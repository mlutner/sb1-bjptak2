import { useAppStore } from '../store';

export function useAppStyles() {
  const { theme } = useAppStore();

  return {
    buttonProps: {
      colorScheme: 'purple',
      bgGradient: theme.gradients.primary,
      _hover: {
        bgGradient: theme.gradients.hover,
      },
    },
    headingProps: {
      color: 'gray.900',
      mb: 2,
    },
    textProps: {
      color: 'gray.600',
    },
  };
}