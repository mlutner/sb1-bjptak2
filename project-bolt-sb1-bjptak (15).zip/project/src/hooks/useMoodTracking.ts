import { useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import { useStore } from '../store';
import type { MoodEntry } from '../types/mood';
import { trackEvent } from '../utils/analytics';
import { handleError } from '../utils/errorBoundary';

export function useMoodTracking() {
  const toast = useToast();
  const { entries, addEntry, hasTrackedToday } = useStore();

  const trackMood = useCallback(async (entry: Omit<MoodEntry, 'id' | 'timestamp'>) => {
    try {
      const newEntry: MoodEntry = {
        id: Date.now().toString(),
        timestamp: new Date().toISOString(),
        ...entry
      };

      addEntry(newEntry);

      trackEvent('mood_tracked', {
        mood: entry.mood,
        hasNote: !!entry.note,
        hasSleepData: !!entry.wearableMetrics?.sleepQuality
      });

      toast({
        title: 'Mood Tracked',
        description: 'Your mood has been recorded successfully',
        status: 'success',
        duration: 3000,
      });

      return newEntry;
    } catch (error) {
      handleError(error, 'trackMood');
      throw error;
    }
  }, [addEntry, toast]);

  return {
    entries,
    trackMood,
    hasTrackedToday,
  };
}