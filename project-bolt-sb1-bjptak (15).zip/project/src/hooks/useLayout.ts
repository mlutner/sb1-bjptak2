import { useAppStore } from '../store';

export function useLayout() {
  const { layout, spacing } = useAppStore();

  return {
    containerProps: {
      maxW: layout.containerMaxWidth,
      px: { base: 4, md: 6, lg: 8 },
      py: spacing.section,
    },
    sectionProps: {
      mb: spacing.section,
    },
    cardProps: {
      p: spacing.element,
      shadow: 'sm',
      borderRadius: 'lg',
    },
  };
}