import { useCallback } from 'react';
import { useToast } from '@chakra-ui/react';

export function useErrorHandler() {
  const toast = useToast();

  return useCallback((error: unknown, operation: string) => {
    console.error(`Error during ${operation}:`, error);
    
    toast({
      title: 'Error',
      description: error instanceof Error ? error.message : 'An unexpected error occurred',
      status: 'error',
      duration: 5000,
    });
  }, [toast]);
}

export function useSuccessHandler() {
  const toast = useToast();

  return useCallback((message: string, description?: string) => {
    toast({
      title: message,
      description,
      status: 'success',
      duration: 3000,
    });
  }, [toast]);
}