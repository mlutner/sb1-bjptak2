import { captureException } from './analytics';

export function handleError(error: unknown, context: string) {
  console.error(`Error in ${context}:`, error);
  
  if (error instanceof Error) {
    captureException(error, { context });
  }
  
  return {
    message: error instanceof Error ? error.message : 'An unexpected error occurred',
    code: error instanceof Error ? error.name : 'UnknownError'
  };
}

export function withErrorBoundary<T>(fn: () => Promise<T>, context: string): Promise<T> {
  return fn().catch(error => {
    const { message } = handleError(error, context);
    throw new Error(message);
  });
}