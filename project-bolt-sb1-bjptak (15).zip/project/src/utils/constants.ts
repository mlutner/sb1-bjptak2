export const APP_CONFIG = {
  name: 'FinWell',
  version: '1.0.0',
  api: {
    baseUrl: import.meta.env.VITE_API_URL || '',
    timeout: 10000,
  },
  storage: {
    prefix: 'finwell_',
    version: 1,
  },
  theme: {
    colors: {
      primary: 'purple.500',
      secondary: 'blue.500',
    },
    gradients: {
      primary: 'linear(to-r, purple.500, blue.500)',
      hover: 'linear(to-r, purple.600, blue.600)',
    },
  },
  routes: {
    public: ['/signin', '/signup', '/assessment'],
    auth: ['/dashboard', '/cbt-program', '/goals'],
  },
} as const;