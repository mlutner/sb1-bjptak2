type EventName = 
  | 'mood_tracked'
  | 'goal_created'
  | 'module_completed'
  | 'assessment_completed'
  | 'error_occurred';

type EventProperties = Record<string, string | number | boolean>;

interface ErrorContext {
  context: string;
  [key: string]: any;
}

export function trackEvent(name: EventName, properties?: EventProperties) {
  // In production, this would send to your analytics service
  if (import.meta.env.DEV) {
    console.log(`[Analytics] ${name}:`, properties);
  }
}

export function trackError(error: Error, context: string) {
  // In production, this would send to your error tracking service
  if (import.meta.env.DEV) {
    console.error(`[Error] ${context}:`, error);
  }
}

export function captureException(error: Error, context: ErrorContext) {
  // Track both error and event
  trackError(error, context.context);
  trackEvent('error_occurred', {
    error: error.message,
    errorName: error.name,
    ...context
  });
}