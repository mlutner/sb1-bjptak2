import { z } from 'zod';

// Shared schemas
export const userSchema = z.object({
  id: z.string(),
  email: z.string().email(),
  name: z.string().min(2),
});

export const moodSchema = z.object({
  type: z.enum(['great', 'good', 'neutral', 'low', 'bad']),
  timestamp: z.string().datetime(),
  note: z.string().optional(),
  sleepHours: z.number().min(0).max(24).optional(),
  sleepQuality: z.number().min(1).max(5).optional(),
});

export const goalSchema = z.object({
  id: z.string(),
  title: z.string().min(3),
  description: z.string(),
  deadline: z.string().datetime(),
  progress: z.number().min(0).max(100),
});

// Type exports
export type User = z.infer<typeof userSchema>;
export type Mood = z.infer<typeof moodSchema>;
export type Goal = z.infer<typeof goalSchema>;