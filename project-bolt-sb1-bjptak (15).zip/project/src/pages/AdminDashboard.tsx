import {
  Box,
  Container,
  Heading,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import AdminMetrics from '../components/admin/AdminMetrics';
import AdminCharts from '../components/admin/AdminCharts';
import AdminFilters from '../components/admin/AdminFilters';

export default function AdminDashboard() {
  const [filter, setFilter] = useState('');
  const [timeframe, setTimeframe] = useState('');
  const toast = useToast();

  const handleFilterChange = (newFilter: string) => {
    setFilter(newFilter);
    toast({
      title: 'Filter Applied',
      description: `Showing data for ${newFilter || 'all departments'}`,
      status: 'info',
      duration: 2000,
    });
  };

  const handleTimeframeChange = (newTimeframe: string) => {
    setTimeframe(newTimeframe);
    toast({
      title: 'Timeframe Updated',
      description: `Showing data for ${newTimeframe || 'all time'}`,
      status: 'info',
      duration: 2000,
    });
  };

  return (
    <Box minH="100vh" bg="gray.50" py={8}>
      <Container maxW="container.xl">
        <VStack spacing={8} align="stretch">
          <Box>
            <Heading size="lg" mb={2}>Admin Dashboard</Heading>
            <Text color="gray.600">
              Monitor user engagement and platform performance
            </Text>
          </Box>

          <AdminFilters
            onFilterChange={handleFilterChange}
            onTimeframeChange={handleTimeframeChange}
          />

          <AdminMetrics />
          
          <AdminCharts />
        </VStack>
      </Container>
    </Box>
  );
}