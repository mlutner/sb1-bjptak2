import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  Button,
  useDisclosure,
  VStack,
} from '@chakra-ui/react';
import SmartGoalsPanel from '../components/dashboard/SmartGoalsPanel';
import GoalSettingWorksheet from '../components/cbt/modules/GoalSettingWorksheet';

export default function Goals() {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        <Box>
          <Heading size="lg" mb={2}>Financial Goals</Heading>
          <Text color="gray.600">Set and track your SMART financial goals</Text>
        </Box>

        <Grid templateColumns={{ base: '1fr', lg: '3fr 1fr' }} gap={6}>
          {/* Main Content */}
          <Box>
            <GoalSettingWorksheet onComplete={() => {}} />
          </Box>

          {/* Side Panel */}
          <Box>
            <SmartGoalsPanel />
          </Box>
        </Grid>
      </VStack>
    </Container>
  );
}