import {
  Box,
  Button,
  Container,
  Flex,
  Grid,
  Heading,
  IconButton,
  Progress,
  Text,
  useToast,
  VStack,
  SimpleGrid,
  Card,
  CardBody,
  CardHeader,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiEdit3, FiTarget, FiClipboard } from 'react-icons/fi';
import GoalSettingWorksheet from '../components/cbt/modules/GoalSettingWorksheet';
import FinancialJournal from '../components/cbt/modules/FinancialJournal';
import Module1Quiz from '../components/cbt/quizzes/Module1Quiz';
import ProgramIntroduction from '../components/cbt/modules/ProgramIntroduction';

type ActiveComponent = 'intro' | 'overview' | 'goals' | 'journal' | 'quiz';

export default function CBTProgram() {
  const [activeComponent, setActiveComponent] = useState<ActiveComponent>('intro');
  const navigate = useNavigate();
  const toast = useToast();

  const handleBack = () => {
    if (activeComponent === 'overview') {
      navigate('/');
    } else {
      setActiveComponent('overview');
    }
  };

  const renderComponent = () => {
    switch (activeComponent) {
      case 'intro':
        return (
          <ProgramIntroduction 
            onStart={() => setActiveComponent('overview')} 
          />
        );
      case 'goals':
        return (
          <GoalSettingWorksheet 
            onComplete={(goals) => {
              toast({
                title: 'Goals Saved',
                status: 'success',
                duration: 3000,
              });
              setActiveComponent('overview');
            }} 
          />
        );
      case 'journal':
        return (
          <FinancialJournal 
            onSave={(entry) => {
              toast({
                title: 'Journal Entry Saved',
                status: 'success',
                duration: 3000,
              });
            }}
          />
        );
      case 'quiz':
        return (
          <Module1Quiz 
            onComplete={(results) => {
              toast({
                title: 'Quiz Completed',
                description: `Score: ${results.score}%`,
                status: 'success',
                duration: 3000,
              });
              setActiveComponent('overview');
            }}
          />
        );
      default:
        return (
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={6}>
            <WorksheetCard
              title="Goal Setting Worksheet"
              description="Define your SMART financial and wellness goals"
              icon={FiTarget}
              onClick={() => setActiveComponent('goals')}
            />
            <WorksheetCard
              title="Financial Journal"
              description="Record your thoughts and feelings about money"
              icon={FiEdit3}
              onClick={() => setActiveComponent('journal')}
            />
            <WorksheetCard
              title="Module 1 Quiz"
              description="Test your understanding of financial wellness concepts"
              icon={FiClipboard}
              onClick={() => setActiveComponent('quiz')}
            />
          </SimpleGrid>
        );
    }
  };

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={6} align="stretch">
        {activeComponent !== 'intro' && (
          <Flex align="center" gap={4}>
            <IconButton
              aria-label="Back"
              icon={<FiArrowLeft />}
              variant="ghost"
              onClick={handleBack}
              size="lg"
            />
            <Box>
              <Heading size="lg">CBT Program</Heading>
              <Text color="gray.600">
                {activeComponent === 'overview' 
                  ? 'Select a worksheet or exercise to begin'
                  : 'Financial Wellness Exercises'}
              </Text>
            </Box>
          </Flex>
        )}

        {/* Content */}
        <Box>
          {renderComponent()}
        </Box>
      </VStack>
    </Container>
  );
}

interface WorksheetCardProps {
  title: string;
  description: string;
  icon: any;
  onClick: () => void;
}

function WorksheetCard({ title, description, icon: Icon, onClick }: WorksheetCardProps) {
  return (
    <Card
      cursor="pointer"
      onClick={onClick}
      _hover={{ transform: 'translateY(-2px)', shadow: 'lg' }}
      transition="all 0.2s"
    >
      <CardBody>
        <VStack spacing={4} align="start">
          <Icon size={24} color="var(--chakra-colors-purple-500)" />
          <Box>
            <Heading size="md" mb={2}>{title}</Heading>
            <Text color="gray.600">{description}</Text>
          </Box>
        </VStack>
      </CardBody>
    </Card>
  );
}