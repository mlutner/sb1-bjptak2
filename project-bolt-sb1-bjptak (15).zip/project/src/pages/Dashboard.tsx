import {
  Container,
  Grid,
  GridItem,
  VStack,
} from '@chakra-ui/react';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import WearablesConnect from '../components/wearables/WearablesConnect';
import WellnessMetrics from '../components/wearables/WellnessMetrics';
import SmartGoalsPanel from '../components/dashboard/SmartGoalsPanel';

export default function Dashboard() {
  return (
    <Container maxW="container.xl">
      <Grid 
        templateColumns={{ base: '1fr', lg: '3fr 1fr' }}
        gap={6}
      >
        {/* Main Content */}
        <GridItem>
          <VStack spacing={6} align="stretch">
            <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
              <MetricsCard />
              <SpendingGraph />
            </Grid>

            <LearningPathways />

            <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
              <MoodTracker />
              <WellnessMetrics />
            </Grid>

            <QuickActions />
          </VStack>
        </GridItem>

        {/* Side Panel */}
        <GridItem>
          <VStack spacing={6} align="stretch">
            <SmartGoalsPanel />
            <WearablesConnect />
          </VStack>
        </GridItem>
      </Grid>
    </Container>
  );
}