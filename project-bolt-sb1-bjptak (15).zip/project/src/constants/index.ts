export const APP_IMAGES = {
  logo: '/finwell-logo.svg',
  defaultAvatar: '/images/demo-avatar.svg',
  heroImages: {
    login: 'https://images.unsplash.com/photo-1515552726023-7125c8d07fb3',
    assessment: 'https://images.unsplash.com/photo-1515552726023-7125c8d07fb3',
  },
} as const;

export const ROUTES = {
  home: '/',
  assessment: '/assessment',
  dashboard: '/dashboard',
  cbtProgram: '/cbt-program',
  goals: '/goals',
  expenses: '/expenses',
  savings: '/savings',
  calendar: '/calendar',
  achievements: '/achievements',
  admin: '/admin',
} as const;

export const NAV_ITEMS = [
  { name: 'Dashboard', icon: 'FiHome', path: ROUTES.home },
  { name: 'Learning Path', icon: 'FiBookOpen', path: ROUTES.cbtProgram },
  { name: 'Goals', icon: 'FiTarget', path: ROUTES.goals },
  { name: 'Expenses', icon: 'FiDollarSign', path: ROUTES.expenses },
  { name: 'Savings', icon: 'FiDatabase', path: ROUTES.savings },
  { name: 'Calendar', icon: 'FiCalendar', path: ROUTES.calendar },
  { name: 'Achievements', icon: 'FiAward', path: ROUTES.achievements },
] as const;