import { useState, useRef, useEffect } from 'react';
import {
  Box,
  Button,
  Flex,
  Icon,
  Input,
  Text,
  VStack,
  useDisclosure,
  IconButton,
  InputGroup,
  InputRightElement,
} from '@chakra-ui/react';
import { FiMessageSquare, FiSend, FiX } from 'react-icons/fi';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  context?: string;
  initialMessage?: string;
  position?: 'fixed' | 'relative';
  showExplainer?: boolean;
}

export default function DesktopChat({
  context = 'general',
  initialMessage = "Hi! I'm your AI financial wellness assistant. How can I help you today?",
  position = 'fixed',
  showExplainer = true,
}: Props) {
  const { isOpen, onToggle } = useDisclosure();
  const [messages, setMessages] = useState([{
    id: '0',
    text: initialMessage,
    sender: 'ai' as const,
    timestamp: new Date()
  }]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      text: input,
      sender: 'user' as const,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage = {
        id: (Date.now() + 1).toString(),
        text: "I understand. Let me help you with that. What specific aspect would you like to explore?",
        sender: 'ai' as const,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <Box position={position} bottom={6} right={6} zIndex={1000}>
      <AnimatePresence>
        {isOpen ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <Box
              bg="white"
              rounded="lg"
              shadow="lg"
              overflow="hidden"
              maxH="600px"
              display="flex"
              flexDirection="column"
              borderWidth="1px"
              borderColor="gray.200"
              maxW="400px"
              w="full"
            >
              <Flex
                align="center"
                justify="space-between"
                p={4}
                bg="purple.500"
                color="white"
              >
                <Flex align="center" gap={2}>
                  <Icon as={FiMessageSquare} boxSize={5} />
                  <Text fontWeight="medium">AI Assistant</Text>
                </Flex>
                <IconButton
                  icon={<FiX />}
                  aria-label="Close chat"
                  variant="ghost"
                  color="white"
                  _hover={{ bg: 'purple.600' }}
                  onClick={onToggle}
                />
              </Flex>

              <VStack spacing={4} p={4} overflowY="auto" maxH="400px" bg="gray.50" align="stretch">
                {messages.map((msg) => (
                  <Flex
                    key={msg.id}
                    justify={msg.sender === 'user' ? 'flex-end' : 'flex-start'}
                  >
                    <Box
                      maxW="80%"
                      bg={msg.sender === 'user' ? 'purple.500' : 'white'}
                      color={msg.sender === 'user' ? 'white' : 'gray.800'}
                      px={4}
                      py={2}
                      rounded="lg"
                      shadow="sm"
                    >
                      <Text>{msg.text}</Text>
                    </Box>
                  </Flex>
                ))}
                <div ref={messagesEndRef} />
              </VStack>

              <Box p={4} bg="white" borderTop="1px" borderColor="gray.100">
                <InputGroup size="lg">
                  <Input
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
                    placeholder="Type your message..."
                    pr="4.5rem"
                  />
                  <InputRightElement width="4.5rem">
                    <IconButton
                      h="1.75rem"
                      size="sm"
                      icon={<FiSend />}
                      onClick={handleSendMessage}
                      aria-label="Send message"
                      isDisabled={!input.trim() || isTyping}
                      colorScheme="purple"
                    />
                  </InputRightElement>
                </InputGroup>
              </Box>
            </Box>
          </motion.div>
        ) : (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
          >
            <Button
              colorScheme="purple"
              leftIcon={<FiMessageSquare />}
              onClick={onToggle}
              shadow="lg"
              size="lg"
              _hover={{
                transform: "translateY(-2px)",
                shadow: "lg",
              }}
            >
              Chat with AI Assistant
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </Box>
  );
}