import {
  Box,
  Circle,
  Flex,
  Text,
  VStack,
} from '@chakra-ui/react';

interface Step {
  label: string;
  time: string;
}

interface ProgressStepsProps {
  steps: Step[];
}

export default function ProgressSteps({ steps }: ProgressStepsProps) {
  return (
    <VStack spacing={4} align="stretch">
      {steps.map((step, index) => (
        <Flex key={index} align="center">
          <Flex align="center" position="relative">
            <Circle
              size="8"
              borderWidth={2}
              borderColor="purple.500"
              bg="white"
              color="purple.500"
              fontWeight="semibold"
            >
              {index + 1}
            </Circle>
            {index < steps.length - 1 && (
              <Box
                h="0.5"
                w="24"
                bg="purple.100"
                mx={2}
              />
            )}
          </Flex>
          <Box ml={4}>
            <Text fontWeight="medium">{step.label}</Text>
            <Text fontSize="sm" color="gray.500">
              Estimated time: {step.time}
            </Text>
          </Box>
        </Flex>
      ))}
    </VStack>
  );
}