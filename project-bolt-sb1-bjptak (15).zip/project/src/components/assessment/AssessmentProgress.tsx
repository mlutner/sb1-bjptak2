import {
  Box,
  Container,
  Flex,
  Progress,
  Text,
} from '@chakra-ui/react';

interface AssessmentProgressProps {
  currentStep: number;
  totalSteps: number;
}

export default function AssessmentProgress({ currentStep, totalSteps }: AssessmentProgressProps) {
  const steps = ['Initial Assessment', 'Financial Behaviors', 'Goal Setting', 'Pathway Selection'];

  return (
    <Box
      position="fixed"
      top={0}
      left={0}
      w="full"
      bg="white"
      shadow="sm"
      zIndex={50}
    >
      <Container maxW="3xl" py={4}>
        <Flex justify="space-between" mb={2}>
          <Text fontSize="sm" fontWeight="medium">Assessment Progress</Text>
          <Text fontSize="sm" fontWeight="medium">{currentStep}/{totalSteps}</Text>
        </Flex>
        
        <Progress
          value={(currentStep/totalSteps) * 100}
          size="sm"
          colorScheme="purple"
          borderRadius="full"
          mb={2}
        />

        <Flex justify="space-between">
          {steps.map((step, index) => (
            <Text
              key={index}
              fontSize="xs"
              color="gray.500"
              textAlign="center"
              flex={1}
            >
              {step}
            </Text>
          ))}
        </Flex>
      </Container>
    </Box>
  );
}