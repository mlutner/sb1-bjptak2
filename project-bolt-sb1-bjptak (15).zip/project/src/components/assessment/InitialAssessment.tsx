import {
  Box,
  Button,
  Container,
  Heading,
  Text,
  VStack,
  Card,
  CardBody,
  Image,
  SimpleGrid,
  Alert,
  AlertIcon,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import ProgramBenefits from './ProgramBenefits';
import AudioIntro from './AudioIntro';
import AssessmentQuestion from './AssessmentQuestion';
import { assessmentQuestions, programBenefits } from '../../data/assessment';
import { determinePathway } from '../../utils/assessment';

export default function InitialAssessment() {
  const [step, setStep] = useState(0);
  const [responses, setResponses] = useState<Record<string, string>>({});
  const [isPlaying, setIsPlaying] = useState(false);
  const navigate = useNavigate();
  const toast = useToast();

  const handleAudioToggle = () => {
    setIsPlaying(!isPlaying);
  };

  const handleResponse = (value: string) => {
    const currentQuestion = assessmentQuestions[step - 1];
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: value
    }));
    
    if (step < assessmentQuestions.length) {
      setTimeout(() => setStep(prev => prev + 1), 300);
    } else {
      const pathway = determinePathway(responses);
      // Navigate to CBT program overview instead of dashboard
      navigate('/cbt-program', { state: { pathway } });
      
      toast({
        title: "Assessment Complete",
        description: "Your personalized learning path is ready",
        status: "success",
        duration: 3000,
      });
    }
  };

  const handleNext = () => {
    if (step === 0) {
      setStep(1);
    }
  };

  const handlePrevious = () => {
    if (step > 0) {
      setStep(prev => prev - 1);
    }
  };

  const renderContent = () => {
    if (step === 0) {
      return (
        <Card>
          <CardBody>
            <VStack spacing={6} align="stretch">
              <Box
                h="300px"
                overflow="hidden"
                borderRadius="xl"
                position="relative"
              >
                <Image
                  src="https://images.unsplash.com/photo-1515552726023-7125c8d07fb3?auto=format&fit=crop&q=80"
                  alt="Financial Wellness Journey"
                  objectFit="cover"
                  w="full"
                  h="full"
                />
                <Box
                  position="absolute"
                  top={0}
                  left={0}
                  right={0}
                  bottom={0}
                  bg="blackAlpha.600"
                  p={6}
                  display="flex"
                  flexDirection="column"
                  justifyContent="flex-end"
                >
                  <Heading color="white" size="lg" mb={2}>
                    Welcome to FinWell
                  </Heading>
                  <Text color="whiteAlpha.900">
                    Your journey to financial wellness begins here
                  </Text>
                </Box>
              </Box>

              <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6}>
                {programBenefits.map((benefit) => (
                  <Card key={benefit.id} p={6}>
                    <Heading size="md" mb={2}>{benefit.title}</Heading>
                    <Text color="gray.600" mb={2}>{benefit.description}</Text>
                    <Text color="purple.600" fontSize="sm">{benefit.metrics}</Text>
                  </Card>
                ))}
              </SimpleGrid>

              <Alert status="info" borderRadius="lg">
                <AlertIcon />
                <Text>
                  This assessment takes about 5 minutes to complete. Your answers will help us create
                  your personalized financial wellness journey.
                </Text>
              </Alert>

              <Button
                colorScheme="purple"
                size="lg"
                onClick={handleNext}
                bgGradient="linear(to-r, purple.500, blue.500)"
                _hover={{
                  bgGradient: "linear(to-r, purple.600, blue.600)",
                }}
              >
                Begin Assessment
              </Button>
            </VStack>
          </CardBody>
        </Card>
      );
    }

    const currentQuestion = assessmentQuestions[step - 1];
    return (
      <AssessmentQuestion
        question={currentQuestion.question}
        options={currentQuestion.options}
        currentResponse={responses[currentQuestion.id]}
        onAnswer={handleResponse}
        onNext={handleNext}
        onPrevious={handlePrevious}
        isLastQuestion={step === assessmentQuestions.length}
      />
    );
  };

  return (
    <Container maxW="2xl">
      <VStack spacing={8} align="stretch">
        {renderContent()}
      </VStack>
    </Container>
  );
}