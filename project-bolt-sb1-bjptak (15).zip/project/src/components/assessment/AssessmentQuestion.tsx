import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  VStack,
  Text,
  Progress,
  Icon,
  Flex,
  useToast,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { FiArrowLeft, FiArrowRight } from 'react-icons/fi';
import { useEffect } from 'react';

interface Option {
  id: string;
  label: string;
}

interface Props {
  question: string;
  options: Option[];
  currentResponse?: string;
  onAnswer: (value: string) => void;
  onNext: () => void;
  onPrevious: () => void;
  isLastQuestion: boolean;
}

export default function AssessmentQuestion({
  question,
  options,
  currentResponse,
  onAnswer,
  onNext,
  onPrevious,
  isLastQuestion,
}: Props) {
  const toast = useToast();

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [question]);

  const handleOptionClick = (value: string) => {
    onAnswer(value);
    // Add a small delay before advancing
    setTimeout(() => {
      onNext();
    }, 300);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.3 }}
    >
      <Card maxW="3xl" mx="auto">
        <CardHeader>
          <VStack spacing={4} align="stretch">
            <Heading size="lg">{question}</Heading>
            <Progress 
              value={currentResponse ? 100 : 0} 
              size="sm" 
              colorScheme="purple" 
              borderRadius="full" 
            />
          </VStack>
        </CardHeader>

        <CardBody>
          <VStack spacing={8} align="stretch">
            <VStack spacing={4} align="stretch">
              {options.map((option) => (
                <Card
                  key={option.id} // Using option.id as the unique key
                  onClick={() => handleOptionClick(option.id)}
                  cursor="pointer"
                  variant="outline"
                  borderWidth={2}
                  borderColor={currentResponse === option.id ? 'purple.500' : 'gray.200'}
                  _hover={{
                    borderColor: 'purple.300',
                    transform: 'translateY(-2px)',
                    shadow: 'md',
                  }}
                  transition="all 0.2s"
                  p={6}
                >
                  <Text fontWeight="medium">{option.label}</Text>
                </Card>
              ))}
            </VStack>

            <Flex justify="space-between">
              <Button
                leftIcon={<Icon as={FiArrowLeft} />}
                onClick={onPrevious}
                variant="ghost"
              >
                Back
              </Button>
              {isLastQuestion && currentResponse && (
                <Button
                  rightIcon={<Icon as={FiArrowRight} />}
                  onClick={onNext}
                  colorScheme="purple"
                >
                  Complete Assessment
                </Button>
              )}
            </Flex>
          </VStack>
        </CardBody>
      </Card>
    </motion.div>
  );
}