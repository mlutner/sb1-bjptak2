import {
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
} from '@chakra-ui/react';

interface Props {
  isOpen: boolean;
  onDismiss: () => void;
  children: React.ReactNode;
  header?: React.ReactNode;
}

export default function BottomSheet({ 
  isOpen, 
  onDismiss, 
  children, 
  header 
}: Props) {
  return (
    <Drawer
      isOpen={isOpen}
      placement="bottom"
      onClose={onDismiss}
      autoFocus={false}
    >
      <DrawerOverlay />
      <DrawerContent
        borderTopRadius="20px"
        maxH="90vh"
      >
        {header && (
          <DrawerHeader p={4}>
            {header}
          </DrawerHeader>
        )}
        <DrawerCloseButton />
        <DrawerBody p={4}>
          {children}
        </DrawerBody>
      </DrawerContent>
    </Drawer>
  );
}