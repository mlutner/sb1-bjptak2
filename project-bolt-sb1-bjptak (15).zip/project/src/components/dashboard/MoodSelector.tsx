import {
  SimpleGrid,
  Button,
  Icon,
  Text,
  Box,
  useColorModeValue,
} from '@chakra-ui/react';
import { FiSmile, FiMeh, FiFrown } from 'react-icons/fi';

interface Props {
  onSelect: () => void;
}

const MOODS = [
  { icon: FiSmile, label: 'Great', color: 'green' },
  { icon: FiSmile, label: 'Good', color: 'blue' },
  { icon: FiMeh, label: 'Okay', color: 'yellow' },
  { icon: FiFrown, label: 'Low', color: 'orange' },
  { icon: FiFrown, label: 'Rough', color: 'red' },
];

export default function MoodSelector({ onSelect }: Props) {
  const buttonBg = useColorModeValue('white', 'gray.800');

  return (
    <SimpleGrid columns={{ base: 2, sm: 5 }} spacing={4}>
      {MOODS.map((mood) => (
        <Button
          key={mood.label}
          onClick={onSelect}
          height="auto"
          p={4}
          bg={buttonBg}
          borderWidth={1}
          borderColor={`${mood.color}.200`}
          _hover={{
            bg: `${mood.color}.50`,
            transform: 'translateY(-2px)',
            shadow: 'md',
          }}
          transition="all 0.2s"
        >
          <Box>
            <Icon
              as={mood.icon}
              boxSize={8}
              color={`${mood.color}.500`}
              mb={2}
            />
            <Text
              fontSize="sm"
              fontWeight="medium"
              color={`${mood.color}.700`}
            >
              {mood.label}
            </Text>
          </Box>
        </Button>
      ))}
    </SimpleGrid>
  );
}