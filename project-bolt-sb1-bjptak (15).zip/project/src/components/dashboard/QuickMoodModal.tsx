import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  VStack,
  Button,
  Text,
  Textarea,
  FormControl,
  FormLabel,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  Icon,
  HStack,
} from '@chakra-ui/react';
import { useState } from 'react';
import { FiMoon, FiStar } from 'react-icons/fi';
import type { MoodEntry } from '../../types/mood';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (entry: Omit<MoodEntry, 'id' | 'timestamp'>) => void;
  selectedMood: string | null;
}

export default function QuickMoodModal({ isOpen, onClose, onSubmit, selectedMood }: Props) {
  const [sleepHours, setSleepHours] = useState(7);
  const [sleepQuality, setSleepQuality] = useState(3);
  const [note, setNote] = useState('');

  const handleSubmit = () => {
    if (!selectedMood) return;

    onSubmit({
      mood: selectedMood as MoodEntry['mood'],
      note: note.trim() || undefined,
      wearableMetrics: {
        sleepQuality,
        sleepHours
      }
    });

    // Reset form
    setSleepHours(7);
    setSleepQuality(3);
    setNote('');
    onClose();
  };

  return (
    <Modal 
      isOpen={isOpen} 
      onClose={onClose} 
      isCentered 
      motionPreset="slideInBottom"
    >
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Add More Context</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <VStack spacing={6}>
            {/* Sleep Duration */}
            <FormControl>
              <FormLabel>Hours of Sleep</FormLabel>
              <HStack spacing={4}>
                <Icon as={FiMoon} color="purple.500" />
                <Slider
                  value={sleepHours}
                  min={0}
                  max={12}
                  step={0.5}
                  onChange={setSleepHours}
                  flex={1}
                >
                  <SliderTrack>
                    <SliderFilledTrack />
                  </SliderTrack>
                  <SliderThumb />
                </Slider>
                <Text w="3.5rem" textAlign="right">{sleepHours}h</Text>
              </HStack>
            </FormControl>

            {/* Sleep Quality */}
            <FormControl>
              <FormLabel>Sleep Quality</FormLabel>
              <HStack spacing={4}>
                <Icon as={FiStar} color="purple.500" />
                <Slider
                  value={sleepQuality}
                  min={1}
                  max={5}
                  step={1}
                  onChange={setSleepQuality}
                  flex={1}
                >
                  <SliderTrack>
                    <SliderFilledTrack />
                  </SliderTrack>
                  <SliderThumb />
                </Slider>
                <Text w="3.5rem" textAlign="right">{sleepQuality}/5</Text>
              </HStack>
            </FormControl>

            {/* Notes */}
            <FormControl>
              <FormLabel>Notes (Optional)</FormLabel>
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder="What's making you feel this way?"
                rows={4}
              />
            </FormControl>

            <Button
              colorScheme="purple"
              size="lg"
              w="full"
              onClick={handleSubmit}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Save Entry
            </Button>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}