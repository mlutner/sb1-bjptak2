import {
  Box,
  Button,
  Flex,
  Input,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';

interface AITherapistProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function AITherapist({ isOpen, onClose }: AITherapistProps) {
  if (!isOpen) return null;

  return (
    <Box
      position="fixed"
      bottom={6}
      right={6}
      zIndex={50}
      bg="white"
      rounded="lg"
      shadow="lg"
      maxW="sm"
    >
      <Flex align="center" justify="space-between" p={4} borderBottom="1px" borderColor="gray.200">
        <Flex align="center" gap={3}>
          <Flex
            w={10}
            h={10}
            bg="purple.100"
            rounded="full"
            align="center"
            justify="center"
          >
            <Text color="purple.600" fontWeight="semibold">AI</Text>
          </Flex>
          <Box>
            <Text fontWeight="semibold">Financial Wellbeing Therapist</Text>
            <Text fontSize="sm" color="gray.500">Online</Text>
          </Box>
        </Flex>
        <Button variant="ghost" onClick={onClose}>
          ✕
        </Button>
      </Flex>

      <Box h="96" overflowY="auto" p={4}>
        {/* Chat messages will go here */}
      </Box>

      <Box p={4} borderTop="1px" borderColor="gray.200">
        <Flex gap={2}>
          <Input
            placeholder="Talk to your financial wellbeing therapist..."
            _focus={{
              borderColor: 'purple.500',
              boxShadow: '0 0 0 1px var(--chakra-colors-purple-500)',
            }}
          />
          <Button colorScheme="purple">Send</Button>
        </Flex>
      </Box>
    </Box>
  );
}