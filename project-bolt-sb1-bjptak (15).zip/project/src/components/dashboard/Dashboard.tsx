import {
  Box,
  Container,
  Grid,
  GridItem,
  VStack,
  useBreakpointValue,
  Heading,
  Text,
  Flex,
  Avatar,
  useDisclosure,
  Alert,
  AlertIcon,
  AlertTitle,
  AlertDescription,
  Button,
  CloseButton,
  Card,
  CardBody,
} from '@chakra-ui/react';
import { useEffect } from 'react';
import MoodTracker from './MoodTracker';
import MetricsCard from './MetricsCard';
import SpendingGraph from './SpendingGraph';
import LearningPathways from './LearningPathways';
import WearablesConnect from '../wearables/WearablesConnect';
import WellnessMetrics from '../wearables/WellnessMetrics';
import QuickActions from './QuickActions';

export default function Dashboard() {
  const isMobile = useBreakpointValue({ base: true, md: false });
  const { isOpen: showPrompt, onClose: closePrompt } = useDisclosure({ defaultIsOpen: true });
  const hasMoodToday = false; // This would come from your mood tracking state/API

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Welcome Header */}
        <Card bg="white" shadow="sm">
          <CardBody>
            <Grid templateColumns={{ base: '1fr', md: '1fr auto' }} gap={6} alignItems="center">
              <Box>
                <Heading size="lg">Welcome back, Demo User</Heading>
                <Text color="gray.600" mt={1}>Let's check in on your financial wellness</Text>
              </Box>
              <Avatar
                size="lg"
                name="Demo User"
                src="/images/demo-avatar.svg"
                bg="purple.500"
              />
            </Grid>
          </CardBody>
        </Card>

        {/* Prominent Mood Tracking Section */}
        <Box>
          {showPrompt && !hasMoodToday && (
            <Alert
              status="info"
              variant="subtle"
              flexDirection="column"
              alignItems="center"
              justifyContent="center"
              textAlign="center"
              borderRadius="lg"
              p={6}
              bg="blue.50"
              borderWidth={1}
              borderColor="blue.200"
              mb={4}
            >
              <Flex w="100%" justify="space-between" align="center" mb={4}>
                <AlertIcon boxSize={6} />
                <AlertTitle mr={2}>Time for Your Daily Check-in!</AlertTitle>
                <CloseButton onClick={closePrompt} />
              </Flex>
              <AlertDescription maxWidth="sm">
                Start your day right by tracking your financial mood. Regular check-ins help build better habits and insights.
              </AlertDescription>
              <Button
                mt={4}
                colorScheme="blue"
                size="lg"
                onClick={closePrompt}
                variant="outline"
              >
                Track Now
              </Button>
            </Alert>
          )}

          <Card
            bg="white"
            shadow="md"
            _hover={{ transform: "translateY(-2px)", shadow: "lg" }}
            transition="all 0.2s"
            borderWidth={2}
            borderColor="purple.100"
          >
            <CardBody>
              <MoodTracker />
            </CardBody>
          </Card>
        </Box>

        {/* Main Content Grid */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <GridItem>
            <MetricsCard />
          </GridItem>
          <GridItem>
            <SpendingGraph />
          </GridItem>
        </Grid>

        {/* Learning Pathways */}
        <Box>
          <LearningPathways />
        </Box>

        {/* Wearables and Wellness Section */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <GridItem>
            <WearablesConnect />
          </GridItem>
          <GridItem>
            <WellnessMetrics />
          </GridItem>
        </Grid>

        {/* Quick Actions */}
        <Box>
          <QuickActions />
        </Box>
      </VStack>
    </Container>
  );
}