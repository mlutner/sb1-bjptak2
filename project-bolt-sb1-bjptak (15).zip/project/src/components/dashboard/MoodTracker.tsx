import {
  Box,
  Flex,
  Text,
  VStack,
  useDisclosure,
  useToast,
  Heading,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { useMoodTracking } from '../../hooks/useMoodTracking';
import MoodSelector from './MoodSelector';
import QuickMoodModal from './QuickMoodModal';
import { useEffect } from 'react';

export default function MoodTracker() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const { trackMood, hasTrackedToday } = useMoodTracking();
  const toast = useToast();

  // Show reminder if needed
  useEffect(() => {
    if (!hasTrackedToday()) {
      toast({
        title: "Time for Your Daily Check-in",
        description: "Track your financial mood to build better habits",
        status: "info",
        duration: null,
        isClosable: true,
        position: "top",
      });
    }
  }, [hasTrackedToday, toast]);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <VStack spacing={6} align="stretch">
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md" color="purple.700">How are you feeling about your finances today?</Heading>
            <Text color="gray.600" mt={1}>Your daily financial wellness check-in</Text>
          </Box>
          {hasTrackedToday() && (
            <Text color="green.500" fontSize="sm" fontWeight="medium">
              ✓ Tracked Today
            </Text>
          )}
        </Flex>
        
        <Box>
          <MoodSelector onSelect={onOpen} />
        </Box>
      </VStack>

      <QuickMoodModal 
        isOpen={isOpen}
        onClose={onClose}
        onSubmit={trackMood}
      />
    </motion.div>
  );
}