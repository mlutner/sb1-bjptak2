import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { sendPasswordResetEmail } from 'firebase/auth';
import { auth } from '../../config/firebase';
import {
  Box,
  Button,
  Card,
  CardBody,
  FormControl,
  FormLabel,
  Heading,
  Input,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';

export default function PasswordReset() {
  const [email, setEmail] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const toast = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      await sendPasswordResetEmail(auth, email);
      toast({
        title: 'Reset email sent',
        description: 'Check your email for password reset instructions',
        status: 'success',
        duration: 5000,
      });
      navigate('/signin');
    } catch (error) {
      console.error('Password reset error:', error);
      toast({
        title: 'Error',
        description: 'Failed to send reset email. Please try again.',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box minH="100vh" bg="gray.50" py={12}>
      <Box maxW="md" mx="auto">
        <Card shadow="lg">
          <CardBody>
            <VStack spacing={6}>
              <Heading size="lg">Reset Password</Heading>
              <Text color="gray.600" textAlign="center">
                Enter your email address and we'll send you instructions to reset your password.
              </Text>

              <form onSubmit={handleSubmit} style={{ width: '100%' }}>
                <VStack spacing={6}>
                  <FormControl isRequired>
                    <FormLabel>Email Address</FormLabel>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Enter your email"
                      bg="white"
                    />
                  </FormControl>

                  <Button
                    type="submit"
                    colorScheme="purple"
                    size="lg"
                    isLoading={loading}
                    w="full"
                    bgGradient="linear(to-r, purple.500, purple.600)"
                    _hover={{
                      bgGradient: "linear(to-r, purple.600, purple.700)",
                    }}
                  >
                    Send Reset Instructions
                  </Button>

                  <Button
                    variant="ghost"
                    onClick={() => navigate('/signin')}
                    size="sm"
                  >
                    Back to Sign In
                  </Button>
                </VStack>
              </form>
            </VStack>
          </CardBody>
        </Card>
      </Box>
    </Box>
  );
}