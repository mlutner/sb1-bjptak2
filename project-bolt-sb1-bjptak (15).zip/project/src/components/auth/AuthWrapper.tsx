import { useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { Center, Spinner } from '@chakra-ui/react';

interface Props {
  children: React.ReactNode;
}

export default function AuthWrapper({ children }: Props) {
  const { isAuthenticated, loading } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const publicPaths = ['/signin', '/signup', '/assessment'];
    if (!loading && !isAuthenticated && !publicPaths.some(path => location.pathname.includes(path))) {
      navigate('/signin');
    }
  }, [isAuthenticated, loading, navigate, location]);

  if (loading) {
    return (
      <Center h="100vh" bg="gray.50">
        <Spinner size="xl" color="purple.500" thickness="4px" />
      </Center>
    );
  }

  if (!isAuthenticated && !location.pathname.includes('/assessment')) {
    return null;
  }

  return <>{children}</>;
}