import { useState } from 'react';
import {
  Box,
  Grid,
  Text,
  Button,
  HStack,
  VStack,
  Badge,
  useColorModeValue,
} from '@chakra-ui/react';
import { format, addMonths, subMonths, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday } from 'date-fns';

interface Event {
  id: string;
  title: string;
  start: Date;
  end: Date;
  type: 'consultation' | 'goal' | 'reminder';
}

interface Props {
  events: Event[];
  onDateSelect: (selectInfo: { start: Date }) => void;
}

export default function CalendarView({ events, onDateSelect }: Props) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const bgColor = useColorModeValue('white', 'gray.800');
  const todayBg = useColorModeValue('purple.50', 'purple.900');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const prevMonth = () => setCurrentDate(subMonths(currentDate, 1));

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const getEventsForDate = (date: Date) => 
    events.filter(event => 
      format(event.start, 'yyyy-MM-dd') === format(date, 'yyyy-MM-dd')
    );

  return (
    <Box bg={bgColor} p={6} rounded="lg" shadow="sm">
      <VStack spacing={6} align="stretch">
        <HStack justify="space-between">
          <Button onClick={prevMonth} variant="ghost">Previous</Button>
          <Text fontSize="xl" fontWeight="bold">
            {format(currentDate, 'MMMM yyyy')}
          </Text>
          <Button onClick={nextMonth} variant="ghost">Next</Button>
        </HStack>

        <Grid templateColumns="repeat(7, 1fr)" gap={2}>
          {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
            <Box key={day} textAlign="center" fontWeight="medium" py={2}>
              {day}
            </Box>
          ))}

          {days.map(day => {
            const dayEvents = getEventsForDate(day);
            const isCurrentMonth = isSameMonth(day, currentDate);
            const isCurrentDay = isToday(day);

            return (
              <Box
                key={day.toString()}
                p={2}
                bg={isCurrentDay ? todayBg : 'transparent'}
                border="1px"
                borderColor={borderColor}
                rounded="md"
                opacity={isCurrentMonth ? 1 : 0.5}
                cursor="pointer"
                onClick={() => onDateSelect({ start: day })}
                _hover={{ bg: 'gray.50' }}
                minH="100px"
              >
                <Text fontWeight={isCurrentDay ? "bold" : "normal"}>
                  {format(day, 'd')}
                </Text>
                <VStack align="stretch" spacing={1} mt={1}>
                  {dayEvents.map(event => (
                    <Badge
                      key={event.id}
                      colorScheme={
                        event.type === 'consultation' ? 'purple' :
                        event.type === 'goal' ? 'green' : 'blue'
                      }
                      fontSize="xs"
                      p={1}
                      noOfLines={1}
                    >
                      {event.title}
                    </Badge>
                  ))}
                </VStack>
              </Box>
            );
          })}
        </Grid>
      </VStack>
    </Box>
  );
}