import {
  SimpleGrid,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Card,
  CardBody,
  Icon,
  Flex,
} from '@chakra-ui/react';
import { FiUsers, FiTrendingUp, FiActivity, FiTarget } from 'react-icons/fi';

const metrics = [
  {
    label: 'Active Users',
    value: '1,240',
    change: 12,
    icon: FiUsers,
    color: 'purple.500'
  },
  {
    label: 'Engagement Rate',
    value: '78%',
    change: 8,
    icon: FiTrendingUp,
    color: 'blue.500'
  },
  {
    label: 'Total Sessions',
    value: '4,080',
    change: 15,
    icon: FiActivity,
    color: 'green.500'
  },
  {
    label: 'Goals Achieved',
    value: '892',
    change: 10,
    icon: FiTarget,
    color: 'orange.500'
  }
];

export default function AdminMetrics() {
  return (
    <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
      {metrics.map((metric) => (
        <Card key={metric.label}>
          <CardBody>
            <Stat>
              <Flex justify="space-between" align="center" mb={2}>
                <StatLabel color="gray.600">{metric.label}</StatLabel>
                <Icon as={metric.icon} color={metric.color} boxSize={5} />
              </Flex>
              <StatNumber fontSize="2xl">{metric.value}</StatNumber>
              <StatHelpText>
                <StatArrow type={metric.change >= 0 ? 'increase' : 'decrease'} />
                {Math.abs(metric.change)}%
              </StatHelpText>
            </Stat>
          </CardBody>
        </Card>
      ))}
    </SimpleGrid>
  );
}