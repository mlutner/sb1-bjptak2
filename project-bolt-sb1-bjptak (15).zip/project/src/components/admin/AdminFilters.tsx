import {
  Flex,
  Select,
  Button,
  ButtonGroup,
  Icon,
} from '@chakra-ui/react';
import { FiDownload, FiRefreshCw } from 'react-icons/fi';

interface Props {
  onFilterChange: (filter: string) => void;
  onTimeframeChange: (timeframe: string) => void;
}

export default function AdminFilters({ onFilterChange, onTimeframeChange }: Props) {
  return (
    <Flex justify="space-between" align="center" mb={6} gap={4} wrap="wrap">
      <Flex gap={4}>
        <Select 
          placeholder="All Departments" 
          w="200px"
          onChange={(e) => onFilterChange(e.target.value)}
        >
          <option value="sales">Sales</option>
          <option value="engineering">Engineering</option>
          <option value="marketing">Marketing</option>
          <option value="hr">HR</option>
          <option value="finance">Finance</option>
        </Select>

        <Select 
          placeholder="Timeframe" 
          w="150px"
          onChange={(e) => onTimeframeChange(e.target.value)}
        >
          <option value="week">Last Week</option>
          <option value="month">Last Month</option>
          <option value="quarter">Last Quarter</option>
          <option value="year">Last Year</option>
        </Select>
      </Flex>

      <ButtonGroup>
        <Button
          leftIcon={<Icon as={FiRefreshCw} />}
          variant="ghost"
          onClick={() => {
            onFilterChange('');
            onTimeframeChange('');
          }}
        >
          Reset
        </Button>
        <Button
          leftIcon={<Icon as={FiDownload} />}
          colorScheme="purple"
        >
          Export Data
        </Button>
      </ButtonGroup>
    </Flex>
  );
}