import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  Text,
  VStack,
  Card,
  CardBody,
  CardHeader,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Icon,
  Flex,
  Select,
  ButtonGroup,
  Button,
} from '@chakra-ui/react';
import { FiUsers, FiTrendingUp, FiActivity, FiBarChart2, FiDownload, FiRefreshCw } from 'react-icons/fi';
import { Line, Pie } from 'react-chartjs-2';

const metrics = [
  {
    title: 'Active Users',
    value: '1,240',
    change: 12,
    icon: FiUsers,
  },
  {
    title: 'Engagement Rate',
    value: '78%',
    change: 8,
    icon: FiTrendingUp,
  },
  {
    title: 'Sessions',
    value: '4,080',
    change: 15,
    icon: FiActivity,
  },
  {
    title: 'Tools Used',
    value: '6,120',
    change: 10,
    icon: FiBarChart2,
  }
];

const engagementData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Active Users',
      data: [420, 480, 540, 600, 650, 700],
      borderColor: 'rgb(124, 58, 237)',
      tension: 0.1,
    },
    {
      label: 'Sessions',
      data: [840, 960, 1080, 1200, 1300, 1400],
      borderColor: 'rgb(59, 130, 246)',
      tension: 0.1,
    }
  ],
};

const departmentData = {
  labels: ['Sales', 'Engineering', 'Marketing', 'HR', 'Finance'],
  datasets: [
    {
      data: [150, 200, 80, 40, 60],
      backgroundColor: [
        'rgba(124, 58, 237, 0.8)',
        'rgba(59, 130, 246, 0.8)',
        'rgba(34, 197, 94, 0.8)',
        'rgba(249, 115, 22, 0.8)',
        'rgba(236, 72, 153, 0.8)',
      ],
    },
  ],
};

const chartOptions = {
  responsive: true,
  maintainAspectRatio: false,
  plugins: {
    legend: {
      position: 'top' as const,
    },
  },
};

export default function AdminDashboard() {
  return (
    <Box minH="100vh" bg="gray.50" p={8}>
      <Container maxW="7xl">
        <VStack spacing={8} align="stretch">
          {/* Header */}
          <Flex justify="space-between" align="center">
            <Box>
              <Heading size="lg">Admin Dashboard</Heading>
              <Text color="gray.600" mt={1}>Monitor platform performance and user engagement</Text>
            </Box>
            <ButtonGroup>
              <Button leftIcon={<Icon as={FiRefreshCw} />} variant="ghost">
                Refresh
              </Button>
              <Button leftIcon={<Icon as={FiDownload} />} colorScheme="purple">
                Export Data
              </Button>
            </ButtonGroup>
          </Flex>

          {/* Filters */}
          <Flex gap={4}>
            <Select bg="white" w="200px" defaultValue="all">
              <option value="all">All Departments</option>
              <option value="sales">Sales</option>
              <option value="engineering">Engineering</option>
              <option value="marketing">Marketing</option>
              <option value="hr">HR</option>
              <option value="finance">Finance</option>
            </Select>
            <Select bg="white" w="150px" defaultValue="month">
              <option value="week">Last Week</option>
              <option value="month">Last Month</option>
              <option value="quarter">Last Quarter</option>
              <option value="year">Last Year</option>
            </Select>
          </Flex>

          {/* Metrics Grid */}
          <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)', lg: 'repeat(4, 1fr)' }} gap={6}>
            {metrics.map((metric) => (
              <Card key={metric.title}>
                <CardBody>
                  <Stat>
                    <Flex justify="space-between" align="center" mb={2}>
                      <StatLabel>{metric.title}</StatLabel>
                      <Icon as={metric.icon} color="purple.500" boxSize={5} />
                    </Flex>
                    <StatNumber>{metric.value}</StatNumber>
                    <StatHelpText>
                      <StatArrow type={metric.change >= 0 ? 'increase' : 'decrease'} />
                      {Math.abs(metric.change)}%
                    </StatHelpText>
                  </Stat>
                </CardBody>
              </Card>
            ))}
          </Grid>

          {/* Charts */}
          <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
            <Card>
              <CardHeader>
                <Heading size="md">Engagement Trends</Heading>
              </CardHeader>
              <CardBody>
                <Box h="300px">
                  <Line options={chartOptions} data={engagementData} />
                </Box>
              </CardBody>
            </Card>

            <Card>
              <CardHeader>
                <Heading size="md">Department Distribution</Heading>
              </CardHeader>
              <CardBody>
                <Box h="300px">
                  <Pie data={departmentData} options={chartOptions} />
                </Box>
              </CardBody>
            </Card>
          </Grid>

          {/* Insights Card */}
          <Card bg="blue.50">
            <CardBody>
              <Flex justify="space-between" align="center">
                <Heading size="md">Key Insights</Heading>
                <Flex gap={6}>
                  <Text color="blue.700">↑ 15% reduction in financial distress</Text>
                  <Text color="blue.700">↑ 12% increase in productivity</Text>
                  <Text color="blue.700">↑ 82% engagement in Engineering</Text>
                </Flex>
              </Flex>
            </CardBody>
          </Card>
        </VStack>
      </Container>
    </Box>
  );
}