import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  VStack,
  Text,
  Flex,
  Button,
  CircularProgress,
  CircularProgressLabel,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import UpdateRRSPModal from './UpdateRRSPModal';

export default function RRSPTracker() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [rrspData, setRRSPData] = useState({
    balance: 45000,
    contributionRoom: 27830,
    yearlyContribution: 6000,
    yearlyLimit: 29210,
    returns: 8.5
  });

  const contributionProgress = (rrspData.yearlyContribution / rrspData.yearlyLimit) * 100;

  return (
    <>
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center">
            <Heading size="md">RRSP Overview</Heading>
            <Button
              colorScheme="purple"
              variant="outline"
              size="sm"
              onClick={onOpen}
            >
              Update RRSP
            </Button>
          </Flex>
        </CardHeader>

        <CardBody>
          <Flex gap={6} flexWrap="wrap">
            <Box flex="1">
              <VStack spacing={4} align="stretch">
                <Stat>
                  <StatLabel>Total RRSP Balance</StatLabel>
                  <StatNumber>${rrspData.balance.toLocaleString()}</StatNumber>
                  <StatHelpText>
                    {rrspData.returns}% annual return
                  </StatHelpText>
                </Stat>

                <Stat>
                  <StatLabel>Available Contribution Room</StatLabel>
                  <StatNumber>${rrspData.contributionRoom.toLocaleString()}</StatNumber>
                  <StatHelpText>
                    For current tax year
                  </StatHelpText>
                </Stat>
              </VStack>
            </Box>

            <Box>
              <VStack align="center" spacing={2}>
                <CircularProgress
                  value={contributionProgress}
                  size="120px"
                  thickness="8px"
                  color="green.400"
                >
                  <CircularProgressLabel>
                    {Math.round(contributionProgress)}%
                  </CircularProgressLabel>
                </CircularProgress>
                <Text fontSize="sm" color="gray.600" textAlign="center">
                  Yearly Contribution Progress
                </Text>
              </VStack>
            </Box>
          </Flex>
        </CardBody>
      </Card>

      <UpdateRRSPModal
        isOpen={isOpen}
        onClose={onClose}
        currentData={rrspData}
        onUpdate={setRRSPData}
      />
    </>
  );
}