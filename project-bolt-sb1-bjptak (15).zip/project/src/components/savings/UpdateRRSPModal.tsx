import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  VStack,
  Button,
} from '@chakra-ui/react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentData: {
    balance: number;
    contributionRoom: number;
    yearlyContribution: number;
    yearlyLimit: number;
    returns: number;
  };
  onUpdate: (data: any) => void;
}

export default function UpdateRRSPModal({ isOpen, onClose, currentData, onUpdate }: Props) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const updatedData = {
      balance: Number(formData.get('balance')),
      contributionRoom: Number(formData.get('contributionRoom')),
      yearlyContribution: Number(formData.get('yearlyContribution')),
      yearlyLimit: Number(formData.get('yearlyLimit')),
      returns: Number(formData.get('returns'))
    };

    onUpdate(updatedData);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Update RRSP Details</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <form onSubmit={handleSubmit}>
            <VStack spacing={4}>
              <FormControl>
                <FormLabel>Total Balance</FormLabel>
                <NumberInput defaultValue={currentData.balance} min={0}>
                  <NumberInputField name="balance" />
                </NumberInput>
              </FormControl>

              <FormControl>
                <FormLabel>Contribution Room</FormLabel>
                <NumberInput defaultValue={currentData.contributionRoom} min={0}>
                  <NumberInputField name="contributionRoom" />
                </NumberInput>
              </FormControl>

              <FormControl>
                <FormLabel>Yearly Contribution</FormLabel>
                <NumberInput defaultValue={currentData.yearlyContribution} min={0}>
                  <NumberInputField name="yearlyContribution" />
                </NumberInput>
              </FormControl>

              <FormControl>
                <FormLabel>Yearly Limit</FormLabel>
                <NumberInput defaultValue={currentData.yearlyLimit} min={0}>
                  <NumberInputField name="yearlyLimit" />
                </NumberInput>
              </FormControl>

              <FormControl>
                <FormLabel>Annual Returns (%)</FormLabel>
                <NumberInput defaultValue={currentData.returns} min={0} max={100}>
                  <NumberInputField name="returns" />
                </NumberInput>
              </FormControl>

              <Button type="submit" colorScheme="purple" w="full">
                Update RRSP
              </Button>
            </VStack>
          </form>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}