import { useState, useEffect } from 'react';
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  VStack,
  Text,
  Icon,
  Box,
} from '@chakra-ui/react';
import { FiAward } from 'react-icons/fi';
import Confetti from 'react-confetti';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  achievement: {
    title: string;
    description: string;
    points: number;
  };
}

export default function AchievementUnlock({ isOpen, onClose, achievement }: Props) {
  const [showConfetti, setShowConfetti] = useState(true);

  useEffect(() => {
    if (isOpen) {
      const timer = setTimeout(() => {
        setShowConfetti(false);
        onClose();
      }, 5000);
      return () => clearTimeout(timer);
    }
  }, [isOpen, onClose]);

  return (
    <Modal isOpen={isOpen} onClose={onClose} isCentered>
      <ModalOverlay />
      <ModalContent bg="transparent" boxShadow="none">
        <ModalBody>
          {showConfetti && <Confetti />}
          <VStack
            spacing={4}
            bg="white"
            p={8}
            borderRadius="xl"
            boxShadow="xl"
            position="relative"
            overflow="hidden"
          >
            <Box
              position="absolute"
              top={0}
              left={0}
              right={0}
              h="4px"
              bgGradient="linear(to-r, purple.500, blue.500)"
            />
            
            <Icon as={FiAward} boxSize={12} color="yellow.400" />
            
            <Text
              fontSize="xl"
              fontWeight="bold"
              bgGradient="linear(to-r, purple.500, blue.500)"
              bgClip="text"
            >
              Achievement Unlocked!
            </Text>
            
            <Text fontSize="lg" fontWeight="medium">
              {achievement.title}
            </Text>
            
            <Text color="gray.600" textAlign="center">
              {achievement.description}
            </Text>
            
            <Text
              fontSize="sm"
              color="purple.500"
              fontWeight="bold"
            >
              +{achievement.points} Points
            </Text>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}