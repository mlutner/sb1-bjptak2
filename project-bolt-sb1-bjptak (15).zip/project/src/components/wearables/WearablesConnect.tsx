import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Icon,
  Menu,
  MenuButton,
  MenuItem,
  MenuList,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';
import { FiWatch, FiChevronDown, FiActivity, FiHeart, FiMoon } from 'react-icons/fi';
import { useWearables } from '../../hooks/useWearables';
import type { WearableProvider } from '../../types/wearables';

const PROVIDERS: { id: WearableProvider; name: string; icon: any }[] = [
  { id: 'fitbit', name: 'Fitbit', icon: FiWatch },
  { id: 'garmin', name: 'Garmin', icon: FiActivity },
  { id: 'apple', name: 'Apple Health', icon: FiHeart },
];

export default function WearablesConnect() {
  const { connections, isConnecting, metrics, connect, disconnect } = useWearables();
  const toast = useToast();

  const handleConnect = async (provider: WearableProvider) => {
    try {
      await connect(provider);
    } catch (error) {
      toast({
        title: 'Connection Failed',
        description: 'Unable to connect to device. Please try again.',
        status: 'error',
        duration: 5000,
      });
    }
  };

  const connectedDevice = connections[0];

  return (
    <Card>
      <CardHeader>
        <Heading size="md">Connect Your Wearable</Heading>
        <Text color="gray.600" mt={2}>
          Sync your wearable device to track stress and wellness metrics
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          {connectedDevice ? (
            <Card
              variant="outline"
              borderColor="green.200"
            >
              <CardBody>
                <VStack spacing={4}>
                  <Icon 
                    as={PROVIDERS.find(p => p.id === connectedDevice.provider)?.icon} 
                    boxSize={8} 
                    color="green.500" 
                  />
                  <Text fontWeight="medium">
                    {PROVIDERS.find(p => p.id === connectedDevice.provider)?.name} Connected
                  </Text>
                  <Button
                    colorScheme="red"
                    variant="outline"
                    onClick={() => disconnect(connectedDevice.provider)}
                    w="full"
                  >
                    Disconnect Device
                  </Button>
                </VStack>
              </CardBody>
            </Card>
          ) : (
            <Menu>
              <MenuButton
                as={Button}
                colorScheme="purple"
                size="lg"
                rightIcon={<FiChevronDown />}
                isLoading={isConnecting}
                w="full"
              >
                Connect Device
              </MenuButton>
              <MenuList>
                {PROVIDERS.map((provider) => (
                  <MenuItem
                    key={provider.id}
                    icon={<Icon as={provider.icon} />}
                    onClick={() => handleConnect(provider.id)}
                  >
                    {provider.name}
                  </MenuItem>
                ))}
              </MenuList>
            </Menu>
          )}

          {metrics && (
            <Card bg="purple.50" p={4}>
              <Flex justify="space-between" wrap="wrap" gap={4}>
                <Box>
                  <Flex align="center" gap={2}>
                    <Icon as={FiHeart} color="red.500" />
                    <Text fontWeight="medium">Heart Rate</Text>
                  </Flex>
                  <Text fontSize="2xl">{metrics.heartRate} BPM</Text>
                </Box>

                <Box>
                  <Flex align="center" gap={2}>
                    <Icon as={FiActivity} color="green.500" />
                    <Text fontWeight="medium">Steps</Text>
                  </Flex>
                  <Text fontSize="2xl">{metrics.steps}</Text>
                </Box>

                <Box>
                  <Flex align="center" gap={2}>
                    <Icon as={FiMoon} color="blue.500" />
                    <Text fontWeight="medium">Sleep Quality</Text>
                  </Flex>
                  <Text fontSize="2xl">{metrics.sleepQuality}%</Text>
                </Box>
              </Flex>
            </Card>
          )}
        </VStack>
      </CardBody>
    </Card>
  );
}