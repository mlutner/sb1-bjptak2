import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Grid,
  Heading,
  Image,
  Text,
  VStack,
  Icon,
  Flex,
  Progress,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  useDisclosure,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { FiPlay, FiArrowRight } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';
import AudioPlayer from '../AudioPlayer';
import VideoLesson from './VideoLesson';
import EmotionalAwarenessExercise from './exercises/EmotionalAwarenessExercise';

interface Props {
  onComplete?: () => void;
}

export default function Module1Intro({ onComplete }: Props) {
  const [currentStep, setCurrentStep] = useState(0);
  const steps = ['intro', 'video', 'exercise', 'reflection'];
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();
  const toast = useToast();

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      onOpen();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const handleModuleComplete = () => {
    onClose();
    toast({
      title: "Module 1 Completed!",
      description: "Great job! You can now proceed to Module 2.",
      status: "success",
      duration: 5000,
    });
    navigate('/cbt-program/module/2');
  };

  const renderStep = () => {
    switch (steps[currentStep]) {
      case 'intro':
        return (
          <VStack spacing={6} align="stretch">
            <Box
              h="300px"
              overflow="hidden"
              borderRadius="xl"
              position="relative"
            >
              <Image
                src="https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80"
                alt="Financial Goals"
                objectFit="cover"
                w="full"
                h="full"
              />
              {/* Overlay */}
              <Box
                position="absolute"
                top={0}
                left={0}
                right={0}
                bottom={0}
                bg="blackAlpha.600"
                p={6}
                display="flex"
                flexDirection="column"
                justifyContent="flex-end"
              >
                <Heading color="white" size="lg" mb={2}>
                  Goal Setting & Initial Assessment
                </Heading>
                <Text color="whiteAlpha.900">
                  Module 1: Establish your financial wellness baseline
                </Text>
              </Box>
            </Box>

            <AudioPlayer 
              title="Introduction to Goal Setting" 
              duration="2:30"
            />

            <Text>
              Welcome to Module 1: Goal Setting & Initial Assessment. In this module,
              we'll establish your financial wellness baseline and set clear, achievable goals
              for your journey.
            </Text>
          </VStack>
        );

      case 'video':
        return (
          <Box position="relative">
            <VideoLesson
              moduleId={1}
              onComplete={handleNext}
            />
            <Flex
              position="absolute"
              top="50%"
              left="50%"
              transform="translate(-50%, -50%)"
              bg="blackAlpha.700"
              rounded="full"
              p={4}
              color="white"
              fontSize="3xl"
            >
              <Icon as={FiPlay} />
            </Flex>
          </Box>
        );

      case 'exercise':
        return (
          <EmotionalAwarenessExercise
            onComplete={handleNext}
          />
        );

      case 'reflection':
        return (
          <VStack spacing={6} align="stretch">
            <Heading size="md">Module Reflection</Heading>
            <Text>
              Congratulations on completing the first module! Take a moment to reflect
              on what you've learned and set your intentions for the next steps.
            </Text>
          </VStack>
        );

      default:
        return null;
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <VStack align="stretch" spacing={4}>
            <Heading size="lg">Goal Setting & Initial Assessment</Heading>
            <Text color="gray.600">
              Module 1: Establish your financial wellness baseline
            </Text>
            <Progress 
              value={(currentStep + 1) / steps.length * 100} 
              size="sm" 
              colorScheme="purple" 
              borderRadius="full" 
            />
          </VStack>
        </CardHeader>

        <CardBody>
          {renderStep()}

          <Grid templateColumns="repeat(2, 1fr)" gap={4} mt={6}>
            <Button
              onClick={handlePrevious}
              isDisabled={currentStep === 0}
              variant="outline"
            >
              Previous
            </Button>
            <Button
              onClick={handleNext}
              colorScheme="purple"
            >
              {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
            </Button>
          </Grid>
        </CardBody>
      </Card>

      {/* Completion Modal */}
      <Modal isOpen={isOpen} onClose={onClose} isCentered>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Module 1 Complete!</ModalHeader>
          <ModalBody>
            <VStack spacing={6} align="stretch">
              <Box bg="green.50" p={4} borderRadius="lg">
                <Flex align="center" gap={3}>
                  <Icon as={FiPlay} color="green.500" boxSize={6} />
                  <VStack align="start" spacing={1}>
                    <Text fontWeight="medium">Great Progress!</Text>
                    <Text fontSize="sm" color="gray.600">
                      You've completed Module 1: Goal Setting & Initial Assessment
                    </Text>
                  </VStack>
                </Flex>
              </Box>

              <Box>
                <Text fontWeight="medium" mb={2}>Next Up: Module 2</Text>
                <Text color="gray.600">
                  Continue your journey by exploring emotional aspects of financial decisions in Module 2.
                </Text>
              </Box>
            </VStack>
          </ModalBody>

          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={onClose}>
              Review Module 1
            </Button>
            <Button
              colorScheme="purple"
              rightIcon={<FiArrowRight />}
              onClick={handleModuleComplete}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Continue to Module 2
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
}