import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  Select,
  NumberInput,
  NumberInputField,
  Grid,
  GridItem,
  Progress,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: () => void;
}

interface SpendingEntry {
  date: string;
  amount: string;
  category: string;
  emotion: string;
  trigger: string;
  needWant: 'need' | 'want';
  satisfaction: string;
}

const initialEntry: SpendingEntry = {
  date: '',
  amount: '',
  category: '',
  emotion: '',
  trigger: '',
  needWant: 'want',
  satisfaction: ''
};

export default function EmotionalSpendingLog({ onComplete }: Props) {
  const [entries, setEntries] = useState<SpendingEntry[]>([initialEntry]);
  const toast = useToast();

  const handleEntryChange = (index: number, field: keyof SpendingEntry, value: string) => {
    const newEntries = [...entries];
    newEntries[index] = { ...newEntries[index], [field]: value };
    setEntries(newEntries);
  };

  const addEntry = () => {
    setEntries([...entries, { ...initialEntry }]);
  };

  const handleSubmit = () => {
    if (entries.some(entry => Object.values(entry).some(value => !value))) {
      toast({
        title: 'Please complete all fields',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onComplete();
  };

  const progress = (entries.reduce((acc, entry) => 
    acc + Object.values(entry).filter(Boolean).length, 0
  ) / (entries.length * 7)) * 100;

  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text mb={2}>Log Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      {entries.map((entry, index) => (
        <Grid key={index} templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={4}>
          <GridItem>
            <FormControl>
              <FormLabel>Date</FormLabel>
              <Input
                type="date"
                value={entry.date}
                onChange={(e) => handleEntryChange(index, 'date', e.target.value)}
              />
            </FormControl>
          </GridItem>

          <GridItem>
            <FormControl>
              <FormLabel>Amount</FormLabel>
              <NumberInput>
                <NumberInputField
                  value={entry.amount}
                  onChange={(e) => handleEntryChange(index, 'amount', e.target.value)}
                />
              </NumberInput>
            </FormControl>
          </GridItem>

          <GridItem>
            <FormControl>
              <FormLabel>Category</FormLabel>
              <Select
                value={entry.category}
                onChange={(e) => handleEntryChange(index, 'category', e.target.value)}
              >
                <option value="">Select category</option>
                <option value="food">Food</option>
                <option value="shopping">Shopping</option>
                <option value="entertainment">Entertainment</option>
                <option value="other">Other</option>
              </Select>
            </FormControl>
          </GridItem>

          <GridItem>
            <FormControl>
              <FormLabel>Emotion</FormLabel>
              <Select
                value={entry.emotion}
                onChange={(e) => handleEntryChange(index, 'emotion', e.target.value)}
              >
                <option value="">Select emotion</option>
                <option value="happy">Happy</option>
                <option value="stressed">Stressed</option>
                <option value="anxious">Anxious</option>
                <option value="bored">Bored</option>
              </Select>
            </FormControl>
          </GridItem>

          <GridItem colSpan={{ base: 1, md: 2 }}>
            <FormControl>
              <FormLabel>What triggered this purchase?</FormLabel>
              <Input
                value={entry.trigger}
                onChange={(e) => handleEntryChange(index, 'trigger', e.target.value)}
                placeholder="What led to this purchase?"
              />
            </FormControl>
          </GridItem>

          <GridItem>
            <FormControl>
              <FormLabel>Need or Want?</FormLabel>
              <Select
                value={entry.needWant}
                onChange={(e) => handleEntryChange(index, 'needWant', e.target.value as 'need' | 'want')}
              >
                <option value="need">Need</option>
                <option value="want">Want</option>
              </Select>
            </FormControl>
          </GridItem>

          <GridItem>
            <FormControl>
              <FormLabel>Satisfaction Level (1-10)</FormLabel>
              <NumberInput min={1} max={10}>
                <NumberInputField
                  value={entry.satisfaction}
                  onChange={(e) => handleEntryChange(index, 'satisfaction', e.target.value)}
                />
              </NumberInput>
            </FormControl>
          </GridItem>
        </Grid>
      ))}

      <Button variant="outline" onClick={addEntry}>
        Add Another Entry
      </Button>

      <Button colorScheme="purple" onClick={handleSubmit}>
        Complete Log
      </Button>
    </VStack>
  );
}