import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  Textarea,
  Progress,
  Grid,
  GridItem,
  Checkbox,
  CheckboxGroup,
  Stack,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: () => void;
}

export default function CopingStrategiesWorksheet({ onComplete }: Props) {
  const [strategies, setStrategies] = useState({
    currentStrategies: [],
    effectiveness: '',
    healthyAlternatives: '',
    supportSystem: '',
    preventionPlan: '',
    commitments: ''
  });

  const isComplete = 
    strategies.currentStrategies.length > 0 &&
    Object.values(strategies).every(value => 
      Array.isArray(value) ? value.length > 0 : value.trim() !== ''
    );

  const progress = (
    (strategies.currentStrategies.length > 0 ? 1 : 0) +
    Object.values(strategies).filter(value => 
      !Array.isArray(value) && value.trim() !== ''
    ).length
  ) / 6 * 100;

  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text mb={2}>Worksheet Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
        <GridItem colSpan={{ base: 1, md: 2 }}>
          <FormControl>
            <FormLabel>Current coping strategies:</FormLabel>
            <CheckboxGroup
              value={strategies.currentStrategies}
              onChange={(value) => setStrategies({ ...strategies, currentStrategies: value as string[] })}
            >
              <Stack spacing={3}>
                <Checkbox value="shopping">Retail therapy</Checkbox>
                <Checkbox value="avoidance">Avoiding financial tasks</Checkbox>
                <Checkbox value="impulsive">Impulsive spending</Checkbox>
                <Checkbox value="borrowing">Borrowing money</Checkbox>
                <Checkbox value="other">Other</Checkbox>
              </Stack>
            </CheckboxGroup>
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>How effective are these strategies?</FormLabel>
            <Textarea
              value={strategies.effectiveness}
              onChange={(e) => setStrategies({ ...strategies, effectiveness: e.target.value })}
              placeholder="Rate their effectiveness..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Healthier alternatives:</FormLabel>
            <Textarea
              value={strategies.healthyAlternatives}
              onChange={(e) => setStrategies({ ...strategies, healthyAlternatives: e.target.value })}
              placeholder="List better coping strategies..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Support system:</FormLabel>
            <Textarea
              value={strategies.supportSystem}
              onChange={(e) => setStrategies({ ...strategies, supportSystem: e.target.value })}
              placeholder="Who can help you?"
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Prevention plan:</FormLabel>
            <Textarea
              value={strategies.preventionPlan}
              onChange={(e) => setStrategies({ ...strategies, preventionPlan: e.target.value })}
              placeholder="How will you prevent triggers?"
            />
          </FormControl>
        </GridItem>

        <GridItem colSpan={{ base: 1, md: 2 }}>
          <FormControl>
            <FormLabel>Commitments and next steps:</FormLabel>
            <Textarea
              value={strategies.commitments}
              onChange={(e) => setStrategies({ ...strategies, commitments: e.target.value })}
              placeholder="What specific actions will you take?"
            />
          </FormControl>
        </GridItem>
      </Grid>

      <Button
        colorScheme="purple"
        onClick={onComplete}
        isDisabled={!isComplete}
      >
        Complete Worksheet
      </Button>
    </VStack>
  );
}