import { useState, useEffect } from 'react';
// ... rest of imports remain the same

export default function TriggerIdentificationExercise({ onComplete }: Props) {
  // ... other state and handlers remain the same

  // Scroll to top when component mounts
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  // ... rest of the component remains the same
}