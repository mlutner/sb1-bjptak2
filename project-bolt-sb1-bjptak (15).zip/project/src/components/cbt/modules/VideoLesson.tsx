import { useState } from 'react';
import { Box, VStack } from '@chakra-ui/react';
import LMSVideoPlayer from '../../../lib/lms/videoPlayer';
import { lmsApi } from '../../../lib/lms/api';
import type { VideoContent } from '../../../lib/lms/config';

interface Props {
  moduleId: number;
  onComplete: () => void;
}

export default function VideoLesson({ moduleId, onComplete }: Props) {
  const [content, setContent] = useState<VideoContent | null>(null);

  // Fetch video content from LMS
  useState(() => {
    const loadContent = async () => {
      try {
        const moduleContent = await lmsApi.getModuleContent(moduleId);
        if (moduleContent.length > 0) {
          setContent(moduleContent[0]); // Get first video
        }
      } catch (error) {
        console.error('Error loading video content:', error);
      }
    };
    loadContent();
  }, [moduleId]);

  const handleComplete = async () => {
    if (content) {
      await lmsApi.trackProgress(content.id, 100);
    }
    onComplete();
  };

  if (!content) {
    return null;
  }

  return (
    <VStack spacing={6} align="stretch">
      <Box bg="gray.900" rounded="lg" overflow="hidden">
        <LMSVideoPlayer 
          content={content}
          onComplete={handleComplete}
        />
      </Box>
    </VStack>
  );
}