import {
  Box,
  Card,
  Grid,
  Heading,
  Text,
  Flex,
  Icon,
} from '@chakra-ui/react';
import { FiTarget, FiTrendingUp, FiCheckCircle, FiClock, FiLink } from 'react-icons/fi';

const SMART_CRITERIA = [
  {
    letter: 'S',
    word: 'Specific',
    description: 'Clear and well-defined goals',
    icon: FiTarget
  },
  {
    letter: 'M',
    word: 'Measurable',
    description: 'Quantifiable progress indicators',
    icon: FiTrendingUp
  },
  {
    letter: 'A',
    word: 'Achievable',
    description: 'Realistic and attainable',
    icon: FiCheckCircle
  },
  {
    letter: 'R',
    word: 'Relevant',
    description: 'Aligned with your values',
    icon: FiLink
  },
  {
    letter: 'T',
    word: 'Time-bound',
    description: 'Set deadlines and milestones',
    icon: FiClock
  }
];

export default function SmartCriteria() {
  return (
    <Card variant="outline" p={6}>
      <Heading size="sm" mb={4}>SMART Goal Criteria</Heading>
      <Grid templateColumns={{ base: "1fr", md: "repeat(2, 1fr)", lg: "repeat(5, 1fr)" }} gap={6}>
        {SMART_CRITERIA.map(({ letter, word, description, icon }) => (
          <Card
            key={letter}
            p={4}
            variant="outline"
            _hover={{
              borderColor: 'purple.500',
              transform: 'translateY(-2px)',
              shadow: 'md'
            }}
            transition="all 0.2s"
          >
            <Flex gap={3}>
              <Box
                bg="purple.100"
                color="purple.700"
                p={2}
                borderRadius="lg"
                fontSize="lg"
                display="flex"
                alignItems="center"
                justifyContent="center"
              >
                <Icon as={icon} boxSize={5} />
              </Box>
              <Box>
                <Text fontWeight="bold" color="purple.700" mb={1}>
                  {letter} - {word}
                </Text>
                <Text fontSize="sm" color="gray.600">
                  {description}
                </Text>
              </Box>
            </Flex>
          </Card>
        ))}
      </Grid>
    </Card>
  );
}