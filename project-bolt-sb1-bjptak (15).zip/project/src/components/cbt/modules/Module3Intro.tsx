import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Grid,
  Heading,
  Image,
  Text,
  VStack,
  Icon,
  Flex,
  Progress,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  useDisclosure,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiPlay, FiArrowRight } from 'react-icons/fi';
import AudioPlayer from '../AudioPlayer';
import VideoLesson from './VideoLesson';
import TriggerIdentificationExercise from './exercises/TriggerIdentificationExercise';
import SpendingPatternAnalysis from './exercises/SpendingPatternAnalysis';

interface Props {
  onComplete?: () => void;
}

export default function Module3Intro({ onComplete }: Props) {
  const [currentStep, setCurrentStep] = useState(0);
  const steps = ['intro', 'video', 'triggers', 'patterns'];
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();
  const toast = useToast();

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      onOpen();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const handleModuleComplete = () => {
    onClose();
    toast({
      title: "Module 3 Completed!",
      description: "Great job! You can now proceed to Module 4.",
      status: "success",
      duration: 5000,
    });
    navigate('/cbt-program/module/4');
  };

  const renderStep = () => {
    switch (steps[currentStep]) {
      case 'intro':
        return (
          <VStack spacing={6} align="stretch">
            <Box
              h="300px"
              overflow="hidden"
              borderRadius="xl"
              position="relative"
            >
              <Image
                src="https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&q=80"
                alt="Identifying Triggers"
                objectFit="cover"
                w="full"
                h="full"
              />
              <Box
                position="absolute"
                top={0}
                left={0}
                right={0}
                bottom={0}
                bg="blackAlpha.600"
                p={6}
                display="flex"
                flexDirection="column"
                justifyContent="flex-end"
              >
                <Heading color="white" size="lg" mb={2}>
                  Identifying Triggers
                </Heading>
                <Text color="whiteAlpha.900">
                  Module 3: Recognize patterns in financial behavior
                </Text>
              </Box>
            </Box>

            <AudioPlayer 
              title="Understanding Financial Triggers" 
              duration="2:45"
            />

            <Text>
              Welcome to Module 3: Identifying Triggers. In this module,
              we'll help you recognize patterns in your financial behavior
              and identify what triggers certain spending habits.
            </Text>
          </VStack>
        );

      case 'video':
        return (
          <Box position="relative">
            <VideoLesson
              moduleId={3}
              onComplete={handleNext}
            />
            <Flex
              position="absolute"
              top="50%"
              left="50%"
              transform="translate(-50%, -50%)"
              bg="blackAlpha.700"
              rounded="full"
              p={4}
              color="white"
              fontSize="3xl"
            >
              <Icon as={FiPlay} />
            </Flex>
          </Box>
        );

      case 'triggers':
        return (
          <TriggerIdentificationExercise
            onComplete={handleNext}
          />
        );

      case 'patterns':
        return (
          <SpendingPatternAnalysis
            onComplete={handleNext}
          />
        );

      default:
        return null;
    }
  };

  return (
    <>
      <Card>
        <CardHeader>
          <VStack align="stretch" spacing={4}>
            <Heading size="lg">Identifying Triggers</Heading>
            <Text color="gray.600">
              Module 3: Recognize patterns in financial behavior
            </Text>
            <Progress 
              value={(currentStep + 1) / steps.length * 100} 
              size="sm" 
              colorScheme="purple" 
              borderRadius="full" 
            />
          </VStack>
        </CardHeader>

        <CardBody>
          {renderStep()}

          <Grid templateColumns="repeat(2, 1fr)" gap={4} mt={6}>
            <Button
              onClick={handlePrevious}
              isDisabled={currentStep === 0}
              variant="outline"
            >
              Previous
            </Button>
            <Button
              onClick={handleNext}
              colorScheme="purple"
            >
              {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
            </Button>
          </Grid>
        </CardBody>
      </Card>

      {/* Completion Modal */}
      <Modal isOpen={isOpen} onClose={onClose} isCentered>
        <ModalOverlay />
        <ModalContent>
          <ModalHeader>Module 3 Complete!</ModalHeader>
          <ModalBody>
            <VStack spacing={6} align="stretch">
              <Box bg="green.50" p={4} borderRadius="lg">
                <Flex align="center" gap={3}>
                  <Icon as={FiPlay} color="green.500" boxSize={6} />
                  <VStack align="start" spacing={1}>
                    <Text fontWeight="medium">Great Progress!</Text>
                    <Text fontSize="sm" color="gray.600">
                      You've completed Module 3: Identifying Triggers
                    </Text>
                  </VStack>
                </Flex>
              </Box>

              <Box>
                <Text fontWeight="medium" mb={2}>Next Up: Module 4</Text>
                <Text color="gray.600">
                  Continue your journey by learning about developing coping strategies.
                </Text>
              </Box>
            </VStack>
          </ModalBody>

          <ModalFooter>
            <Button variant="ghost" mr={3} onClick={onClose}>
              Review Module 3
            </Button>
            <Button
              colorScheme="purple"
              rightIcon={<FiArrowRight />}
              onClick={handleModuleComplete}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Continue to Module 4
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
}