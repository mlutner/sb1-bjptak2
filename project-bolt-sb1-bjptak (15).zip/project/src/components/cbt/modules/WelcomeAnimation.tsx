import { useState, useEffect } from 'react';
import {
  Box,
  Button,
  VStack,
  Text,
  useBreakpointValue,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { Player } from '@lottiefiles/react-lottie-player';

interface Props {
  onComplete: () => void;
}

const animations = [
  {
    id: 'intro',
    src: 'https://assets9.lottiefiles.com/packages/lf20_jvg7qk0w.json',
    message: "Welcome to your financial wellness journey",
    duration: 3000
  },
  {
    id: 'growth',
    src: 'https://assets5.lottiefiles.com/packages/lf20_olomspnz.json',
    message: "Let's grow and learn together",
    duration: 3000
  },
  {
    id: 'success',
    src: 'https://assets6.lottiefiles.com/packages/lf20_qdbb21wb.json',
    message: "Ready to begin your transformation",
    duration: 3000
  }
];

export default function WelcomeAnimation({ onComplete }: Props) {
  const [currentScene, setCurrentScene] = useState(0);
  const [isPlaying, setIsPlaying] = useState(true);
  const size = useBreakpointValue({ base: '250px', md: '400px' });

  useEffect(() => {
    if (!isPlaying) return;

    const timer = setTimeout(() => {
      if (currentScene < animations.length - 1) {
        setCurrentScene(prev => prev + 1);
      } else {
        setIsPlaying(false);
      }
    }, animations[currentScene].duration);

    return () => clearTimeout(timer);
  }, [currentScene, isPlaying]);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
    >
      <VStack spacing={8} align="center" py={8}>
        <motion.div
          key={currentScene}
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          exit={{ scale: 0.8, opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <Box w={size} h={size}>
            <Player
              autoplay
              keepLastFrame
              src={animations[currentScene].src}
              style={{ width: '100%', height: '100%' }}
            />
          </Box>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.3 }}
        >
          <Text
            fontSize="2xl"
            fontWeight="medium"
            color="gray.700"
            textAlign="center"
          >
            {animations[currentScene].message}
          </Text>
        </motion.div>

        {!isPlaying && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.5 }}
          >
            <Button
              colorScheme="purple"
              size="lg"
              onClick={onComplete}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
                transform: "translateY(-2px)",
              }}
              shadow="md"
              px={8}
            >
              Begin Your Journey
            </Button>
          </motion.div>
        )}
      </VStack>
    </motion.div>
  );
}