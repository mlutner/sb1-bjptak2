import { config } from './config';

interface ModelSelection {
  provider: 'openai' | 'huggingface';
  model: string;
  temperature: number;
}

// Cost-effective model selection strategy
export function selectModel(prompt: string): ModelSelection {
  // Use Hugging Face for simpler queries (cost optimization)
  const isSimpleQuery = (
    prompt.length < 100 && 
    !prompt.includes('?') &&
    !prompt.toLowerCase().includes('explain') &&
    !prompt.toLowerCase().includes('analyze')
  );

  if (isSimpleQuery && config.huggingface.available) {
    return {
      provider: 'huggingface',
      model: config.huggingface.defaultModel,
      temperature: 0.7
    };
  }

  // Use OpenAI for more complex queries
  return {
    provider: 'openai',
    model: 'gpt-3.5-turbo',
    temperature: 0.7
  };
}