// Simple in-memory cache implementation
const cache = new Map<string, any>();

export async function getCachedResponse(key: string): Promise<any> {
  return cache.get(key) || null;
}

export async function cacheResponse(key: string, response: any): Promise<void> {
  cache.set(key, response);
}