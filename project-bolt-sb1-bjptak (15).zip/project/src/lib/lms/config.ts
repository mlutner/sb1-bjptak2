import { z } from 'zod';

export const LMSConfig = {
  moodle: {
    baseUrl: import.meta.env.VITE_MOODLE_API_URL || '',
    token: import.meta.env.VITE_MOODLE_TOKEN || '',
  },
  canvas: {
    baseUrl: import.meta.env.VITE_CANVAS_API_URL || '',
    token: import.meta.env.VITE_CANVAS_TOKEN || '',
  }
};

export const VideoContentSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  url: z.string().url(),
  duration: z.number(),
  provider: z.enum(['moodle', 'canvas', 'vimeo', 'youtube']),
  moduleId: z.number(),
});

export type VideoContent = z.infer<typeof VideoContentSchema>;