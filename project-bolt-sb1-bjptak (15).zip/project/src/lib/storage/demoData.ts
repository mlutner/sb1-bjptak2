export const DEFAULT_USER = {
  id: 'demo-user',
  email: 'demo@finwell.com',
  name: 'Demo User'
};

export const DEFAULT_PREFERENCES = {
  onboardingCompleted: false,
  isFirstTimeUser: true,
  theme: 'light',
  notifications: true,
};

export const DEMO_DATA = {
  preferences: DEFAULT_PREFERENCES,
  userId: DEFAULT_USER.id,
  createdAt: new Date().toISOString()
};