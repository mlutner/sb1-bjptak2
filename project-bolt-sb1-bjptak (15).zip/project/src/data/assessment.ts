import { AssessmentStep } from '../types/assessment';

export const assessmentQuestions = [
  {
    id: 'financial_stress',
    question: 'How would you rate your current level of financial stress?',
    options: [
      { id: 'high', label: 'High - It affects my daily life and well-being' },
      { id: 'moderate', label: 'Moderate - I worry about finances occasionally' },
      { id: 'low', label: 'Low - I feel generally in control of my finances' }
    ]
  },
  {
    id: 'primary_goal',
    question: "What's your primary financial goal right now?",
    options: [
      { id: 'debt', label: 'Managing or reducing debt' },
      { id: 'savings', label: 'Building savings and emergency fund' },
      { id: 'investing', label: 'Learning about investing and growth' },
      { id: 'budgeting', label: 'Creating and sticking to a budget' }
    ]
  },
  {
    id: 'support_preference',
    question: "What type of support would you find most helpful?",
    options: [
      { id: 'self_guided', label: 'Self-guided with digital tools' },
      { id: 'therapy', label: 'One-on-one therapy sessions' },
      { id: 'group', label: 'Group workshops and peer support' },
      { id: 'mixed', label: 'Combination of different support types' }
    ]
  }
];

export const programBenefits = [
  {
    id: 'wellness',
    title: "Financial Wellness",
    description: "Learn to manage money stress and build healthy financial habits",
    metrics: "78% of participants report reduced financial anxiety"
  },
  {
    id: 'support',
    title: "Professional Support",
    description: "Access to financial therapists and AI-powered guidance",
    metrics: "24/7 support available through our platform"
  },
  {
    id: 'tools',
    title: "Practical Tools",
    description: "Interactive budgeting, mood tracking, and spending analysis",
    metrics: "Average 15% improvement in financial confidence"
  }
];