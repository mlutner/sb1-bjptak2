import { defineStyleConfig } from '@chakra-ui/react';

export const components = {
  Button: defineStyleConfig({
    baseStyle: {
      fontWeight: 'medium',
      borderRadius: 'lg',
    },
    variants: {
      solid: {
        bg: 'purple.500',
        color: 'white',
        _hover: {
          bg: 'purple.600',
        },
      },
      outline: {
        borderColor: 'purple.500',
        color: 'purple.500',
      },
      ghost: {
        color: 'gray.600',
        _hover: {
          bg: 'purple.50',
        },
      },
    },
    defaultProps: {
      size: 'md',
      variant: 'solid',
    },
  }),

  Card: defineStyleConfig({
    baseStyle: {
      container: {
        bg: 'white',
        borderRadius: 'lg',
        overflow: 'hidden',
      },
      header: {
        p: 6,
      },
      body: {
        p: 6,
      },
      footer: {
        p: 6,
      },
    },
  }),

  Heading: defineStyleConfig({
    baseStyle: {
      fontWeight: 'bold',
      color: 'gray.900',
    },
  }),

  Input: defineStyleConfig({
    baseStyle: {
      field: {
        borderRadius: 'lg',
      },
    },
    defaultProps: {
      focusBorderColor: 'purple.500',
    },
  }),

  Select: defineStyleConfig({
    baseStyle: {
      field: {
        borderRadius: 'lg',
      },
    },
    defaultProps: {
      focusBorderColor: 'purple.500',
    },
  }),

  Textarea: defineStyleConfig({
    baseStyle: {
      borderRadius: 'lg',
    },
    defaultProps: {
      focusBorderColor: 'purple.500',
    },
  }),
};