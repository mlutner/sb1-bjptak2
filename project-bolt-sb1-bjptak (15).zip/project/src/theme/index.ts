import { extendTheme } from '@chakra-ui/react';
import { colors } from './colors';
import { components } from './components';
import { typography } from './typography';

const theme = extendTheme({
  colors,
  components,
  ...typography,
  styles: {
    global: {
      body: {
        bg: 'gray.50',
        color: 'gray.900',
      },
    },
  },
  sizes: {
    container: {
      sm: '640px',
      md: '768px',
      lg: '1024px',
      xl: '1280px',
    },
  },
  space: {
    section: '2rem',
    element: '1.5rem',
  },
});

export default theme;