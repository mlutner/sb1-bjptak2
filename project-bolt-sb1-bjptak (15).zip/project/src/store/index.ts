import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { createUISlice, UISlice } from './slices/uiSlice';
import { createMoodSlice, MoodSlice } from './slices/moodSlice';
import { createAuthSlice, AuthSlice } from './slices/authSlice';

interface StoreState extends UISlice, MoodSlice, AuthSlice {}

export const useStore = create<StoreState>()(
  persist(
    (...a) => ({
      ...createUISlice(...a),
      ...createMoodSlice(...a),
      ...createAuthSlice(...a),
    }),
    {
      name: 'finwell-store',
      partialize: (state) => ({
        theme: state.theme,
        user: state.user,
        isAuthenticated: state.isAuthenticated,
        lastTrackedDate: state.lastTrackedDate,
      }),
    }
  )
);