import { StateCreator } from 'zustand';
import { MoodEntry } from '../../types/mood';

export interface MoodSlice {
  entries: MoodEntry[];
  lastTrackedDate: string | null;
  addEntry: (entry: MoodEntry) => void;
  hasTrackedToday: () => boolean;
}

export const createMoodSlice: StateCreator<MoodSlice> = (set, get) => ({
  entries: [],
  lastTrackedDate: null,
  
  addEntry: (entry) => set((state) => ({
    entries: [entry, ...state.entries],
    lastTrackedDate: new Date().toISOString().split('T')[0]
  })),
  
  hasTrackedToday: () => {
    const { lastTrackedDate } = get();
    if (!lastTrackedDate) return false;
    const today = new Date().toISOString().split('T')[0];
    return lastTrackedDate === today;
  }
});