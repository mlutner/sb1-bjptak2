import { StateCreator } from 'zustand';
import { DEFAULT_USER } from '../../lib/storage/demoData';

export interface User {
  id: string;
  email: string;
  name: string;
}

export interface AuthSlice {
  user: User | null;
  isAuthenticated: boolean;
  login: () => void;
  logout: () => void;
}

export const createAuthSlice: StateCreator<AuthSlice> = (set) => ({
  user: null,
  isAuthenticated: false,
  login: () => set({
    user: DEFAULT_USER,
    isAuthenticated: true
  }),
  logout: () => set({ user: null, isAuthenticated: false })
});