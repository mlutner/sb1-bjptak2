import { Box } from '@chakra-ui/react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Budget from './pages/Budget';
import Transactions from './pages/Transactions';
import Assessment from './pages/Assessment';
import CBTProgram from './pages/CBTProgram';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';
import OnboardingFlow from './components/onboarding/OnboardingFlow';
import AuthWrapper from './components/auth/AuthWrapper';
import Calendar from './pages/Calendar';
import Savings from './pages/Savings';
import AdminDashboard from './pages/AdminDashboard';
import Goals from './pages/Goals';
import Expenses from './pages/Expenses';
import Achievements from './pages/Achievements';
import Module1Intro from './components/cbt/modules/Module1Intro';
import Module2Intro from './components/cbt/modules/Module2Intro';
import Module3Intro from './components/cbt/modules/Module3Intro';
import ProgramOverview from './components/cbt/modules/ProgramOverview';

export default function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <Box minH="100vh" bg="gray.50">
            <Routes>
              <Route path="/signin" element={<SignIn />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/onboarding" element={<OnboardingFlow />} />
              <Route path="/assessment" element={<Assessment />} />
              <Route
                path="/*"
                element={
                  <AuthWrapper>
                    <Layout>
                      <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/budget" element={<Budget />} />
                        <Route path="/transactions" element={<Transactions />} />
                        <Route path="/cbt-program" element={<ProgramOverview />} />
                        <Route path="/cbt-program/module/1" element={<Module1Intro />} />
                        <Route path="/cbt-program/module/2" element={<Module2Intro />} />
                        <Route path="/cbt-program/module/3" element={<Module3Intro />} />
                        <Route path="/calendar" element={<Calendar />} />
                        <Route path="/savings" element={<Savings />} />
                        <Route path="/admin" element={<AdminDashboard />} />
                        <Route path="/goals" element={<Goals />} />
                        <Route path="/expenses" element={<Expenses />} />
                        <Route path="/achievements" element={<Achievements />} />
                        <Route path="*" element={<Navigate to="/" />} />
                      </Routes>
                    </Layout>
                  </AuthWrapper>
                }
              />
            </Routes>
          </Box>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}