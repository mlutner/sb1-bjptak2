export interface Goal {
  type: string;
  timeframe: string;
  description: string;
  target: string;
  steps: string[];
  obstacles: string[];
  support: string[];
  metrics: string;
}