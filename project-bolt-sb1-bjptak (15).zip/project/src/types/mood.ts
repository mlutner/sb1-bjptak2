export type MoodType = 'great' | 'good' | 'neutral' | 'low' | 'bad';

export interface MoodEntry {
  id: string;
  timestamp: string;
  mood: MoodType;
  note?: string;
  wearableMetrics?: {
    sleepQuality?: number;
    sleepHours?: number;
    heartRate?: number;
    stressScore?: number;
  };
}