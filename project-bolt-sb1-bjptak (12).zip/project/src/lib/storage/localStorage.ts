import localforage from 'localforage';
import { DEFAULT_USER, DEMO_DATA } from './demoData';

// Configure localforage
localforage.config({
  name: 'finwell',
  storeName: 'app_cache',
  version: 1.0,
  description: 'FinWell application cache',
  driver: [
    localforage.INDEXEDDB,
    localforage.WEBSQL,
    localforage.LOCALSTORAGE
  ],
  size: 4980736 // 4.75MB
});

export async function getStoredData(key: string): Promise<any> {
  try {
    const data = await localforage.getItem(key);
    return data || null;
  } catch (error) {
    console.error('Error getting stored data:', error);
    return null;
  }
}

export async function setStoredData(key: string, value: any): Promise<void> {
  try {
    await localforage.setItem(key, value);
  } catch (error) {
    console.error('Error setting stored data:', error);
  }
}

export async function removeStoredData(key: string): Promise<void> {
  try {
    await localforage.removeItem(key);
  } catch (error) {
    console.error('Error removing stored data:', error);
  }
}

export async function getUserPreferences(userId: string = DEFAULT_USER.id) {
  const key = `preferences_${userId}`;
  const stored = await getStoredData(key);
  
  if (!stored) {
    await setStoredData(key, DEMO_DATA);
    return DEMO_DATA;
  }
  
  return stored;
}

export async function saveUserPreferences(data: any, userId: string = DEFAULT_USER.id) {
  const key = `preferences_${userId}`;
  await setStoredData(key, {
    ...data,
    updatedAt: new Date().toISOString()
  });
  return true;
}