import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import localforage from 'localforage';

// Configure localforage
localforage.config({
  name: 'finwell',
  storeName: 'app_cache',
  version: 1.0,
  description: 'FinWell application cache',
  driver: [
    localforage.INDEXEDDB,
    localforage.WEBSQL,
    localforage.LOCALSTORAGE
  ],
  size: 4980736 // 4.75MB
});

interface UIState {
  theme: 'light' | 'dark';
  sidebarCollapsed: boolean;
  notifications: any[];
  setTheme: (theme: 'light' | 'dark') => void;
  toggleSidebar: () => void;
  addNotification: (notification: any) => void;
  clearNotifications: () => void;
}

export const useUIStore = create<UIState>()(
  persist(
    (set) => ({
      theme: 'light',
      sidebarCollapsed: false,
      notifications: [],
      setTheme: (theme) => set({ theme }),
      toggleSidebar: () => set((state) => ({ sidebarCollapsed: !state.sidebarCollapsed })),
      addNotification: (notification) => 
        set((state) => ({ notifications: [...state.notifications, notification] })),
      clearNotifications: () => set({ notifications: [] })
    }),
    {
      name: 'ui-storage'
    }
  )
);

// Cache helpers with improved performance
export const cacheHelpers = {
  async set(key: string, value: any, maxAge?: number) {
    try {
      const cacheItem = {
        value,
        timestamp: Date.now(),
        maxAge: maxAge || 1000 * 60 * 60 // 1 hour default
      };
      
      // Use batch operations when possible
      if (Array.isArray(value)) {
        await Promise.all(
          value.map((item, index) => 
            localforage.setItem(`${key}_${index}`, item)
          )
        );
      } else {
        await localforage.setItem(key, cacheItem);
      }
    } catch (error) {
      console.error('Cache set error:', error);
    }
  },

  async get(key: string) {
    try {
      const cached = await localforage.getItem(key) as { 
        value: any; 
        timestamp: number;
        maxAge: number;
      } | null;
      
      if (!cached) return null;

      const { value, timestamp, maxAge } = cached;
      if (Date.now() - timestamp > maxAge) {
        await localforage.removeItem(key);
        return null;
      }

      return value;
    } catch (error) {
      console.error('Cache get error:', error);
      return null;
    }
  },

  async clear() {
    try {
      await localforage.clear();
    } catch (error) {
      console.error('Cache clear error:', error);
    }
  },

  // Batch operations
  async batchGet(keys: string[]) {
    try {
      return await Promise.all(
        keys.map(key => this.get(key))
      );
    } catch (error) {
      console.error('Batch get error:', error);
      return [];
    }
  },

  async batchSet(items: { key: string; value: any; maxAge?: number }[]) {
    try {
      await Promise.all(
        items.map(({ key, value, maxAge }) => 
          this.set(key, value, maxAge)
        )
      );
    } catch (error) {
      console.error('Batch set error:', error);
    }
  }
};