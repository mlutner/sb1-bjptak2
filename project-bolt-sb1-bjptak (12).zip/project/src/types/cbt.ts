export type ModuleStatus = 'locked' | 'available' | 'in-progress' | 'completed';

export interface CBTModule {
  id: number;
  title: string;
  description: string;
  duration: string;
  status: ModuleStatus;
  progress: number;
  exercises: {
    id: string;
    title: string;
    type: 'quiz' | 'journal' | 'exercise' | 'worksheet';
    completed: boolean;
  }[];
}