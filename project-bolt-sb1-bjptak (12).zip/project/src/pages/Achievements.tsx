import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  Progress,
  useDisclosure
} from '@chakra-ui/react';
import { useState } from 'react';
import ProgressMilestones from '../components/gamification/ProgressMilestones';
import AchievementUnlock from '../components/gamification/AchievementUnlock';

export default function Achievements() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [currentAchievement] = useState({
    title: 'Consistency Master',
    description: 'Completed activities 7 days in a row',
    points: 250
  });

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        <Box>
          <Heading size="lg" mb={2}>Your Achievements</Heading>
          <Text color="gray.600">Track your progress and unlock rewards</Text>
        </Box>

        <Grid templateColumns={{ base: '1fr', md: '2fr 1fr' }} gap={6}>
          {/* Main Achievement Section */}
          <Box>
            <VStack spacing={6} align="stretch">
              {/* Overall Progress */}
              <Box bg="white" p={6} rounded="lg" shadow="sm">
                <Text fontWeight="medium" mb={4}>Overall Progress</Text>
                <Progress value={60} size="lg" colorScheme="purple" rounded="full" mb={2} />
                <Text fontSize="sm" color="gray.600">Level 3 - 450/1000 XP</Text>
              </Box>

              {/* Recent Achievements */}
              <Box bg="white" p={6} rounded="lg" shadow="sm">
                <Text fontWeight="medium" mb={4}>Recent Achievements</Text>
                {/* Add achievement cards here */}
              </Box>
            </VStack>
          </Box>

          {/* Milestones Section */}
          <ProgressMilestones />
        </Grid>
      </VStack>

      {/* Achievement Unlock Modal */}
      <AchievementUnlock
        isOpen={isOpen}
        onClose={onClose}
        achievement={currentAchievement}
      />
    </Container>
  );
}