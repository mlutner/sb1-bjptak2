import {
  Box,
  Button,
  Card,
  CardBody,
  Container,
  Flex,
  Grid,
  GridItem,
  Heading,
  Icon,
  Select,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  VStack,
} from '@chakra-ui/react';
import { FiCalendar, FiTrendingUp, FiUsers, FiBarChart2 } from 'react-icons/fi';
import { Line, Pie } from 'react-chartjs-2';
import { defaultChartOptions } from '../lib/charts/chartConfig';

interface MetricCardProps {
  title: string;
  value: string;
  change: number;
  icon: React.ElementType;
}

const MetricCard = ({ title, value, change, icon: IconComponent }: MetricCardProps) => (
  <Card>
    <CardBody>
      <Flex justify="space-between" align="center" mb={2}>
        <Text color="gray.500" fontSize="sm" fontWeight="medium">{title}</Text>
        <Icon as={IconComponent} color="blue.500" boxSize={4} />
      </Flex>
      <Stat>
        <StatNumber fontSize="lg">{value}</StatNumber>
        <StatHelpText>
          <StatArrow type={change >= 0 ? 'increase' : 'decrease'} />
          {Math.abs(change)}%
        </StatHelpText>
      </Stat>
    </CardBody>
  </Card>
);

const engagementData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Active Users',
      data: [420, 480, 540, 600, 650, 700],
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1,
    },
    {
      label: 'Sessions Completed',
      data: [840, 960, 1080, 1200, 1300, 1400],
      borderColor: 'rgb(255, 99, 132)',
      tension: 0.1,
    },
    {
      label: 'Tools Used',
      data: [1260, 1440, 1620, 1800, 1950, 2100],
      borderColor: 'rgb(54, 162, 235)',
      tension: 0.1,
    }
  ],
};

const departmentData = {
  labels: ['Sales', 'Engineering', 'Marketing', 'HR', 'Finance'],
  datasets: [
    {
      data: [150, 200, 80, 40, 60],
      backgroundColor: [
        'rgba(255, 99, 132, 0.8)',
        'rgba(54, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',
        'rgba(75, 192, 192, 0.8)',
        'rgba(153, 102, 255, 0.8)',
      ],
    },
  ],
};

const roiData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Productivity Increase',
      data: [5, 7, 10, 12, 15, 18],
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1,
    },
    {
      label: 'Absenteeism Reduction',
      data: [-8, -12, -15, -18, -20, -25],
      borderColor: 'rgb(255, 99, 132)',
      tension: 0.1,
    },
    {
      label: 'Financial Distress Reduction',
      data: [-12, -15, -20, -25, -30, -35],
      borderColor: 'rgb(54, 162, 235)',
      tension: 0.1,
    }
  ],
};

export default function AdminDashboard() {
  return (
    <Box minH="100vh" bg="gray.50" p={4}>
      <Container maxW="7xl">
        <VStack spacing={6} align="stretch">
          {/* Header */}
          <Card>
            <CardBody>
              <Flex justify="space-between" align="center">
                <Heading size="lg">Employee Wellness Analytics</Heading>
                <Flex gap={4}>
                  <Select bg="white" w="150px" defaultValue="month">
                    <option value="week">Week</option>
                    <option value="month">Month</option>
                    <option value="quarter">Quarter</option>
                    <option value="year">Year</option>
                  </Select>
                  <Select bg="white" w="200px" defaultValue="all">
                    <option value="all">All Departments</option>
                    <option value="sales">Sales</option>
                    <option value="engineering">Engineering</option>
                    <option value="marketing">Marketing</option>
                    <option value="hr">HR</option>
                    <option value="finance">Finance</option>
                  </Select>
                </Flex>
              </Flex>
            </CardBody>
          </Card>

          {/* Metrics Grid */}
          <Grid templateColumns="repeat(4, 1fr)" gap={6}>
            <GridItem>
              <MetricCard
                title="Active Employees"
                value="1,240"
                change={12}
                icon={FiUsers}
              />
            </GridItem>
            <GridItem>
              <MetricCard
                title="Engagement Rate"
                value="78%"
                change={8}
                icon={FiTrendingUp}
              />
            </GridItem>
            <GridItem>
              <MetricCard
                title="Sessions"
                value="4,080"
                change={15}
                icon={FiCalendar}
              />
            </GridItem>
            <GridItem>
              <MetricCard
                title="Tools Used"
                value="6,120"
                change={10}
                icon={FiBarChart2}
              />
            </GridItem>
          </Grid>

          {/* Charts Grid */}
          <Grid templateColumns="repeat(2, 1fr)" gap={6}>
            {/* Engagement Trends */}
            <GridItem colSpan={2}>
              <Card>
                <CardBody>
                  <Heading size="md" mb={4}>Employee Engagement Trends</Heading>
                  <Box h="300px">
                    <Line options={defaultChartOptions} data={engagementData} />
                  </Box>
                </CardBody>
              </Card>
            </GridItem>

            {/* Department Distribution */}
            <GridItem>
              <Card>
                <CardBody>
                  <Heading size="md" mb={4}>Department Distribution</Heading>
                  <Box h="300px">
                    <Pie data={departmentData} />
                  </Box>
                </CardBody>
              </Card>
            </GridItem>

            {/* ROI Metrics */}
            <GridItem>
              <Card>
                <CardBody>
                  <Heading size="md" mb={4}>ROI Metrics</Heading>
                  <Box h="300px">
                    <Line options={defaultChartOptions} data={roiData} />
                  </Box>
                </CardBody>
              </Card>
            </GridItem>
          </Grid>

          {/* Insights Card */}
          <Card bg="blue.50">
            <CardBody>
              <Flex justify="space-between" align="center">
                <Heading size="md">Key Insights</Heading>
                <Flex gap={6}>
                  <Text color="blue.700">↑ 15% reduction in financial distress</Text>
                  <Text color="blue.700">↑ 12% increase in productivity</Text>
                  <Text color="blue.700">↑ 82% engagement in Engineering</Text>
                </Flex>
              </Flex>
            </CardBody>
          </Card>
        </VStack>
      </Container>
    </Box>
  );
}