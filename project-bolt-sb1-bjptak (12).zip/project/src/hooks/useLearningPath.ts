import { useState } from 'react';
import { pathModules, pathNames } from '../data/learningPaths';

export function useLearningPath() {
  const [data] = useState({
    type: 'confidence',
    modules: pathModules.confidence,
    name: pathNames.confidence
  });

  return {
    data,
    isLoading: false,
    error: null
  };
}