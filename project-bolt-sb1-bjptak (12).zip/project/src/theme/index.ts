import { extendTheme } from '@chakra-ui/react';
import { colors } from './colors';

const radii = {
  none: '0',
  sm: '0.125rem',
  base: '0.25rem',
  md: '0.375rem',
  lg: '0.5rem',
  xl: '0.75rem',
  '2xl': '1rem',
  '3xl': '1.25rem',
  full: '9999px',
  custom: '20px'
};

const theme = extendTheme({
  colors,
  radii,
  components: {
    Card: {
      baseStyle: {
        container: {
          borderRadius: 'custom'
        }
      }
    },
    Button: {
      baseStyle: {
        borderRadius: 'custom'
      },
      variants: {
        solid: {
          borderRadius: 'custom'
        },
        outline: {
          borderRadius: 'custom'
        },
        ghost: {
          borderRadius: 'custom'
        },
        link: {
          borderRadius: 'custom'
        },
        pill: {
          borderRadius: 'full'
        }
      },
      defaultProps: {
        borderRadius: 'custom'
      }
    },
    ButtonGroup: {
      baseStyle: {
        borderRadius: 'custom'
      },
      variants: {
        pill: {
          borderRadius: 'full'
        }
      }
    },
    IconButton: {
      baseStyle: {
        borderRadius: 'custom'
      },
      variants: {
        solid: {
          borderRadius: 'custom'
        },
        outline: {
          borderRadius: 'custom'
        },
        ghost: {
          borderRadius: 'custom'
        }
      },
      defaultProps: {
        borderRadius: 'custom'
      }
    },
    Input: {
      defaultProps: {
        focusBorderColor: 'purple.500'
      },
      baseStyle: {
        field: {
          borderRadius: 'custom'
        }
      }
    },
    Select: {
      baseStyle: {
        field: {
          borderRadius: 'custom'
        }
      }
    },
    Textarea: {
      baseStyle: {
        borderRadius: 'custom'
      }
    },
    Badge: {
      baseStyle: {
        borderRadius: 'custom'
      }
    },
    Progress: {
      baseStyle: {
        track: {
          borderRadius: 'custom'
        },
        filledTrack: {
          borderRadius: 'custom'
        }
      }
    },
    Modal: {
      baseStyle: {
        dialog: {
          borderRadius: 'custom'
        }
      }
    },
    Popover: {
      baseStyle: {
        content: {
          borderRadius: 'custom'
        }
      }
    },
    Menu: {
      baseStyle: {
        list: {
          borderRadius: 'custom'
        },
        item: {
          borderRadius: 'custom'
        }
      }
    },
    Tooltip: {
      baseStyle: {
        borderRadius: 'custom'
      }
    }
  },
  styles: {
    global: {
      '.chakra-card': {
        borderRadius: 'custom'
      },
      '.chakra-button': {
        borderRadius: 'custom !important'
      },
      '.chakra-button__group': {
        borderRadius: 'custom !important'
      }
    }
  }
});

export default theme;