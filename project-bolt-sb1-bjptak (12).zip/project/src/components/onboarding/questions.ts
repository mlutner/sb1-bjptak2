interface Question {
  id: string;
  title: string;
  options: {
    value: string;
    label: string;
    description: string;
  }[];
}

export const questions: Question[] = [
  {
    id: 'stress_level',
    title: 'How would you describe your relationship with money?',
    options: [
      { 
        value: 'high',
        label: 'Frequently Stressed',
        description: 'Money worries often affect my daily life and well-being'
      },
      {
        value: 'moderate',
        label: 'Sometimes Concerned',
        description: 'I manage but often worry about financial decisions'
      },
      {
        value: 'low',
        label: 'Generally Confident',
        description: 'I feel in control but want to improve further'
      }
    ]
  },
  {
    id: 'primary_concern',
    title: "What's your main financial goal right now?",
    options: [
      {
        value: 'anxiety',
        label: 'Reduce Financial Stress',
        description: 'Learn to manage money-related anxiety and worry'
      },
      {
        value: 'spending',
        label: 'Control Spending',
        description: 'Develop healthier spending habits and patterns'
      },
      {
        value: 'confidence',
        label: 'Build Confidence',
        description: 'Gain knowledge and trust in financial decisions'
      }
    ]
  },
  {
    id: 'learning_style',
    title: 'How do you prefer to learn and grow?',
    options: [
      {
        value: 'interactive',
        label: 'Interactive Tools',
        description: 'Learn by doing with practical exercises'
      },
      {
        value: 'guidance',
        label: 'Professional Guidance',
        description: 'Regular check-ins with financial therapists'
      },
      {
        value: 'community',
        label: 'Community Support',
        description: 'Learn alongside others with similar goals'
      }
    ]
  }
];