import React, { Component, ErrorInfo, ReactNode } from 'react';
import { Box, Heading, Text, Button } from '@chakra-ui/react';

interface Props {
  children: ReactNode;
}

interface State {
  hasError: boolean;
  error: Error | null;
}

class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false,
    error: null
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  public render() {
    if (this.state.hasError) {
      const isMissingEnvVars = this.state.error?.message.includes('Missing required environment variables');

      return (
        <Box p={8} maxW="container.md" mx="auto">
          <Heading mb={4} color="red.500">Something went wrong</Heading>
          {isMissingEnvVars ? (
            <>
              <Text mb={4}>
                Firebase configuration is incomplete. Please check your environment variables.
              </Text>
              <Text whiteSpace="pre-wrap" mb={4} fontFamily="monospace">
                {this.state.error?.message}
              </Text>
            </>
          ) : (
            <Text mb={4}>
              An unexpected error occurred. Please try refreshing the page.
            </Text>
          )}
          <Button
            colorScheme="blue"
            onClick={() => window.location.reload()}
          >
            Refresh Page
          </Button>
        </Box>
      );
    }

    return this.props.children;
  }
}

export default ErrorBoundary;