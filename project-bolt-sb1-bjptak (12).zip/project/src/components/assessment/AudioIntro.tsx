import { Button, HStack, Icon } from '@chakra-ui/react';
import { Play, Pause, Volume2 } from 'lucide-react';

interface Props {
  isPlaying: boolean;
  onToggle: () => void;
}

export default function AudioIntro({ isPlaying, onToggle }: Props) {
  return (
    <Button
      onClick={onToggle}
      variant="ghost"
      colorScheme="blue"
      size="sm"
      leftIcon={
        <HStack spacing={1}>
          <Icon as={isPlaying ? Pause : Play} />
          <Icon as={Volume2} />
        </HStack>
      }
    >
      Listen to Overview
    </Button>
  );
}