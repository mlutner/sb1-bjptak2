import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  Select,
  VStack,
  Textarea,
  FormErrorMessage,
  NumberInput,
  NumberInputField,
  Heading,
} from '@chakra-ui/react';
import type { FinancialAssessment } from '../../types/assessment';

const schema = z.object({
  monthlyIncome: z.number().min(0, 'Monthly income must be positive'),
  monthlyExpenses: z.number().min(0, 'Monthly expenses must be positive'),
  savings: z.number().min(0, 'Savings must be positive'),
  debt: z.number().min(0, 'Debt must be positive'),
  financialGoals: z.string(),
  riskTolerance: z.enum(['low', 'medium', 'high']),
  investmentExperience: z.enum(['none', 'beginner', 'intermediate', 'advanced']),
});

type FormData = z.infer<typeof schema>;

interface Props {
  onSubmit: (data: FinancialAssessment) => void;
  initialData?: FinancialAssessment;
}

function FinancialAssessmentForm({ onSubmit, initialData }: Props) {
  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<FormData>({
    resolver: zodResolver(schema),
    defaultValues: initialData,
  });

  const handleFormSubmit = (data: FormData) => {
    const goals = data.financialGoals
      .split('\n')
      .map(goal => goal.trim())
      .filter(Boolean);
    
    onSubmit({
      ...data,
      financialGoals: goals,
    });
  };

  return (
    <Box maxW="2xl" mx="auto" mt={8}>
      <Heading size="lg" mb={6}>Financial Assessment</Heading>
      <form onSubmit={handleSubmit(handleFormSubmit)}>
        <VStack spacing={6} align="stretch">
          <FormControl isInvalid={!!errors.monthlyIncome}>
            <FormLabel>Monthly Income</FormLabel>
            <NumberInput min={0}>
              <NumberInputField {...register('monthlyIncome', { valueAsNumber: true })} />
            </NumberInput>
            <FormErrorMessage>{errors.monthlyIncome?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={!!errors.monthlyExpenses}>
            <FormLabel>Monthly Expenses</FormLabel>
            <NumberInput min={0}>
              <NumberInputField {...register('monthlyExpenses', { valueAsNumber: true })} />
            </NumberInput>
            <FormErrorMessage>{errors.monthlyExpenses?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={!!errors.savings}>
            <FormLabel>Total Savings</FormLabel>
            <NumberInput min={0}>
              <NumberInputField {...register('savings', { valueAsNumber: true })} />
            </NumberInput>
            <FormErrorMessage>{errors.savings?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={!!errors.debt}>
            <FormLabel>Total Debt</FormLabel>
            <NumberInput min={0}>
              <NumberInputField {...register('debt', { valueAsNumber: true })} />
            </NumberInput>
            <FormErrorMessage>{errors.debt?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={!!errors.financialGoals}>
            <FormLabel>Financial Goals (one per line)</FormLabel>
            <Textarea {...register('financialGoals')} rows={4} />
            <FormErrorMessage>{errors.financialGoals?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={!!errors.riskTolerance}>
            <FormLabel>Risk Tolerance</FormLabel>
            <Select {...register('riskTolerance')}>
              <option value="low">Low</option>
              <option value="medium">Medium</option>
              <option value="high">High</option>
            </Select>
            <FormErrorMessage>{errors.riskTolerance?.message}</FormErrorMessage>
          </FormControl>

          <FormControl isInvalid={!!errors.investmentExperience}>
            <FormLabel>Investment Experience</FormLabel>
            <Select {...register('investmentExperience')}>
              <option value="none">None</option>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </Select>
            <FormErrorMessage>{errors.investmentExperience?.message}</FormErrorMessage>
          </FormControl>

          <Button
            type="submit"
            colorScheme="blue"
            size="lg"
            isLoading={isSubmitting}
          >
            Submit Assessment
          </Button>
        </VStack>
      </form>
    </Box>
  );
}

export default FinancialAssessmentForm;