import { VStack, Heading, Text, Box, Button, List, ListItem, ListIcon } from '@chakra-ui/react';
import { CheckCircleIcon } from '@chakra-ui/icons';
import { useNavigate } from 'react-router-dom';

interface Pathway {
  name: string;
  description: string;
  features: string[];
}

interface Props {
  pathway: Pathway;
}

export default function PathwayRecommendation({ pathway }: Props) {
  const navigate = useNavigate();

  const handleStart = () => {
    navigate('/cbt-program');
  };

  return (
    <VStack spacing={6} align="stretch">
      <Box textAlign="center">
        <Heading size="lg" mb={2}>Your Personalized Path</Heading>
        <Text color="gray.600">Based on your responses, we recommend:</Text>
      </Box>

      <Box bg="white" p={6} rounded="xl" shadow="sm">
        <Heading size="md" color="blue.600" mb={4}>{pathway.name}</Heading>
        <Text color="gray.600" mb={4}>{pathway.description}</Text>
        
        <List spacing={2}>
          {pathway.features.map((feature, index) => (
            <ListItem key={index} display="flex" alignItems="center">
              <ListIcon as={CheckCircleIcon} color="blue.500" />
              <Text>{feature}</Text>
            </ListItem>
          ))}
        </List>
      </Box>

      <Button
        colorScheme="blue"
        size="lg"
        onClick={handleStart}
        bgGradient="linear(to-r, blue.500, purple.500)"
        _hover={{
          bgGradient: "linear(to-r, blue.600, purple.600)",
        }}
      >
        Begin Your Journey
      </Button>
    </VStack>
  );
}