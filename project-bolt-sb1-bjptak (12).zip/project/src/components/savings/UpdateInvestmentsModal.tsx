import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  VStack,
  Button,
  Text,
  Alert,
  AlertIcon,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentInvestments: Array<{
    type: string;
    value: number;
    change: number;
    allocation: number;
  }>;
  onUpdate: (investments: any) => void;
}

export default function UpdateInvestmentsModal({ isOpen, onClose, currentInvestments, onUpdate }: Props) {
  const [allocations, setAllocations] = useState(
    currentInvestments.map(inv => inv.allocation)
  );

  const totalAllocation = allocations.reduce((sum, curr) => sum + curr, 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const updatedInvestments = currentInvestments.map((inv, index) => ({
      ...inv,
      value: Number(formData.get(`${inv.type}-value`)),
      allocation: Number(formData.get(`${inv.type}-allocation`))
    }));

    onUpdate(updatedInvestments);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Update Investment Portfolio</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <form onSubmit={handleSubmit}>
            <VStack spacing={6}>
              {totalAllocation !== 100 && (
                <Alert status="warning">
                  <AlertIcon />
                  Total allocation should equal 100% (currently {totalAllocation}%)
                </Alert>
              )}

              {currentInvestments.map((investment, index) => (
                <VStack key={investment.type} spacing={4} align="stretch" w="full">
                  <Text fontWeight="medium">{investment.type}</Text>
                  
                  <FormControl>
                    <FormLabel>Current Value</FormLabel>
                    <NumberInput defaultValue={investment.value} min={0}>
                      <NumberInputField name={`${investment.type}-value`} />
                    </NumberInput>
                  </FormControl>

                  <FormControl>
                    <FormLabel>Allocation (%)</FormLabel>
                    <NumberInput
                      defaultValue={investment.allocation}
                      min={0}
                      max={100}
                      onChange={(_, value) => {
                        const newAllocations = [...allocations];
                        newAllocations[index] = value;
                        setAllocations(newAllocations);
                      }}
                    >
                      <NumberInputField name={`${investment.type}-allocation`} />
                    </NumberInput>
                  </FormControl>
                </VStack>
              ))}

              <Button
                type="submit"
                colorScheme="purple"
                w="full"
                isDisabled={totalAllocation !== 100}
              >
                Update Portfolio
              </Button>
            </VStack>
          </form>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}