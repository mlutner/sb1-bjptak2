import {
  Box,
  Button,
  Drawer,
  DrawerBody,
  DrawerCloseButton,
  DrawerContent,
  DrawerHeader,
  Flex,
  Grid,
  Heading,
  Icon,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Tab,
  TabList,
  TabPanel,
  TabPanels,
  Tabs,
  Text,
  VStack,
} from '@chakra-ui/react';
import { FiTrendingUp, FiDollarSign, FiPieChart, FiActivity } from 'react-icons/fi';
import { Line, Pie } from 'react-chartjs-2';

const lineChartOptions = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top' as const,
    },
  },
  scales: {
    y: {
      beginAtZero: true,
    },
  },
};

const mockLineData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Income',
      data: [3000, 3500, 3200, 3800, 3600, 4000],
      borderColor: 'rgb(75, 192, 192)',
      tension: 0.1,
    },
    {
      label: 'Expenses',
      data: [2500, 2800, 2600, 3000, 2900, 3200],
      borderColor: 'rgb(255, 99, 132)',
      tension: 0.1,
    },
  ],
};

const mockPieData = {
  labels: ['Housing', 'Food', 'Transport', 'Entertainment', 'Savings'],
  datasets: [
    {
      data: [35, 20, 15, 10, 20],
      backgroundColor: [
        'rgba(255, 99, 132, 0.8)',
        'rgba(54, 162, 235, 0.8)',
        'rgba(255, 206, 86, 0.8)',
        'rgba(75, 192, 192, 0.8)',
        'rgba(153, 102, 255, 0.8)',
      ],
    },
  ],
};

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

export default function AnalyticsFoldout({ isOpen, onClose }: Props) {
  return (
    <Drawer
      isOpen={isOpen}
      placement="right"
      onClose={onClose}
      size="lg"
    >
      <DrawerContent>
        <DrawerCloseButton />
        <DrawerHeader borderBottomWidth="1px">
          <Heading size="lg">Financial Analytics</Heading>
        </DrawerHeader>

        <DrawerBody>
          <VStack spacing={6} align="stretch">
            {/* Quick Stats */}
            <Grid templateColumns="repeat(2, 1fr)" gap={4}>
              <Stat bg="purple.50" p={4} borderRadius="lg">
                <StatLabel>Monthly Income</StatLabel>
                <StatNumber>$4,000</StatNumber>
                <StatHelpText>
                  <StatArrow type="increase" />
                  8.2%
                </StatHelpText>
              </Stat>

              <Stat bg="green.50" p={4} borderRadius="lg">
                <StatLabel>Monthly Savings</StatLabel>
                <StatNumber>$800</StatNumber>
                <StatHelpText>
                  <StatArrow type="increase" />
                  12.5%
                </StatHelpText>
              </Stat>
            </Grid>

            <Tabs colorScheme="purple" isLazy>
              <TabList>
                <Tab><Icon as={FiTrendingUp} mr={2} />Trends</Tab>
                <Tab><Icon as={FiPieChart} mr={2} />Breakdown</Tab>
                <Tab><Icon as={FiActivity} mr={2} />Activity</Tab>
              </TabList>

              <TabPanels>
                <TabPanel>
                  <VStack spacing={4} align="stretch">
                    <Heading size="md">Income vs Expenses</Heading>
                    <Box h="300px">
                      <Line options={lineChartOptions} data={mockLineData} />
                    </Box>
                  </VStack>
                </TabPanel>

                <TabPanel>
                  <VStack spacing={4} align="stretch">
                    <Heading size="md">Expense Breakdown</Heading>
                    <Box h="300px">
                      <Pie data={mockPieData} />
                    </Box>
                  </VStack>
                </TabPanel>

                <TabPanel>
                  <VStack spacing={4} align="stretch">
                    <Heading size="md">Recent Activity</Heading>
                    {[
                      { type: 'Income', amount: 4000, date: '2023-12-15', category: 'Salary' },
                      { type: 'Expense', amount: 1200, date: '2023-12-14', category: 'Rent' },
                      { type: 'Expense', amount: 85, date: '2023-12-13', category: 'Groceries' },
                    ].map((activity, index) => (
                      <Flex
                        key={index}
                        justify="space-between"
                        align="center"
                        p={4}
                        bg="gray.50"
                        borderRadius="lg"
                      >
                        <Box>
                          <Text fontWeight="medium">{activity.category}</Text>
                          <Text fontSize="sm" color="gray.600">{activity.date}</Text>
                        </Box>
                        <Text
                          fontWeight="medium"
                          color={activity.type === 'Income' ? 'green.500' : 'red.500'}
                        >
                          {activity.type === 'Income' ? '+' : '-'}${activity.amount}
                        </Text>
                      </Flex>
                    ))}
                  </VStack>
                </TabPanel>
              </TabPanels>
            </Tabs>
          </VStack>
        </DrawerBody>
      </DrawerContent>
    </Drawer>
  );
}