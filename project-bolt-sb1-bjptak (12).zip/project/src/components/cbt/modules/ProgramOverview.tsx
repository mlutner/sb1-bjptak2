import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  Card,
  CardBody,
  Image,
  VStack,
  Icon,
  Button,
  useBreakpointValue,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { 
  FiTarget, 
  FiHeart, 
  FiActivity, 
  FiShield,
  FiTrendingUp,
  FiPieChart,
  FiCompass,
  FiBook
} from 'react-icons/fi';

const modules = [
  {
    id: 1,
    title: 'Goal Setting & Initial Assessment',
    description: 'Establish your financial and wellness goals',
    icon: FiTarget,
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 2,
    title: 'Understanding Money Emotions',
    description: 'Explore the emotional aspects of financial decisions',
    icon: FiHeart,
    image: 'https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 3,
    title: 'Identifying Triggers',
    description: 'Recognize patterns in financial behavior',
    icon: FiActivity,
    image: 'https://images.unsplash.com/photo-1494200483035-db7bc6aa5739?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 4,
    title: 'Developing Coping Strategies',
    description: 'Build resilience against financial stress',
    icon: FiShield,
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 5,
    title: 'Building Healthy Habits',
    description: 'Create sustainable financial practices',
    icon: FiTrendingUp,
    image: 'https://images.unsplash.com/photo-1434626881859-194d67b2b86f?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 6,
    title: 'Financial Decision Making',
    description: 'Improve your financial choices',
    icon: FiPieChart,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 7,
    title: 'Stress Management',
    description: 'Handle financial pressure effectively',
    icon: FiCompass,
    image: 'https://images.unsplash.com/photo-1506126613408-eca07ce68773?auto=format&fit=crop&w=600&q=80'
  },
  {
    id: 8,
    title: 'Long-term Wellness Planning',
    description: 'Maintain financial well-being',
    icon: FiBook,
    image: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=600&q=80'
  }
];

export default function ProgramOverview() {
  const navigate = useNavigate();
  const columns = useBreakpointValue({ base: 1, md: 2, lg: 4 }) || 1;

  const handleModuleClick = (moduleId: number) => {
    navigate(`/cbt-program/module/${moduleId}`);
  };

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        <Box textAlign="center">
          <Heading size="lg" mb={4}>Financial Wellness Program</Heading>
          <Text color="gray.600">
            An 8-module journey combining financial management with mental well-being
          </Text>
        </Box>

        <Grid templateColumns={`repeat(${columns}, 1fr)`} gap={6}>
          {modules.map((module) => (
            <Card 
              key={module.id}
              onClick={() => handleModuleClick(module.id)}
              cursor="pointer"
              _hover={{ transform: 'translateY(-4px)', shadow: 'lg' }}
              transition="all 0.2s"
            >
              <CardBody>
                <VStack spacing={4}>
                  <Box position="relative" w="full" h="160px" overflow="hidden" borderRadius="lg">
                    <Image
                      src={module.image}
                      alt={module.title}
                      objectFit="cover"
                      w="full"
                      h="full"
                    />
                  </Box>
                  <Icon as={module.icon} boxSize={6} color="purple.500" />
                  <VStack spacing={2} align="center" textAlign="center">
                    <Text fontWeight="bold">{module.title}</Text>
                    <Text fontSize="sm" color="gray.600">
                      {module.description}
                    </Text>
                  </VStack>
                  <Button
                    colorScheme="purple"
                    size="sm"
                    width="full"
                    onClick={() => handleModuleClick(module.id)}
                  >
                    Start Module {module.id}
                  </Button>
                </VStack>
              </CardBody>
            </Card>
          ))}
        </Grid>
      </VStack>
    </Container>
  );
}