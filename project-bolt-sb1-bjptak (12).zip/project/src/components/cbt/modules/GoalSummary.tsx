import {
  Box,
  Card,
  Heading,
  Text,
  VStack,
  List,
  ListItem,
  ListIcon,
  Badge,
  Accordion,
  AccordionItem,
  AccordionButton,
  AccordionPanel,
  AccordionIcon,
  Icon,
  Flex,
} from '@chakra-ui/react';
import { FiCheck, FiTarget, FiClock, FiTrendingUp, FiAlertTriangle, FiLifeBuoy } from 'react-icons/fi';
import type { Goal } from '../../../types/goals';

interface Props {
  goals: Goal[];
}

export default function GoalSummary({ goals }: Props) {
  return (
    <Card variant="outline">
      <Box p={6}>
        <Heading size="md" mb={4}>Goals Summary</Heading>
        <Accordion allowMultiple>
          {goals.map((goal, index) => (
            <AccordionItem key={index} border="none" mb={4}>
              <AccordionButton 
                p={4} 
                bg="purple.50" 
                rounded="lg"
                _hover={{ bg: 'purple.100' }}
              >
                <Box flex="1" textAlign="left">
                  <Badge colorScheme="purple" mb={2}>
                    {goal.type.charAt(0).toUpperCase() + goal.type.slice(1)}
                  </Badge>
                  <Text fontWeight="medium">{goal.description}</Text>
                </Box>
                <AccordionIcon />
              </AccordionButton>
              <AccordionPanel pb={4}>
                <VStack align="stretch" spacing={4} mt={4}>
                  <Box>
                    <Flex align="center" gap={2} mb={2}>
                      <Icon as={FiTarget} color="purple.500" />
                      <Text fontWeight="medium">Target</Text>
                    </Flex>
                    <Text color="gray.700">{goal.target}</Text>
                  </Box>

                  <Box>
                    <Flex align="center" gap={2} mb={2}>
                      <Icon as={FiClock} color="purple.500" />
                      <Text fontWeight="medium">Timeframe</Text>
                    </Flex>
                    <Text color="gray.700">{goal.timeframe}</Text>
                  </Box>

                  <Box>
                    <Flex align="center" gap={2} mb={2}>
                      <Icon as={FiTrendingUp} color="purple.500" />
                      <Text fontWeight="medium">Success Metrics</Text>
                    </Flex>
                    <Text color="gray.700">{goal.metrics}</Text>
                  </Box>

                  <Box>
                    <Flex align="center" gap={2} mb={2}>
                      <Icon as={FiCheck} color="green.500" />
                      <Text fontWeight="medium">Action Steps</Text>
                    </Flex>
                    <List spacing={2}>
                      {goal.steps.map((step, stepIndex) => (
                        <ListItem key={stepIndex} display="flex" alignItems="center" gap={2}>
                          <Badge colorScheme="green" rounded="full" minW="24px" textAlign="center">
                            {stepIndex + 1}
                          </Badge>
                          <Text color="gray.700">{step}</Text>
                        </ListItem>
                      ))}
                    </List>
                  </Box>

                  <Box>
                    <Flex align="center" gap={2} mb={2}>
                      <Icon as={FiAlertTriangle} color="orange.500" />
                      <Text fontWeight="medium">Potential Obstacles</Text>
                    </Flex>
                    <List spacing={2}>
                      {goal.obstacles.map((obstacle, index) => (
                        <ListItem key={index} display="flex" alignItems="center" gap={2}>
                          <ListIcon as={FiAlertTriangle} color="orange.500" />
                          <Text color="gray.700">{obstacle}</Text>
                        </ListItem>
                      ))}
                    </List>
                  </Box>

                  <Box>
                    <Flex align="center" gap={2} mb={2}>
                      <Icon as={FiLifeBuoy} color="blue.500" />
                      <Text fontWeight="medium">Support & Resources</Text>
                    </Flex>
                    <List spacing={2}>
                      {goal.support.map((support, index) => (
                        <ListItem key={index} display="flex" alignItems="center" gap={2}>
                          <ListIcon as={FiLifeBuoy} color="blue.500" />
                          <Text color="gray.700">{support}</Text>
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                </VStack>
              </AccordionPanel>
            </AccordionItem>
          ))}
        </Accordion>
      </Box>
    </Card>
  );
}