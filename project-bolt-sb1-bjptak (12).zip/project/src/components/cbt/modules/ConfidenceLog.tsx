import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  VStack,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  SliderMark,
  Textarea,
  FormControl,
  FormLabel,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';

interface ConfidenceRating {
  area: string;
  rating: number;
  reason: string;
}

interface Props {
  onComplete: (ratings: ConfidenceRating[]) => void;
}

const ASSESSMENT_AREAS = [
  {
    id: 'budgeting',
    label: 'Creating and sticking to a budget',
    description: 'How confident are you in your ability to create and maintain a budget?'
  },
  {
    id: 'saving',
    label: 'Saving money regularly',
    description: 'How confident are you in your ability to save money consistently?'
  },
  {
    id: 'spending',
    label: 'Controlling spending impulses',
    description: 'How confident are you in your ability to control impulsive spending?'
  },
  {
    id: 'stress',
    label: 'Managing financial stress',
    description: 'How confident are you in your ability to cope with financial stress?'
  }
];

export default function ConfidenceLog({ onComplete }: Props) {
  const [ratings, setRatings] = useState<Record<string, ConfidenceRating>>({});
  const toast = useToast();

  const handleSubmit = () => {
    if (Object.keys(ratings).length < ASSESSMENT_AREAS.length) {
      toast({
        title: 'Please complete all areas',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onComplete(Object.values(ratings));
    toast({
      title: 'Confidence log saved successfully',
      status: 'success',
      duration: 3000,
    });
  };

  const updateRating = (area: string, field: keyof ConfidenceRating, value: any) => {
    setRatings(prev => ({
      ...prev,
      [area]: {
        ...prev[area],
        area,
        [field]: value
      }
    }));
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Confidence to Achieve Goals Log</Heading>
        <Text mt={2} color="gray.600">
          Rate your confidence level in different areas of financial wellness
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={8} align="stretch">
          {ASSESSMENT_AREAS.map((area) => (
            <Box key={area.id} p={6} bg="gray.50" rounded="lg">
              <VStack spacing={4} align="stretch">
                <Heading size="md">{area.label}</Heading>
                <Text color="gray.600">{area.description}</Text>

                <Box pt={6} pb={2}>
                  <Slider
                    defaultValue={5}
                    min={0}
                    max={10}
                    step={1}
                    onChange={(val) => updateRating(area.id, 'rating', val)}
                  >
                    <SliderMark value={0} mt={2} ml={-2} fontSize="sm">
                      0
                    </SliderMark>
                    <SliderMark value={5} mt={2} ml={-2} fontSize="sm">
                      5
                    </SliderMark>
                    <SliderMark value={10} mt={2} ml={-2} fontSize="sm">
                      10
                    </SliderMark>
                    <SliderTrack>
                      <SliderFilledTrack bg="purple.500" />
                    </SliderTrack>
                    <SliderThumb boxSize={6} />
                  </Slider>
                </Box>

                <FormControl>
                  <FormLabel>What influences your confidence in this area?</FormLabel>
                  <Textarea
                    value={ratings[area.id]?.reason || ''}
                    onChange={(e) => updateRating(area.id, 'reason', e.target.value)}
                    placeholder="Explain your rating..."
                  />
                </FormControl>
              </VStack>
            </Box>
          ))}

          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleSubmit}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
            }}
          >
            Save Confidence Log
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}