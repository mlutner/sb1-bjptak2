import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  Input,
  Select,
  VStack,
  Button,
  Textarea,
} from '@chakra-ui/react';
import type { EventFormData } from '../../types/calendar';

interface EventModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (formData: EventFormData) => void;
}

export default function EventModal({ isOpen, onClose, onSubmit }: EventModalProps) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    onSubmit({
      title: formData.get('title') as string,
      type: formData.get('type') as 'consultation' | 'goal' | 'reminder',
      description: formData.get('description') as string,
    });
    
    form.reset();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="md">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Add Event</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <form onSubmit={handleSubmit}>
            <VStack spacing={4}>
              <FormControl isRequired>
                <FormLabel>Event Title</FormLabel>
                <Input 
                  name="title" 
                  placeholder="Enter event title"
                  autoFocus
                />
              </FormControl>

              <FormControl isRequired>
                <FormLabel>Event Type</FormLabel>
                <Select 
                  name="type"
                  defaultValue="reminder"
                >
                  <option value="consultation">Consultation</option>
                  <option value="goal">Goal Milestone</option>
                  <option value="reminder">Reminder</option>
                </Select>
              </FormControl>

              <FormControl>
                <FormLabel>Description</FormLabel>
                <Textarea
                  name="description"
                  placeholder="Add description (optional)"
                  resize="vertical"
                  rows={3}
                />
              </FormControl>

              <Button 
                type="submit" 
                colorScheme="purple" 
                w="full"
                size="lg"
              >
                Add Event
              </Button>
            </VStack>
          </form>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}