import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  VStack,
  Text,
  Heading,
  Image,
  Card,
  CardBody,
  Container,
  Alert,
  AlertIcon,
} from '@chakra-ui/react';
import { useAuth } from '../../contexts/AuthContext';

export default function SignIn() {
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleDemoLogin = async () => {
    setLoading(true);
    try {
      login();
      // Navigate to initial assessment instead of dashboard
      navigate('/assessment');
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box minH="100vh" bg="gray.50" py={12}>
      <Container maxW="md">
        <Card shadow="lg">
          <CardBody>
            <VStack spacing={8}>
              <Image 
                src="/finwell-logo.svg" 
                alt="FinWell Logo" 
                boxSize="120px"
                fallbackSrc="https://via.placeholder.com/120"
              />
              
              <Heading as="h1" size="xl" color="purple.600">
                FinWell
              </Heading>
              
              <Text fontSize="lg" color="gray.600" textAlign="center">
                Your Financial Wellness Journey
              </Text>

              <Alert status="info" rounded="md">
                <AlertIcon />
                <Text>
                  Welcome to FinWell! Start with a quick assessment to personalize your journey.
                </Text>
              </Alert>

              <Button
                w="full"
                size="lg"
                colorScheme="purple"
                onClick={handleDemoLogin}
                isLoading={loading}
                bgGradient="linear(to-r, purple.500, purple.600)"
                _hover={{
                  bgGradient: "linear(to-r, purple.600, purple.700)",
                }}
              >
                Begin Journey
              </Button>

              <Text color="gray.600" fontSize="sm" textAlign="center">
                This is a demo version with pre-populated data.<br />
                No sign up required.
              </Text>
            </VStack>
          </CardBody>
        </Card>
      </Container>
    </Box>
  );
}