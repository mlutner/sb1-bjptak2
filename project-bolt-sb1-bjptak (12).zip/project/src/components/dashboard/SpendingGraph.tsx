import {
  Box,
  Button,
  ButtonGroup,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Text,
  useTheme,
  Badge,
  HStack,
  Icon,
  Tooltip,
} from '@chakra-ui/react';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip as ChartTooltip,
  Legend,
  Filler,
} from 'chart.js';
import { Line } from 'react-chartjs-2';
import { useState } from 'react';
import { motion } from 'framer-motion';
import { FiActivity, FiDollarSign, FiTrendingUp } from 'react-icons/fi';
import { useWearables } from '../../hooks/useWearables';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  ChartTooltip,
  Legend,
  Filler
);

const generateMockData = (days: number, colors: any) => {
  const labels = Array.from({ length: days }, (_, i) => {
    const date = new Date();
    date.setDate(date.getDate() - (days - 1 - i));
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
  });

  const spending = Array.from({ length: days }, () => 
    Math.floor(Math.random() * 150) + 50
  );

  const budget = Array(days).fill(100);

  const stressLevels = Array.from({ length: days }, () => 
    Math.floor(Math.random() * 100)
  );

  return {
    labels,
    datasets: [
      {
        label: 'Daily Spending',
        data: spending,
        borderColor: colors.headspace.orange.primary,
        backgroundColor: colors.headspace.orange.light,
        tension: 0.4,
        order: 2,
      },
      {
        label: 'Budget Target',
        data: budget,
        borderColor: colors.headspace.blue,
        backgroundColor: `${colors.headspace.blue}33`,
        borderDash: [5, 5],
        tension: 0,
        order: 3,
      },
      {
        label: 'Stress Level',
        data: stressLevels,
        borderColor: colors.red[400],
        backgroundColor: `${colors.red[400]}33`,
        tension: 0.4,
        fill: true,
        order: 1,
        yAxisID: 'stress',
      },
    ],
  };
};

export default function SpendingGraph() {
  const theme = useTheme();
  const [timeframe, setTimeframe] = useState<'7d' | '30d' | '90d'>('7d');
  const [chartData, setChartData] = useState(() => generateMockData(7, theme.colors));
  const { metrics } = useWearables();

  const handleTimeframeChange = (newTimeframe: '7d' | '30d' | '90d') => {
    setTimeframe(newTimeframe);
    const days = newTimeframe === '7d' ? 7 : newTimeframe === '30d' ? 30 : 90;
    setChartData(generateMockData(days, theme.colors));
  };

  const options = {
    responsive: true,
    interaction: {
      mode: 'index' as const,
      intersect: false,
    },
    plugins: {
      legend: {
        position: 'top' as const,
        labels: {
          usePointStyle: true,
          padding: 20,
          font: {
            family: "'Circular', -apple-system, BlinkMacSystemFont, sans-serif"
          },
        }
      },
      tooltip: {
        mode: 'index' as const,
        intersect: false,
        backgroundColor: 'rgba(255, 255, 255, 0.95)',
        titleColor: theme.colors.headspace.slate,
        bodyColor: theme.colors.headspace.slate,
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderWidth: 1,
        padding: 12,
        callbacks: {
          label: function(context: any) {
            let label = context.dataset.label || '';
            let value = context.parsed.y;
            
            if (label === 'Stress Level') {
              return `${label}: ${value}%`;
            }
            return `${label}: $${value}`;
          }
        }
      }
    },
    scales: {
      y: {
        type: 'linear',
        display: true,
        position: 'left',
        title: {
          display: true,
          text: 'Amount ($)',
        },
        grid: {
          color: theme.colors.headspace.orange.light,
        },
        ticks: {
          callback: function(value: any) {
            return '$' + value;
          }
        }
      },
      stress: {
        type: 'linear',
        display: true,
        position: 'right',
        title: {
          display: true,
          text: 'Stress Level (%)',
        },
        grid: {
          drawOnChartArea: false,
        },
        ticks: {
          callback: function(value: any) {
            return value + '%';
          }
        }
      }
    },
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center" mb={4}>
            <Box>
              <Heading 
                size="md" 
                color="headspace.slate"
                fontWeight="600"
                letterSpacing="-0.02em"
              >
                Spending & Stress Overview
              </Heading>
              <Text 
                color="gray.600" 
                fontSize="sm"
                mt={1}
              >
                Track spending patterns and stress correlation
              </Text>
            </Box>

            <HStack spacing={4}>
              {metrics && (
                <Tooltip label="Current stress level from wearable">
                  <Badge
                    display="flex"
                    alignItems="center"
                    gap={2}
                    colorScheme={metrics.stressLevel > 70 ? 'red' : 'green'}
                    py={1}
                    px={3}
                  >
                    <Icon as={FiActivity} />
                    <Text>Stress: {metrics.stressLevel}%</Text>
                  </Badge>
                </Tooltip>
              )}

              <ButtonGroup variant="pill" bg="gray.100" p={1} borderRadius="full">
                <Button
                  variant="pill"
                  onClick={() => handleTimeframeChange('7d')}
                  bg={timeframe === '7d' ? 'white' : 'transparent'}
                  shadow={timeframe === '7d' ? 'sm' : 'none'}
                >
                  7D
                </Button>
                <Button
                  variant="pill"
                  onClick={() => handleTimeframeChange('30d')}
                  bg={timeframe === '30d' ? 'white' : 'transparent'}
                  shadow={timeframe === '30d' ? 'sm' : 'none'}
                >
                  30D
                </Button>
                <Button
                  variant="pill"
                  onClick={() => handleTimeframeChange('90d')}
                  bg={timeframe === '90d' ? 'white' : 'transparent'}
                  shadow={timeframe === '90d' ? 'sm' : 'none'}
                >
                  90D
                </Button>
              </ButtonGroup>
            </HStack>
          </Flex>
        </CardHeader>

        <CardBody>
          <Box h="300px">
            <Line options={options} data={chartData} />
          </Box>

          <HStack mt={4} spacing={6} justify="center">
            <Flex align="center" gap={2}>
              <Icon as={FiDollarSign} color="orange.500" />
              <Text fontSize="sm" color="gray.600">Daily Spending</Text>
            </Flex>
            <Flex align="center" gap={2}>
              <Icon as={FiTrendingUp} color="blue.500" />
              <Text fontSize="sm" color="gray.600">Budget Target</Text>
            </Flex>
            <Flex align="center" gap={2}>
              <Icon as={FiActivity} color="red.400" />
              <Text fontSize="sm" color="gray.600">Stress Level</Text>
            </Flex>
          </HStack>
        </CardBody>
      </Card>
    </motion.div>
  );
}