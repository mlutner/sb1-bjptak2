import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Progress,
  Text,
  VStack,
  Badge,
  SimpleGrid,
  Divider,
  Button,
  Skeleton,
  SkeletonText,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { useLearningPath } from '../../hooks/useLearningPath';
import ModuleCard from './ModuleCard';
import { Suspense, lazy } from 'react';

const LoadingSkeleton = () => (
  <Card>
    <CardHeader>
      <VStack align="stretch" spacing={4}>
        <Flex justify="space-between" align="center">
          <Box>
            <Skeleton height="24px" width="200px" mb={2} />
            <SkeletonText noOfLines={1} width="150px" />
          </Box>
          <Skeleton height="24px" width="120px" borderRadius="full" />
        </Flex>
        <Skeleton height="8px" borderRadius="full" />
      </VStack>
    </CardHeader>

    <CardBody>
      <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4}>
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} height="200px" borderRadius="lg" />
        ))}
      </SimpleGrid>
    </CardBody>
  </Card>
);

export default function LearningPathways() {
  const navigate = useNavigate();
  const { data: userPath, isLoading } = useLearningPath();

  if (isLoading) {
    return <LoadingSkeleton />;
  }

  if (!userPath) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <VStack align="stretch" spacing={4}>
          <Flex justify="space-between" align="center">
            <Box>
              <Heading size="md">Your Learning Journey</Heading>
              <Text color="gray.600" mt={1}>Track your progress</Text>
            </Box>
            <Badge
              colorScheme="purple"
              fontSize="sm"
              px={3}
              py={1}
              borderRadius="full"
            >
              {userPath.name}
            </Badge>
          </Flex>
          <Progress value={0} size="sm" colorScheme="purple" borderRadius="full" />
        </VStack>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4}>
            {userPath.modules.map((module) => (
              <ModuleCard
                key={module.id}
                module={module}
                onNavigate={() => navigate('/cbt-program')}
              />
            ))}
          </SimpleGrid>

          <Divider />

          <Button
            colorScheme="purple"
            size="lg"
            onClick={() => navigate('/cbt-program')}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
              transform: "translateY(-2px)",
            }}
          >
            Continue Your Journey
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}