import { useEffect, useRef, useState } from 'react';
import {
  AspectRatio,
  Box,
  Button,
  Progress,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';
import type { VideoContent } from './config';

interface Props {
  content: VideoContent;
  onComplete?: () => void;
}

export default function LMSVideoPlayer({ content, onComplete }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [progress, setProgress] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  const toast = useToast();

  useEffect(() => {
    // Track video progress
    const video = videoRef.current;
    if (!video) return;

    const handleTimeUpdate = () => {
      const progress = (video.currentTime / video.duration) * 100;
      setProgress(progress);

      // Mark as complete when finished
      if (progress >= 98 && onComplete) {
        onComplete();
      }
    };

    video.addEventListener('timeupdate', handleTimeUpdate);
    return () => video.removeEventListener('timeupdate', handleTimeUpdate);
  }, [onComplete]);

  const handleError = () => {
    toast({
      title: 'Video Error',
      description: 'Unable to load video content. Please try again.',
      status: 'error',
      duration: 5000,
    });
  };

  return (
    <VStack spacing={4} align="stretch">
      <AspectRatio ratio={16 / 9}>
        <Box bg="gray.900" rounded="lg" overflow="hidden">
          <video
            ref={videoRef}
            src={content.url}
            controls
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            onError={handleError}
            style={{ width: '100%', height: '100%', objectFit: 'contain' }}
          />
        </Box>
      </AspectRatio>

      <Box>
        <Text fontWeight="medium" mb={2}>{content.title}</Text>
        {content.description && (
          <Text color="gray.600" fontSize="sm" mb={4}>
            {content.description}
          </Text>
        )}
        <Progress 
          value={progress} 
          size="sm" 
          colorScheme="purple" 
          rounded="full" 
        />
      </Box>
    </VStack>
  );
}