import { z } from 'zod';

export const LMSConfig = {
  // Example configurations for different LMS providers
  moodle: {
    baseUrl: import.meta.env.VITE_MOODLE_API_URL || '',
    token: import.meta.env.VITE_MOODLE_TOKEN || '',
  },
  canvas: {
    baseUrl: import.meta.env.VITE_CANVAS_API_URL || '',
    token: import.meta.env.VITE_CANVAS_TOKEN || '',
  },
  // Add other LMS providers as needed
};

// Validation schema for video content
export const VideoContentSchema = z.object({
  id: z.string(),
  title: z.string(),
  description: z.string().optional(),
  url: z.string().url(),
  duration: z.number(),
  provider: z.enum(['moodle', 'canvas', 'vimeo', 'youtube']),
  moduleId: z.number(),
});

export type VideoContent = z.infer<typeof VideoContentSchema>;