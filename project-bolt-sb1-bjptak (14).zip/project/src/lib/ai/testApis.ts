import { config } from './config';

export async function testAPIs() {
  const results = {
    status: 'demo'
  };

  // In demo mode, always return success
  if (config.useMockResponses) {
    console.log("✅ Using demo mode with mock responses");
    return results;
  }

  return results;
}