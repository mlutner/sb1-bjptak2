export interface Professional {
  id: string;
  name: string;
  title: string;
  specialties: string[];
  availability: string[];
  rating: number;
  imageUrl: string;
  bio: string;
  consultationTypes: ('video' | 'phone' | 'chat')[];
  nextAvailable: string;
}

export interface ConsultationBooking {
  professionalId: string;
  userId: string;
  type: 'video' | 'phone' | 'chat';
  dateTime: string;
  status: 'pending' | 'confirmed' | 'completed' | 'cancelled';
  notes?: string;
}