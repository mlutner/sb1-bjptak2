export type WearableProvider = 'garmin' | 'apple' | 'fitbit';

export interface WearableMetrics {
  heartRate: number;
  stressLevel: number;
  sleepQuality: number;
  steps: number;
  timestamp: string;
}

export interface WearableConnection {
  provider: WearableProvider;
  connected: boolean;
  lastSync: string;
  deviceName?: string;
  deviceId?: string;
}

export interface WearableAuthConfig {
  clientId: string;
  clientSecret: string;
  callbackUrl: string;
}