import { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Textarea,
  VStack,
  Heading,
  List,
  ListItem,
  ListIcon,
  Text,
  useToast,
  Circle,
} from '@chakra-ui/react';
import { CheckCircleIcon } from '@chakra-ui/icons';

interface AIAnalysis {
  patterns: string[];
  suggestions: string;
  actions: string[];
}

export default function AIExerciseAnalysis() {
  const [exerciseResponse, setExerciseResponse] = useState('');
  const [analysis, setAnalysis] = useState<AIAnalysis | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const toast = useToast();

  const analyzeExercise = async () => {
    setIsAnalyzing(true);
    try {
      const response = await fetch('/api/ai/analyze-exercise', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          content: exerciseResponse,
          exerciseType: 'thought-record',
          context: {
            currentModule: 'financial-thoughts',
            progress: 60
          }
        })
      });

      if (!response.ok) {
        throw new Error('Analysis failed');
      }

      const data = await response.json();
      setAnalysis(data);
    } catch (error) {
      toast({
        title: 'Analysis failed',
        description: 'Unable to analyze your response. Please try again.',
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  return (
    <VStack spacing={6} align="stretch">
      <FormControl>
        <FormLabel fontWeight="medium">Your Exercise Response</FormLabel>
        <Textarea
          value={exerciseResponse}
          onChange={(e) => setExerciseResponse(e.target.value)}
          minH="32"
          placeholder="Describe your financial thought pattern..."
          resize="vertical"
        />
      </FormControl>

      <Button
        onClick={analyzeExercise}
        isLoading={isAnalyzing}
        isDisabled={!exerciseResponse.trim()}
        colorScheme="blue"
        size="lg"
        bgGradient="linear(to-r, blue.500, purple.500)"
        _hover={{
          bgGradient: "linear(to-r, blue.600, purple.600)",
        }}
      >
        Get AI Feedback
      </Button>

      {analysis && (
        <Box bg="gray.50" p={6} rounded="lg" shadow="sm">
          <VStack spacing={4} align="stretch">
            <Heading size="md" color="gray.900">
              AI Analysis
            </Heading>

            <Box>
              <Text fontWeight="medium" mb={2}>
                Identified Patterns
              </Text>
              <List spacing={2}>
                {analysis.patterns.map((pattern, index) => (
                  <ListItem key={index} display="flex" alignItems="center">
                    <ListIcon as={CheckCircleIcon} color="blue.500" />
                    <Text color="gray.700">{pattern}</Text>
                  </ListItem>
                ))}
              </List>
            </Box>

            <Box>
              <Text fontWeight="medium" mb={2}>
                Suggested Reframes
              </Text>
              <Text color="gray.700">{analysis.suggestions}</Text>
            </Box>

            <Box>
              <Text fontWeight="medium" mb={2}>
                Recommended Actions
              </Text>
              <List spacing={3}>
                {analysis.actions.map((action, index) => (
                  <ListItem
                    key={index}
                    display="flex"
                    alignItems="center"
                    gap={3}
                  >
                    <Circle
                      size="6"
                      bg="blue.100"
                      color="blue.600"
                      fontSize="sm"
                      fontWeight="bold"
                    >
                      {index + 1}
                    </Circle>
                    <Text color="gray.700">{action}</Text>
                  </ListItem>
                ))}
              </List>
            </Box>
          </VStack>
        </Box>
      )}
    </VStack>
  );
}