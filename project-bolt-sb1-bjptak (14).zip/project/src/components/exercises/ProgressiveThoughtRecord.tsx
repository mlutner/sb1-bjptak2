import { useState } from 'react';
import { Box, Stepper, Step, StepIndicator, StepStatus, StepIcon, StepNumber, StepTitle, StepDescription, useSteps, StepSeparator, useToast } from '@chakra-ui/react';
import ThoughtInput from './ThoughtInput';
import EmotionInput from './EmotionInput';
import BehaviorInput from './BehaviorInput';
import { useAIResponse } from '../../hooks/useAIResponse';
import type { ThoughtRecord, ThoughtAnalysis } from '../../types/exercises';

const steps = [
  { title: 'Thought', description: 'Record your thought' },
  { title: 'Emotions', description: 'Identify emotions' },
  { title: 'Behavior', description: 'Note your behavior' },
];

async function mockAnalyzeThought(): Promise<ThoughtAnalysis> {
  // Simulate API delay
  await new Promise(resolve => setTimeout(resolve, 1000));
  return {
    distortions: ['catastrophizing', 'black-and-white thinking'],
    recommendations: ['Consider alternative perspectives', 'Look for evidence'],
    emotionalImpact: 'moderate',
  };
}

export default function ProgressiveThoughtRecord() {
  const { activeStep, setActiveStep } = useSteps({
    index: 0,
    count: steps.length,
  });
  const [record, setRecord] = useState<Partial<ThoughtRecord>>({});
  const toast = useToast();

  const { execute: analyzeThought, loading } = useAIResponse(mockAnalyzeThought, {
    onError: (error) => {
      toast({
        title: 'Analysis failed',
        description: error.message,
        status: 'error',
        duration: 5000,
        isClosable: true,
      });
    },
  });

  const handleStepComplete = async (stepData: Partial<ThoughtRecord>) => {
    try {
      const analysis = activeStep === 0 
        ? await analyzeThought(stepData.thought || '')
        : null;
      
      setRecord(prev => ({ ...prev, ...stepData }));
      if (analysis) {
        setRecord(prev => ({ ...prev, analysis }));
      }
      setActiveStep(activeStep + 1);
    } catch (error) {
      console.error('Error processing step:', error);
    }
  };

  return (
    <Box maxW="container.md" mx="auto" p={6}>
      <Stepper index={activeStep} mb={8}>
        {steps.map((step, index) => (
          <Step key={index}>
            <StepIndicator>
              <StepStatus
                complete={<StepIcon />}
                incomplete={<StepNumber />}
                active={<StepNumber />}
              />
            </StepIndicator>
            <Box flexShrink='0'>
              <StepTitle>{step.title}</StepTitle>
              <StepDescription>{step.description}</StepDescription>
            </Box>
            <StepSeparator />
          </Step>
        ))}
      </Stepper>

      {activeStep === 0 && (
        <ThoughtInput 
          onComplete={handleStepComplete}
          isLoading={loading}
        />
      )}
      {activeStep === 1 && record.analysis && (
        <EmotionInput 
          thoughtAnalysis={record.analysis}
          onComplete={handleStepComplete}
        />
      )}
      {activeStep === 2 && (
        <BehaviorInput 
          previousAnalysis={record.analysis || null}
          onComplete={handleStepComplete}
        />
      )}
    </Box>
  );
}</content>