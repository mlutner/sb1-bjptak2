import { VStack, Button, Text, Box, HStack, Icon } from '@chakra-ui/react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface Option {
  value: string;
  label: string;
}

interface Props {
  question: string;
  options: Option[];
  currentResponse?: string;
  onAnswer: (value: string) => void;
  onNext: () => void;
  onPrevious: () => void;
  isLastQuestion: boolean;
}

export default function AssessmentQuestion({
  question,
  options,
  currentResponse,
  onAnswer,
  onNext,
  onPrevious,
  isLastQuestion,
}: Props) {
  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text fontSize="xl" fontWeight="semibold" mb={4}>{question}</Text>
        <VStack spacing={3} align="stretch">
          {options.map((option) => (
            <Button
              key={option.value}
              onClick={() => onAnswer(option.value)}
              variant={currentResponse === option.value ? 'solid' : 'outline'}
              colorScheme="blue"
              justifyContent="flex-start"
              p={4}
              h="auto"
              whiteSpace="normal"
              textAlign="left"
            >
              {option.label}
            </Button>
          ))}
        </VStack>
      </Box>

      <HStack justify="space-between">
        <Button
          leftIcon={<Icon as={ChevronLeft} />}
          variant="ghost"
          onClick={onPrevious}
        >
          Back
        </Button>
        <Button
          rightIcon={<Icon as={ChevronRight} />}
          colorScheme="blue"
          onClick={onNext}
          isDisabled={!currentResponse}
        >
          {isLastQuestion ? 'Complete' : 'Continue'}
        </Button>
      </HStack>
    </VStack>
  );
}