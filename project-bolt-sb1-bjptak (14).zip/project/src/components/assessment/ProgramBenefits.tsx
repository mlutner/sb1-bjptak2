import { Grid, GridItem, Box, Heading, Text } from '@chakra-ui/react';

interface Benefit {
  title: string;
  description: string;
  metrics: string;
}

interface Props {
  benefits: Benefit[];
}

export default function ProgramBenefits({ benefits }: Props) {
  return (
    <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={4}>
      {benefits.map((benefit, index) => (
        <GridItem key={index}>
          <Box bg="white" p={4} rounded="xl" shadow="sm">
            <Heading size="sm" mb={2}>{benefit.title}</Heading>
            <Text color="gray.600" fontSize="sm" mb={2}>{benefit.description}</Text>
            <Text color="blue.600" fontSize="sm" fontWeight="medium">{benefit.metrics}</Text>
          </Box>
        </GridItem>
      ))}
    </Grid>
  );
}