import {
  Box,
  Button,
  Card,
  CardBody,
  Heading,
  VStack,
  HStack,
  Text,
  Avatar,
  Badge,
  Icon,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';
import { FiVideo, FiPhone, FiMessageSquare, FiCalendar } from 'react-icons/fi';
import { Professional } from '../../types/consultation';

const CONSULTATION_TYPES = [
  { id: 'video', icon: FiVideo, label: 'Video Call' },
  { id: 'phone', icon: FiPhone, label: 'Phone Call' },
  { id: 'chat', icon: FiMessageSquare, label: 'Chat Session' },
];

const TIME_SLOTS = [
  '9:00 AM', '10:00 AM', '11:00 AM',
  '2:00 PM', '3:00 PM', '4:00 PM',
];

export default function ConsultationBooking() {
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const toast = useToast();

  const handleBooking = () => {
    if (!selectedType || !selectedTime) {
      toast({
        title: 'Please select both consultation type and time',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    toast({
      title: 'Consultation Booked!',
      description: `Your ${selectedType} consultation is scheduled for ${selectedTime}`,
      status: 'success',
      duration: 5000,
    });
  };

  return (
    <Box maxW="3xl" mx="auto">
      <Card>
        <CardBody>
          <VStack spacing={8} align="stretch">
            <Box>
              <Heading size="md" mb={4}>Select Consultation Type</Heading>
              <HStack spacing={4}>
                {CONSULTATION_TYPES.map(({ id, icon, label }) => (
                  <Button
                    key={id}
                    variant={selectedType === id ? 'solid' : 'outline'}
                    colorScheme="purple"
                    leftIcon={<Icon as={icon} />}
                    onClick={() => setSelectedType(id)}
                    size="lg"
                    flex={1}
                  >
                    {label}
                  </Button>
                ))}
              </HStack>
            </Box>

            <Box>
              <Heading size="md" mb={4}>Select Time Slot</Heading>
              <VStack spacing={4} align="stretch">
                {TIME_SLOTS.map((time) => (
                  <Button
                    key={time}
                    variant={selectedTime === time ? 'solid' : 'outline'}
                    colorScheme="purple"
                    onClick={() => setSelectedTime(time)}
                    leftIcon={<Icon as={FiCalendar} />}
                    justifyContent="flex-start"
                  >
                    {time}
                  </Button>
                ))}
              </VStack>
            </Box>

            <Button
              size="lg"
              colorScheme="purple"
              isDisabled={!selectedType || !selectedTime}
              onClick={handleBooking}
            >
              Confirm Booking
            </Button>
          </VStack>
        </CardBody>
      </Card>
    </Box>
  );
}