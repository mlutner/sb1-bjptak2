import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Progress,
  Text,
  VStack,
  Badge,
  Icon,
  useDisclosure,
} from '@chakra-ui/react';
import { FiTarget, FiTrendingUp, FiCalendar, FiCheckCircle } from 'react-icons/fi';

interface SmartGoal {
  id: string;
  title: string;
  target: string;
  deadline: string;
  progress: number;
  category: 'savings' | 'spending' | 'debt' | 'investment';
}

const demoGoals: SmartGoal[] = [
  {
    id: '1',
    title: 'Emergency Fund',
    target: 'Save $5,000',
    deadline: '6 months',
    progress: 60,
    category: 'savings'
  },
  {
    id: '2',
    title: 'Reduce Monthly Spending',
    target: 'Cut expenses by 20%',
    deadline: '3 months',
    progress: 45,
    category: 'spending'
  },
  {
    id: '3',
    title: 'Credit Card Debt',
    target: 'Pay off $3,000',
    deadline: '4 months',
    progress: 75,
    category: 'debt'
  }
];

const getCategoryColor = (category: string) => {
  switch (category) {
    case 'savings': return 'green';
    case 'spending': return 'purple';
    case 'debt': return 'red';
    case 'investment': return 'blue';
    default: return 'gray';
  }
};

export default function SmartGoalsPanel() {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Card>
      <CardHeader>
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md">SMART Goals</Heading>
            <Text color="gray.600" mt={1}>Track your financial objectives</Text>
          </Box>
          <Button
            colorScheme="purple"
            variant="outline"
            size="sm"
            leftIcon={<Icon as={FiTarget} />}
          >
            Add Goal
          </Button>
        </Flex>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          {demoGoals.map((goal) => (
            <Box 
              key={goal.id}
              bg="gray.50"
              p={4}
              rounded="lg"
              borderLeft="4px"
              borderLeftColor={`${getCategoryColor(goal.category)}.500`}
            >
              <Flex justify="space-between" align="start" mb={2}>
                <Box>
                  <Badge 
                    colorScheme={getCategoryColor(goal.category)}
                    mb={2}
                  >
                    {goal.category.charAt(0).toUpperCase() + goal.category.slice(1)}
                  </Badge>
                  <Text fontWeight="medium">{goal.title}</Text>
                </Box>
                <Icon 
                  as={goal.progress >= 100 ? FiCheckCircle : FiTrendingUp} 
                  color={goal.progress >= 100 ? 'green.500' : 'gray.500'}
                />
              </Flex>

              <Text fontSize="sm" color="gray.600" mb={2}>
                Target: {goal.target}
              </Text>

              <Progress 
                value={goal.progress} 
                size="sm" 
                colorScheme={getCategoryColor(goal.category)}
                rounded="full"
                mb={2}
              />

              <Flex justify="space-between" align="center">
                <Flex align="center" gap={1} color="gray.600">
                  <Icon as={FiCalendar} boxSize={3} />
                  <Text fontSize="xs">
                    {goal.deadline} remaining
                  </Text>
                </Flex>
                <Text fontSize="xs" fontWeight="medium">
                  {goal.progress}% complete
                </Text>
              </Flex>
            </Box>
          ))}

          <Button
            variant="ghost"
            colorScheme="purple"
            size="sm"
            w="full"
          >
            View All Goals
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}