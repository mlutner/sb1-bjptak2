import {
  Box,
  Button,
  Card,
  CardBody,
  Container,
  Flex,
  Grid,
  Heading,
  Icon,
  Image,
  Text,
  VStack,
  useBreakpointValue,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { 
  FiTarget, 
  FiHeart, 
  FiActivity, 
  FiShield, 
  FiTrendingUp, 
  FiPieChart, 
  FiCompass, 
  FiBook 
} from 'react-icons/fi';

const modules = [
  {
    id: 1,
    title: 'Goal Setting & Initial Assessment',
    description: 'Establish your financial and wellness goals',
    icon: FiTarget,
    image: 'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/1'
  },
  {
    id: 2,
    title: 'Understanding Money Emotions',
    description: 'Explore the emotional aspects of financial decisions',
    icon: FiHeart,
    image: 'https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/2'
  },
  {
    id: 3,
    title: 'Identifying Triggers',
    description: 'Recognize patterns in financial behavior',
    icon: FiActivity,
    image: 'https://images.unsplash.com/photo-1434626881859-194d67b2b86f?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/3'
  },
  {
    id: 4,
    title: 'Developing Coping Strategies',
    description: 'Build resilience against financial stress',
    icon: FiShield,
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/4'
  },
  {
    id: 5,
    title: 'Building Healthy Habits',
    description: 'Create sustainable financial practices',
    icon: FiTrendingUp,
    image: 'https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/5'
  },
  {
    id: 6,
    title: 'Financial Decision Making',
    description: 'Improve your financial choices',
    icon: FiPieChart,
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/6'
  },
  {
    id: 7,
    title: 'Stress Management',
    description: 'Handle financial pressure effectively',
    icon: FiCompass,
    image: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/7'
  },
  {
    id: 8,
    title: 'Long-term Wellness Planning',
    description: 'Maintain financial well-being',
    icon: FiBook,
    image: 'https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?auto=format&fit=crop&w=600&q=80',
    path: '/cbt-program/module/8'
  }
];

export default function ProgramOverview() {
  const navigate = useNavigate();
  const isMobile = useBreakpointValue({ base: true, md: false });

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        {/* Hero Section */}
        <Box
          position="relative"
          height={{ base: "200px", md: "400px" }}
          borderRadius="xl"
          overflow="hidden"
          mb={8}
        >
          <Image
            src="https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&w=1200&q=80"
            alt="Financial Wellness Journey"
            objectFit="cover"
            w="100%"
            h="100%"
          />
          <Box
            position="absolute"
            top={0}
            left={0}
            right={0}
            bottom={0}
            bg="blackAlpha.600"
            p={8}
            display="flex"
            flexDirection="column"
            justifyContent="flex-end"
            color="white"
          >
            <Heading size="2xl" mb={4}>
              Your Financial Wellness Journey
            </Heading>
            <Text fontSize="xl">
              An 8-module CBT program designed to transform your relationship with money
            </Text>
          </Box>
        </Box>

        {/* Modules Grid */}
        <Grid 
          templateColumns={{ 
            base: "1fr",
            md: "repeat(2, 1fr)", 
            lg: "repeat(3, 1fr)",
            xl: "repeat(4, 1fr)" 
          }}
          gap={6}
        >
          {modules.map((module) => (
            <Card
              key={module.id}
              onClick={() => navigate(module.path)}
              cursor="pointer"
              _hover={{
                transform: "translateY(-4px)",
                shadow: "lg",
              }}
              transition="all 0.2s"
              overflow="hidden"
            >
              <Box position="relative" height="160px">
                <Image
                  src={module.image}
                  alt={module.title}
                  objectFit="cover"
                  w="100%"
                  h="100%"
                />
                <Box
                  position="absolute"
                  top={0}
                  left={0}
                  right={0}
                  bottom={0}
                  bg="blackAlpha.400"
                  transition="all 0.2s"
                  _groupHover={{ bg: "blackAlpha.500" }}
                />
              </Box>
              
              <CardBody>
                <VStack spacing={2} align="start">
                  <Flex align="center" gap={2}>
                    <Icon as={module.icon} color="purple.500" boxSize={5} />
                    <Text fontWeight="bold">Module {module.id}</Text>
                  </Flex>
                  <Heading size="sm">{module.title}</Heading>
                  <Text color="gray.600" fontSize="sm">
                    {module.description}
                  </Text>
                  <Button
                    size="sm"
                    colorScheme="purple"
                    variant="ghost"
                    alignSelf="flex-end"
                    mt={2}
                  >
                    Start Module
                  </Button>
                </VStack>
              </CardBody>
            </Card>
          ))}
        </Grid>
      </VStack>
    </Container>
  );
}