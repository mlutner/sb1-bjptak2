import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Grid,
  Heading,
  Image,
  Text,
  VStack,
  Icon,
  Flex,
} from '@chakra-ui/react';
import { useState } from 'react';
import { FiPlay } from 'react-icons/fi';
import AudioPlayer from '../AudioPlayer';
import VideoLesson from './VideoLesson';
import MoneyBeliefsWorksheet from './exercises/MoneyBeliefsWorksheet';
import EmotionalSpendingLog from './exercises/EmotionalSpendingLog';

export default function Module2Intro() {
  const [currentStep, setCurrentStep] = useState(0);
  const steps = ['intro', 'video', 'beliefs', 'spending'];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStep = () => {
    switch (steps[currentStep]) {
      case 'intro':
        return (
          <VStack spacing={6} align="stretch">
            <Box
              h="300px"
              overflow="hidden"
              borderRadius="xl"
              position="relative"
            >
              <Image
                src="https://images.unsplash.com/photo-1434626881859-194d67b2b86f?auto=format&fit=crop&q=80"
                alt="Understanding Emotions"
                objectFit="cover"
                w="full"
                h="full"
              />
              {/* Overlay */}
              <Box
                position="absolute"
                top={0}
                left={0}
                right={0}
                bottom={0}
                bg="blackAlpha.600"
                p={6}
                display="flex"
                flexDirection="column"
                justifyContent="flex-end"
              >
                <Heading color="white" size="lg" mb={2}>
                  Understanding Money Emotions
                </Heading>
                <Text color="whiteAlpha.900">
                  Module 2: Explore the emotional aspects of financial decisions
                </Text>
              </Box>
            </Box>

            <AudioPlayer 
              title="Understanding Money Emotions" 
              duration="3:15"
            />

            <Text>
              Welcome to Module 2: Understanding Money Emotions. In this module,
              we'll explore the emotional aspects of your financial decisions and
              develop strategies for emotional awareness.
            </Text>
          </VStack>
        );

      case 'video':
        return (
          <Box position="relative">
            <VideoLesson
              videoUrl="/module2-video.mp4"
              onComplete={handleNext}
            />
            <Flex
              position="absolute"
              top="50%"
              left="50%"
              transform="translate(-50%, -50%)"
              bg="blackAlpha.700"
              rounded="full"
              p={4}
              color="white"
              fontSize="3xl"
            >
              <Icon as={FiPlay} />
            </Flex>
          </Box>
        );

      case 'beliefs':
        return (
          <MoneyBeliefsWorksheet
            onComplete={handleNext}
          />
        );

      case 'spending':
        return (
          <EmotionalSpendingLog
            onComplete={handleNext}
          />
        );

      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <VStack align="stretch" spacing={4}>
          <Heading size="lg">Understanding Money Emotions</Heading>
          <Text color="gray.600">
            Module 2: Explore the emotional aspects of financial decisions
          </Text>
        </VStack>
      </CardHeader>

      <CardBody>
        {renderStep()}

        <Box pb={{ base: "100px", md: "20px" }}>
          <Grid templateColumns="repeat(2, 1fr)" gap={4} mt={6}>
            <Button
              onClick={handlePrevious}
              isDisabled={currentStep === 0}
              variant="outline"
            >
              Previous
            </Button>
            <Button
              onClick={handleNext}
              colorScheme="purple"
            >
              {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
            </Button>
          </Grid>
        </Box>
      </CardBody>
    </Card>
  );
}