import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Grid,
  Heading,
  Image,
  Text,
  VStack,
  Icon,
  Flex,
} from '@chakra-ui/react';
import { useState } from 'react';
import { FiPlay } from 'react-icons/fi';
import AudioPlayer from '../AudioPlayer';
import VideoLesson from './VideoLesson';
import TriggerIdentificationExercise from './exercises/TriggerIdentificationExercise';
import SpendingPatternAnalysis from './exercises/SpendingPatternAnalysis';

interface Props {
  onComplete?: () => void;
}

export default function Module3Intro({ onComplete }: Props) {
  const [currentStep, setCurrentStep] = useState(0);
  const steps = ['intro', 'video', 'triggers', 'patterns'];

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else if (onComplete) {
      onComplete();
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const renderStep = () => {
    switch (steps[currentStep]) {
      case 'intro':
        return (
          <VStack spacing={6} align="stretch">
            <Box
              h="300px"
              overflow="hidden"
              borderRadius="xl"
              position="relative"
            >
              <Image
                src="https://images.unsplash.com/photo-1553729459-efe14ef6055d?auto=format&fit=crop&q=80"
                alt="Identifying Triggers"
                objectFit="cover"
                w="full"
                h="full"
              />
              {/* Overlay */}
              <Box
                position="absolute"
                top={0}
                left={0}
                right={0}
                bottom={0}
                bg="blackAlpha.600"
                p={6}
                display="flex"
                flexDirection="column"
                justifyContent="flex-end"
              >
                <Heading color="white" size="lg" mb={2}>
                  Identifying Financial Triggers
                </Heading>
                <Text color="whiteAlpha.900">
                  Module 3: Recognize and understand your spending patterns
                </Text>
              </Box>
            </Box>

            <AudioPlayer 
              title="Understanding Financial Triggers" 
              duration="2:45"
            />

            <Text>
              Welcome to Module 3: Identifying Financial Triggers. In this module,
              we'll help you recognize patterns in your financial behavior and develop
              strategies to manage emotional spending triggers effectively.
            </Text>

            <Box bg="purple.50" p={6} rounded="lg">
              <Heading size="md" mb={4}>What You'll Learn</Heading>
              <VStack spacing={3} align="stretch">
                <Text>• How to identify emotional and situational spending triggers</Text>
                <Text>• Understanding your personal spending patterns</Text>
                <Text>• Developing awareness of financial decision-making</Text>
                <Text>• Creating strategies to manage triggers effectively</Text>
              </VStack>
            </Box>
          </VStack>
        );

      case 'video':
        return (
          <Box position="relative">
            <VideoLesson
              moduleId={3}
              onComplete={handleNext}
            />
            <Flex
              position="absolute"
              top="50%"
              left="50%"
              transform="translate(-50%, -50%)"
              bg="blackAlpha.700"
              rounded="full"
              p={4}
              color="white"
              fontSize="3xl"
            >
              <Icon as={FiPlay} />
            </Flex>
          </Box>
        );

      case 'triggers':
        return (
          <TriggerIdentificationExercise
            onComplete={handleNext}
          />
        );

      case 'patterns':
        return (
          <SpendingPatternAnalysis
            onComplete={handleNext}
          />
        );

      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <VStack spacing={4} align="stretch">
          <Heading size="lg">Identifying Financial Triggers</Heading>
          <Text color="gray.600">
            Module 3: Learn to recognize and manage your spending triggers
          </Text>
        </VStack>
      </CardHeader>

      <CardBody>
        {renderStep()}

        <Box pb={{ base: "100px", md: "20px" }}>
          <Grid templateColumns="repeat(2, 1fr)" gap={4} mt={6}>
            <Button
              onClick={handlePrevious}
              isDisabled={currentStep === 0}
              variant="outline"
            >
              Previous
            </Button>
            <Button
              onClick={handleNext}
              colorScheme="purple"
            >
              {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
            </Button>
          </Grid>
        </Box>
      </CardBody>
    </Card>
  );
}