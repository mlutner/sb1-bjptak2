import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  Textarea,
  Progress,
  Grid,
  GridItem,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: () => void;
}

export default function MoneyBeliefsWorksheet({ onComplete }: Props) {
  const [beliefs, setBeliefs] = useState({
    childhood: '',
    family: '',
    current: '',
    challenge: '',
    newBelief: '',
    action: ''
  });

  const isComplete = Object.values(beliefs).every(value => value.trim() !== '');
  const progress = (Object.values(beliefs).filter(value => value.trim() !== '').length / 6) * 100;

  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text mb={2}>Worksheet Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
        <GridItem>
          <FormControl>
            <FormLabel>What money messages did you receive in childhood?</FormLabel>
            <Textarea
              value={beliefs.childhood}
              onChange={(e) => setBeliefs({ ...beliefs, childhood: e.target.value })}
              placeholder="Example: Money doesn't grow on trees..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>How did your family handle money?</FormLabel>
            <Textarea
              value={beliefs.family}
              onChange={(e) => setBeliefs({ ...beliefs, family: e.target.value })}
              placeholder="Describe your family's financial habits..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>What are your current money beliefs?</FormLabel>
            <Textarea
              value={beliefs.current}
              onChange={(e) => setBeliefs({ ...beliefs, current: e.target.value })}
              placeholder="I believe money is..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Challenge one limiting belief:</FormLabel>
            <Textarea
              value={beliefs.challenge}
              onChange={(e) => setBeliefs({ ...beliefs, challenge: e.target.value })}
              placeholder="This belief might not be true because..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Create a new empowering belief:</FormLabel>
            <Input
              value={beliefs.newBelief}
              onChange={(e) => setBeliefs({ ...beliefs, newBelief: e.target.value })}
              placeholder="A more helpful belief would be..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Action step to reinforce new belief:</FormLabel>
            <Input
              value={beliefs.action}
              onChange={(e) => setBeliefs({ ...beliefs, action: e.target.value })}
              placeholder="I will..."
            />
          </FormControl>
        </GridItem>
      </Grid>

      <Button
        colorScheme="purple"
        onClick={onComplete}
        isDisabled={!isComplete}
      >
        Complete Worksheet
      </Button>
    </VStack>
  );
}