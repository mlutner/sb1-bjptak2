import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Grid,
  GridItem,
  Heading,
  Select,
} from '@chakra-ui/react';
import { Line, Pie } from 'react-chartjs-2';

const engagementData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Active Users',
      data: [420, 480, 540, 600, 650, 700],
      borderColor: 'rgb(124, 58, 237)',
      tension: 0.1,
    },
    {
      label: 'Sessions Completed',
      data: [840, 960, 1080, 1200, 1300, 1400],
      borderColor: 'rgb(59, 130, 246)',
      tension: 0.1,
    }
  ],
};

const departmentData = {
  labels: ['Sales', 'Engineering', 'Marketing', 'HR', 'Finance'],
  datasets: [
    {
      data: [150, 200, 80, 40, 60],
      backgroundColor: [
        'rgba(124, 58, 237, 0.8)',
        'rgba(59, 130, 246, 0.8)',
        'rgba(34, 197, 94, 0.8)',
        'rgba(249, 115, 22, 0.8)',
        'rgba(236, 72, 153, 0.8)',
      ],
    },
  ],
};

const options = {
  responsive: true,
  plugins: {
    legend: {
      position: 'top' as const,
    },
  },
};

export default function AdminCharts() {
  return (
    <Grid templateColumns={{ base: '1fr', lg: '2fr 1fr' }} gap={6}>
      <GridItem>
        <Card>
          <CardHeader>
            <Heading size="md">User Engagement Trends</Heading>
          </CardHeader>
          <CardBody>
            <Box h="300px">
              <Line options={options} data={engagementData} />
            </Box>
          </CardBody>
        </Card>
      </GridItem>

      <GridItem>
        <Card>
          <CardHeader>
            <Heading size="md">Department Distribution</Heading>
          </CardHeader>
          <CardBody>
            <Box h="300px">
              <Pie data={departmentData} />
            </Box>
          </CardBody>
        </Card>
      </GridItem>
    </Grid>
  );
}