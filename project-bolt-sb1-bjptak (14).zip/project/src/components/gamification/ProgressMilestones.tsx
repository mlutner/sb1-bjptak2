import {
  Box,
  Card,
  CardBody,
  Progress,
  Text,
  VStack,
  HStack,
  Icon,
  Tooltip,
} from '@chakra-ui/react';
import { FiStar, FiAward, FiTrendingUp } from 'react-icons/fi';

interface Milestone {
  points: number;
  title: string;
  description: string;
  icon: any;
  unlocked: boolean;
}

const milestones: Milestone[] = [
  {
    points: 100,
    title: 'Getting Started',
    description: 'Complete your first assessment',
    icon: FiStar,
    unlocked: true
  },
  {
    points: 250,
    title: 'Consistent Tracker',
    description: '7-day streak of mood tracking',
    icon: FiTrendingUp,
    unlocked: false
  },
  {
    points: 500,
    title: 'Financial Master',
    description: 'Complete all core modules',
    icon: FiAward,
    unlocked: false
  }
];

export default function ProgressMilestones() {
  const currentPoints = 150;
  const nextMilestone = milestones.find(m => !m.unlocked);
  const progress = nextMilestone 
    ? (currentPoints / nextMilestone.points) * 100
    : 100;

  return (
    <Card>
      <CardBody>
        <VStack spacing={6} align="stretch">
          <Box>
            <Text fontWeight="medium" mb={2}>Your Progress</Text>
            <Progress
              value={progress}
              size="sm"
              colorScheme="purple"
              rounded="full"
              mb={2}
            />
            <Text fontSize="sm" color="gray.600">
              {currentPoints} / {nextMilestone?.points || 'Max'} Points
            </Text>
          </Box>

          <VStack spacing={4}>
            {milestones.map((milestone, index) => (
              <HStack
                key={index}
                w="full"
                bg={milestone.unlocked ? 'purple.50' : 'gray.50'}
                p={3}
                rounded="lg"
                opacity={milestone.unlocked ? 1 : 0.7}
              >
                <Tooltip label={milestone.description}>
                  <Box>
                    <Icon
                      as={milestone.icon}
                      color={milestone.unlocked ? 'purple.500' : 'gray.400'}
                      boxSize={5}
                    />
                  </Box>
                </Tooltip>
                <Box flex={1}>
                  <Text fontWeight="medium">{milestone.title}</Text>
                  <Text fontSize="sm" color="gray.600">
                    {milestone.points} Points
                  </Text>
                </Box>
                {milestone.unlocked && (
                  <Icon as={FiStar} color="yellow.400" />
                )}
              </HStack>
            ))}
          </VStack>
        </VStack>
      </CardBody>
    </Card>
  );
}