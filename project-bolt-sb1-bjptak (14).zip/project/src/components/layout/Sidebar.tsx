import {
  Box,
  Button,
  Container,
  Flex,
  IconButton,
  Image,
  Text,
  VStack,
  Icon,
  Divider,
  useDisclosure,
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  Avatar,
} from '@chakra-ui/react';
import { Link, useLocation } from 'react-router-dom';
import { 
  FiMenu, 
  FiHome, 
  FiBookOpen, 
  FiTarget, 
  FiDollarSign, 
  FiPieChart, 
  FiCalendar,
  FiAward,
  FiDatabase
} from 'react-icons/fi';
import { useUIStore } from '../../lib/cache/store';

const NAV_ITEMS = [
  { name: 'Dashboard', icon: FiHome, path: '/' },
  { name: 'Learning Path', icon: FiBookOpen, path: '/cbt-program' },
  { name: 'Goals', icon: FiTarget, path: '/goals' },
  { name: 'Expenses', icon: FiDollarSign, path: '/expenses' },
  { name: 'Savings', icon: FiDatabase, path: '/savings' },
  { name: 'Calendar', icon: FiCalendar, path: '/calendar' },
  { name: 'Achievements', icon: FiAward, path: '/achievements' },
];

export default function Sidebar() {
  const location = useLocation();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const isCollapsed = useUIStore(state => state.sidebarCollapsed);
  const toggleSidebar = useUIStore(state => state.toggleSidebar);

  const SidebarContent = () => (
    <Box
      bg="white"
      borderRight="1px"
      borderRightColor="gray.200"
      w={isCollapsed ? '20' : '64'}
      pos="fixed"
      h="full"
      shadow="md"
      zIndex="sticky"
    >
      <Flex h="20" alignItems="center" mx={isCollapsed ? 2 : 8} justifyContent="space-between">
        {!isCollapsed && (
          <Flex alignItems="center" gap={3}>
            <Avatar
              size="sm"
              name="Demo User"
              src="/images/demo-avatar.svg"
              bg="purple.500"
            />
            <Text fontSize="2xl" fontWeight="bold" color="purple.600">
              FinWell
            </Text>
          </Flex>
        )}
        <IconButton
          display={{ base: 'flex', md: 'none' }}
          onClick={onClose}
          variant="ghost"
          aria-label="close menu"
          icon={<FiMenu />}
        />
        <IconButton
          display={{ base: 'none', md: 'flex' }}
          onClick={toggleSidebar}
          variant="ghost"
          aria-label={isCollapsed ? 'expand menu' : 'collapse menu'}
          icon={isCollapsed ? <FiMenu /> : <FiMenu />}
          size="lg"
          _hover={{
            bg: 'purple.50',
            transform: 'scale(1.1)',
          }}
          transition="all 0.2s"
        />
      </Flex>

      <VStack spacing={1} align="stretch" h="calc(100vh - 80px)" justify="space-between">
        <VStack spacing={1} align="stretch">
          {NAV_ITEMS.map((item) => (
            <Link key={item.name} to={item.path}>
              <Flex
                align="center"
                p="4"
                mx={isCollapsed ? '2' : '4'}
                borderRadius="lg"
                role="group"
                cursor="pointer"
                bg={location.pathname === item.path ? 'purple.50' : 'transparent'}
                color={location.pathname === item.path ? 'purple.600' : 'gray.600'}
                _hover={{
                  bg: 'purple.50',
                  color: 'purple.600',
                  transform: 'translateX(4px)',
                }}
                transition="all 0.2s"
              >
                <Icon
                  mr={isCollapsed ? '0' : '4'}
                  fontSize="18"
                  as={item.icon}
                />
                {!isCollapsed && (
                  <Text fontSize="sm" fontWeight="medium">{item.name}</Text>
                )}
              </Flex>
            </Link>
          ))}
        </VStack>
      </VStack>
    </Box>
  );

  return (
    <Box>
      <Box display={{ base: 'none', md: 'block' }}>
        <SidebarContent />
      </Box>
      <Drawer
        autoFocus={false}
        isOpen={isOpen}
        placement="left"
        onClose={onClose}
        returnFocusOnClose={false}
        onOverlayClick={onClose}
        size="full"
      >
        <DrawerOverlay />
        <DrawerContent>
          <SidebarContent />
        </DrawerContent>
      </Drawer>
    </Box>
  );
}