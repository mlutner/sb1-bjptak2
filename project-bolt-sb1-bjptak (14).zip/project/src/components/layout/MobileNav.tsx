import { Box, Flex, Icon, Text, VStack, useColorModeValue } from '@chakra-ui/react';
import { Link, useLocation } from 'react-router-dom';
import { FiHome, FiBookOpen, FiTarget, FiAward } from 'react-icons/fi';

const NAV_ITEMS = [
  { name: 'Home', icon: FiHome, path: '/' },
  { name: 'Learn', icon: FiBookOpen, path: '/cbt-program' },
  { name: 'Goals', icon: FiTarget, path: '/goals' },
  { name: 'Rewards', icon: FiAward, path: '/achievements' },
];

export default function MobileNav() {
  const location = useLocation();
  const bg = useColorModeValue('white', 'gray.800');
  const borderColor = useColorModeValue('gray.200', 'gray.700');

  return (
    <Box
      position="fixed"
      bottom={0}
      left={0}
      right={0}
      bg={bg}
      borderTop="1px"
      borderColor={borderColor}
      px={4}
      py={2}
      zIndex={1000}
    >
      <Flex justify="space-around">
        {NAV_ITEMS.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link key={item.name} to={item.path}>
              <VStack
                spacing={1}
                color={isActive ? 'purple.500' : 'gray.500'}
                _hover={{ color: 'purple.500' }}
                transition="all 0.2s"
              >
                <Icon as={item.icon} boxSize={6} />
                <Text fontSize="xs" fontWeight="medium">
                  {item.name}
                </Text>
              </VStack>
            </Link>
          );
        })}
      </Flex>
    </Box>
  );
}