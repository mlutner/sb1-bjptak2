import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  VStack,
  Button,
} from '@chakra-ui/react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentValues: {
    total: number;
    change: number;
    assets: number;
    liabilities: number;
  };
  onUpdate: (values: any) => void;
}

export default function UpdateNetWorthModal({ isOpen, onClose, currentValues, onUpdate }: Props) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const assets = Number(formData.get('assets'));
    const liabilities = Number(formData.get('liabilities'));
    const newTotal = assets - liabilities;
    const percentChange = ((newTotal - currentValues.total) / currentValues.total) * 100;

    onUpdate({
      total: newTotal,
      change: Number(percentChange.toFixed(1)),
      assets,
      liabilities
    });
    
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Update Net Worth</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <form onSubmit={handleSubmit}>
            <VStack spacing={4}>
              <FormControl>
                <FormLabel>Total Assets</FormLabel>
                <NumberInput defaultValue={currentValues.assets} min={0}>
                  <NumberInputField name="assets" />
                </NumberInput>
              </FormControl>

              <FormControl>
                <FormLabel>Total Liabilities</FormLabel>
                <NumberInput defaultValue={currentValues.liabilities} min={0}>
                  <NumberInputField name="liabilities" />
                </NumberInput>
              </FormControl>

              <Button type="submit" colorScheme="purple" w="full">
                Update Values
              </Button>
            </VStack>
          </form>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}