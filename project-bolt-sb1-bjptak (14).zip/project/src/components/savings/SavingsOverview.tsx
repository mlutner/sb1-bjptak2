import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Progress,
  VStack,
  Text,
  Flex,
  Button,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import UpdateSavingsModal from './UpdateSavingsModal';

interface SavingsGoal {
  name: string;
  current: number;
  target: number;
  color: string;
}

export default function SavingsOverview() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [goals, setGoals] = useState<SavingsGoal[]>([
    {
      name: "Emergency Fund",
      current: 5000,
      target: 10000,
      color: "blue.400"
    },
    {
      name: "Down Payment",
      current: 15000,
      target: 50000,
      color: "purple.400"
    },
    {
      name: "Vacation Fund",
      current: 2000,
      target: 5000,
      color: "green.400"
    }
  ]);

  return (
    <>
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center">
            <Heading size="md">Savings Goals</Heading>
            <Button
              colorScheme="purple"
              variant="outline"
              size="sm"
              onClick={onOpen}
            >
              Update Savings
            </Button>
          </Flex>
        </CardHeader>

        <CardBody>
          <VStack spacing={6} align="stretch">
            {goals.map((goal) => (
              <Box key={goal.name}>
                <Flex justify="space-between" mb={2}>
                  <Text fontWeight="medium">{goal.name}</Text>
                  <Text>
                    ${goal.current.toLocaleString()} / ${goal.target.toLocaleString()}
                  </Text>
                </Flex>
                <Progress
                  value={(goal.current / goal.target) * 100}
                  colorScheme={goal.color.split('.')[0]}
                  borderRadius="full"
                  size="sm"
                />
              </Box>
            ))}
          </VStack>
        </CardBody>
      </Card>

      <UpdateSavingsModal
        isOpen={isOpen}
        onClose={onClose}
        currentGoals={goals}
        onUpdate={setGoals}
      />
    </>
  );
}