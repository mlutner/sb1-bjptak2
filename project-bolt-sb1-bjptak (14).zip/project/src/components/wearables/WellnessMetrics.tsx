import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  SimpleGrid,
  CircularProgress,
  CircularProgressLabel,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  Icon,
} from '@chakra-ui/react';
import { FiHeart, FiActivity, FiMoon } from 'react-icons/fi';
import { useWearables } from '../../hooks/useWearables';

export default function WellnessMetrics() {
  const { metrics } = useWearables();

  if (!metrics) {
    return null;
  }

  return (
    <Card>
      <CardHeader>
        <Heading size="md">Wellness Metrics</Heading>
        <Text color="gray.600" mt={1}>
          Your physical and emotional wellness indicators
        </Text>
      </CardHeader>

      <CardBody>
        <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>Heart Rate</StatLabel>
                <StatNumber>
                  <Icon as={FiHeart} color="red.500" mr={2} />
                  {metrics.heartRate} BPM
                </StatNumber>
                <StatHelpText>Last 24 hours</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>Stress Level</StatLabel>
                <CircularProgress
                  value={metrics.stressLevel}
                  color={metrics.stressLevel > 70 ? 'red.400' : 'green.400'}
                  size="80px"
                >
                  <CircularProgressLabel>
                    {metrics.stressLevel}%
                  </CircularProgressLabel>
                </CircularProgress>
                <StatHelpText>Current</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>Sleep Quality</StatLabel>
                <StatNumber>
                  <Icon as={FiMoon} color="purple.500" mr={2} />
                  {metrics.sleepQuality}%
                </StatNumber>
                <StatHelpText>Last night</StatHelpText>
              </Stat>
            </CardBody>
          </Card>

          <Card variant="outline">
            <CardBody>
              <Stat>
                <StatLabel>Daily Steps</StatLabel>
                <StatNumber>
                  <Icon as={FiActivity} color="blue.500" mr={2} />
                  {metrics.steps.toLocaleString()}
                </StatNumber>
                <StatHelpText>Today</StatHelpText>
              </Stat>
            </CardBody>
          </Card>
        </SimpleGrid>
      </CardBody>
    </Card>
  );
}