import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  VStack,
  Text,
  Heading,
  Image,
  Card,
  CardBody,
  Container,
  Alert,
  AlertIcon,
  Grid,
  GridItem,
  Flex,
} from '@chakra-ui/react';
import { useAuth } from '../../contexts/AuthContext';

export default function SignIn() {
  const [loading, setLoading] = useState(false);
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleDemoLogin = async () => {
    setLoading(true);
    try {
      login();
      navigate('/assessment');
    } catch (error) {
      console.error('Login error:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box minH="100vh" position="relative" overflow="hidden">
      {/* Background Gradient */}
      <Box
        position="absolute"
        top={0}
        left={0}
        right={0}
        bottom={0}
        bgGradient="linear(to-br, purple.50, blue.50)"
        zIndex={0}
      />

      {/* Hero Image - Desktop Only */}
      <Box
        position="absolute"
        top="50%"
        right={0}
        transform="translateY(-50%)"
        w={{ base: "0", lg: "55%" }}
        h="90vh"
        display={{ base: 'none', lg: 'block' }}
        zIndex={1}
      >
        <Image
          src="https://images.unsplash.com/photo-1579621970563-ebec7560ff3e?auto=format&fit=crop&q=80"
          alt="Financial Wellness"
          objectFit="cover"
          w="full"
          h="full"
          borderLeftRadius="3xl"
          boxShadow="-10px 0 30px rgba(0,0,0,0.1)"
        />
        {/* Overlay Text */}
        <Box
          position="absolute"
          bottom={10}
          left={10}
          color="white"
          maxW="80%"
          p={6}
          bg="blackAlpha.600"
          borderRadius="xl"
          backdropFilter="blur(10px)"
        >
          <Heading size="lg" mb={2}>Begin Your Financial Wellness Journey</Heading>
          <Text fontSize="lg">
            Combine financial management with mental well-being for a balanced approach to your financial life.
          </Text>
        </Box>
      </Box>

      {/* Content */}
      <Container maxW="container.xl" py={12} position="relative" zIndex={2}>
        <Grid templateColumns={{ base: '1fr', lg: '1fr 1fr' }} gap={8}>
          <GridItem>
            <Card
              shadow="xl"
              maxW="md"
              mx="auto"
              bg="white"
              borderRadius="2xl"
              overflow="hidden"
              border="1px"
              borderColor="purple.100"
            >
              <CardBody>
                <VStack spacing={8}>
                  <Flex direction="column" align="center">
                    <Image 
                      src="/finwell-logo.svg" 
                      alt="FinWell Logo" 
                      boxSize="120px"
                      fallbackSrc="https://via.placeholder.com/120"
                    />
                    
                    <Heading 
                      as="h1" 
                      size="xl" 
                      bgGradient="linear(to-r, purple.600, blue.600)"
                      bgClip="text"
                      mt={4}
                    >
                      FinWell
                    </Heading>
                    
                    <Text fontSize="lg" color="gray.600" textAlign="center" mt={2}>
                      Your Financial Wellness Journey
                    </Text>
                  </Flex>

                  <Alert 
                    status="info" 
                    rounded="xl"
                    bg="blue.50"
                    border="1px"
                    borderColor="blue.100"
                  >
                    <AlertIcon />
                    <Text>
                      Welcome to FinWell! Start with a quick assessment to personalize your journey.
                    </Text>
                  </Alert>

                  <Button
                    w="full"
                    size="lg"
                    onClick={handleDemoLogin}
                    isLoading={loading}
                    bgGradient="linear(to-r, purple.500, blue.500)"
                    color="white"
                    _hover={{
                      bgGradient: "linear(to-r, purple.600, blue.600)",
                      transform: "translateY(-2px)",
                    }}
                    _active={{
                      bgGradient: "linear(to-r, purple.700, blue.700)",
                    }}
                    shadow="lg"
                    transition="all 0.2s"
                  >
                    Begin Your Journey
                  </Button>

                  <Text color="gray.500" fontSize="sm" textAlign="center">
                    This is a demo version with pre-populated data.<br />
                    No sign up required.
                  </Text>
                </VStack>
              </CardBody>
            </Card>
          </GridItem>
        </Grid>
      </Container>
    </Box>
  );
}