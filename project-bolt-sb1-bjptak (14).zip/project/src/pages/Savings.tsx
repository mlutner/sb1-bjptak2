import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  useDisclosure,
  VStack,
} from '@chakra-ui/react';
import NetWorthCard from '../components/savings/NetWorthCard';
import SavingsOverview from '../components/savings/SavingsOverview';
import InvestmentPortfolio from '../components/savings/InvestmentPortfolio';
import RRSPTracker from '../components/savings/RRSPTracker';

export default function Savings() {
  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        <Box>
          <Heading size="lg">Savings & Investments</Heading>
          <Text color="gray.600" mt={2}>
            Track your savings, investments, and net worth
          </Text>
        </Box>

        <NetWorthCard />

        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <SavingsOverview />
          <RRSPTracker />
        </Grid>

        <InvestmentPortfolio />
      </VStack>
    </Container>
  );
}