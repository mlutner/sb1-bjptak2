import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, db } from '../../config/firebase';
import { cacheHelpers } from '../cache/store';

const DEFAULT_PREFERENCES = {
  onboardingCompleted: false,
  isFirstTimeUser: true,
  theme: 'light',
  notifications: true,
};

const CACHE_KEY = 'user_preferences';

export async function getUserPreferences() {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) return DEFAULT_PREFERENCES;

    // Check cache first
    const cached = await cacheHelpers.get(`${CACHE_KEY}_${userId}`);
    if (cached) return cached;

    const preferencesRef = doc(db, 'userPreferences', userId);
    const preferencesDoc = await getDoc(preferencesRef);
    
    if (!preferencesDoc.exists()) {
      const defaultPrefs = {
        ...DEFAULT_PREFERENCES,
        userId,
        createdAt: new Date().toISOString()
      };
      
      await setDoc(preferencesRef, defaultPrefs);
      await cacheHelpers.set(`${CACHE_KEY}_${userId}`, defaultPrefs);
      return defaultPrefs;
    }

    const preferences = preferencesDoc.data();
    await cacheHelpers.set(`${CACHE_KEY}_${userId}`, preferences);
    return preferences;
  } catch (error) {
    console.error('Error getting user preferences:', error);
    return DEFAULT_PREFERENCES;
  }
}

export async function saveUserPreferences(preferences: any) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) throw new Error('User not authenticated');

    const data = {
      ...preferences,
      userId,
      updatedAt: new Date().toISOString()
    };

    const preferencesRef = doc(db, 'userPreferences', userId);
    await setDoc(preferencesRef, data, { merge: true });
    await cacheHelpers.set(`${CACHE_KEY}_${userId}`, data);
    return true;
  } catch (error) {
    console.error('Error saving user preferences:', error);
    throw error;
  }
}