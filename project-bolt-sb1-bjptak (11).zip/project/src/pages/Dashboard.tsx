import {
  Box,
  Container,
  Grid,
  GridItem,
  Heading,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import WearablesConnect from '../components/wearables/WearablesConnect';
import WellnessMetrics from '../components/wearables/WellnessMetrics';
import BankImportModal from '../components/bank/BankImportModal';
import { getUserPreferences } from '../lib/firebase/db';

export default function Dashboard() {
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [userName, setUserName] = useState('');

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const preferences = await getUserPreferences();
        if (preferences?.isFirstTimeUser) {
          setUserName('Welcome to FinWell! ');
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      }
    };

    loadUserData();
  }, []);

  return (
    <Container maxW="container.xl" py={8}>
      {/* Header */}
      <VStack spacing={4} align="center" mb={8}>
        <Heading size="lg">Dashboard</Heading>
        <Text color="gray.600" textAlign="center">
          {userName}Here's your financial wellness overview
        </Text>
      </VStack>

      {/* Bento Box Grid Layout */}
      <Grid
        templateColumns="repeat(12, 1fr)"
        templateRows="auto"
        gap={6}
        mx="auto"
      >
        {/* Learning Pathways - Spans full width */}
        <GridItem colSpan={{ base: 12, lg: 12 }} rowSpan={1}>
          <LearningPathways />
        </GridItem>

        {/* Financial Metrics - Left side */}
        <GridItem colSpan={{ base: 12, lg: 6 }} rowSpan={1}>
          <MetricsCard />
        </GridItem>

        {/* Spending Graph - Right side */}
        <GridItem colSpan={{ base: 12, lg: 6 }} rowSpan={1}>
          <SpendingGraph />
        </GridItem>

        {/* Mood Tracker - Center */}
        <GridItem colSpan={{ base: 12, lg: 6 }} rowSpan={1}>
          <MoodTracker />
        </GridItem>

        {/* Quick Actions - Right side */}
        <GridItem colSpan={{ base: 12, lg: 6 }} rowSpan={1}>
          <QuickActions />
        </GridItem>

        {/* Wearables Section - Left side */}
        <GridItem colSpan={{ base: 12, lg: 6 }} rowSpan={1}>
          <WearablesConnect onBankConnect={onOpen} />
        </GridItem>

        {/* Wellness Metrics - Right side */}
        <GridItem colSpan={{ base: 12, lg: 6 }} rowSpan={1}>
          <WellnessMetrics />
        </GridItem>
      </Grid>

      {/* Bank Connection Modal */}
      <BankImportModal isOpen={isOpen} onClose={onClose} />
    </Container>
  );
}