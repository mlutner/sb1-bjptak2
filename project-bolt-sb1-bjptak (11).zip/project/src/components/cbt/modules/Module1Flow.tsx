import { useState } from 'react';
import {
  Box,
  Button,
  Progress,
  VStack,
  useToast,
} from '@chakra-ui/react';
import Module1Intro from './Module1Intro';
import GoalSettingWorksheet from './GoalSettingWorksheet';
import ConfidenceLog from './ConfidenceLog';
import StagesOfChange from './StagesOfChange';
import Module1Quiz from '../quizzes/Module1Quiz';
import QuizResults from '../quizzes/QuizResults';

type ModuleStep = 
  | 'intro'
  | 'goals'
  | 'confidence'
  | 'stages'
  | 'quiz'
  | 'results';

interface ModuleProgress {
  currentStep: ModuleStep;
  completedSteps: ModuleStep[];
  data: Record<string, any>;
}

export default function Module1Flow() {
  const [progress, setProgress] = useState<ModuleProgress>({
    currentStep: 'intro',
    completedSteps: [],
    data: {}
  });
  const toast = useToast();

  const steps: ModuleStep[] = ['intro', 'goals', 'confidence', 'stages', 'quiz', 'results'];
  const progressPercentage = (progress.completedSteps.length / (steps.length - 1)) * 100;

  const handleStepComplete = (stepData: any) => {
    setProgress(prev => ({
      ...prev,
      data: { ...prev.data, [prev.currentStep]: stepData },
      completedSteps: [...prev.completedSteps, prev.currentStep],
      currentStep: getNextStep(prev.currentStep)
    }));

    toast({
      title: 'Progress Saved',
      status: 'success',
      duration: 2000,
    });
  };

  const getNextStep = (currentStep: ModuleStep): ModuleStep => {
    const currentIndex = steps.indexOf(currentStep);
    return steps[currentIndex + 1] as ModuleStep;
  };

  const renderCurrentStep = () => {
    switch (progress.currentStep) {
      case 'intro':
        return <Module1Intro onComplete={() => handleStepComplete({})} />;
      
      case 'goals':
        return <GoalSettingWorksheet onComplete={handleStepComplete} />;
      
      case 'confidence':
        return <ConfidenceLog onComplete={handleStepComplete} />;
      
      case 'stages':
        return <StagesOfChange onComplete={handleStepComplete} />;
      
      case 'quiz':
        return <Module1Quiz onComplete={handleStepComplete} />;
      
      case 'results':
        return (
          <QuizResults
            score={progress.data.quiz?.score || 0}
            onRetake={() => setProgress(prev => ({ ...prev, currentStep: 'quiz' }))}
            onContinue={() => {
              // TODO: Handle module completion and progression to next module
              toast({
                title: 'Module 1 Completed!',
                description: 'You can now proceed to Module 2',
                status: 'success',
                duration: 5000,
              });
            }}
          />
        );
      
      default:
        return null;
    }
  };

  return (
    <VStack spacing={6} align="stretch">
      <Progress
        value={progressPercentage}
        size="sm"
        colorScheme="purple"
        borderRadius="full"
      />
      
      <Box>
        {renderCurrentStep()}
      </Box>
    </VStack>
  );
}