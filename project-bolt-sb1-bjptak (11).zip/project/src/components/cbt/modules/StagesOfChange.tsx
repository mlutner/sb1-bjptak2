import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Radio,
  RadioGroup,
  Stack,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Stage {
  id: string;
  name: string;
  description: string;
  characteristics: string[];
}

const STAGES: Stage[] = [
  {
    id: 'precontemplation',
    name: 'Pre-contemplation',
    description: 'Not yet acknowledging that there is a financial behavior problem that needs to be changed',
    characteristics: [
      'Unaware of financial issues',
      'No intention to change in the near future',
      'May be in denial about problems'
    ]
  },
  {
    id: 'contemplation',
    name: 'Contemplation',
    description: 'Acknowledging that there is a problem but not yet ready or sure of wanting to make a change',
    characteristics: [
      'Aware of financial issues',
      'Considering making changes',
      'Ambivalent about change'
    ]
  },
  {
    id: 'preparation',
    name: 'Preparation',
    description: 'Getting ready to change financial behaviors',
    characteristics: [
      'Making small changes',
      'Gathering information',
      'Creating action plans'
    ]
  },
  {
    id: 'action',
    name: 'Action',
    description: 'Actively modifying financial behaviors',
    characteristics: [
      'Taking direct action',
      'Making specific changes',
      'Strong commitment'
    ]
  },
  {
    id: 'maintenance',
    name: 'Maintenance',
    description: 'Maintaining new financial behaviors',
    characteristics: [
      'Sustaining changes',
      'Working to prevent relapse',
      'Consolidating gains'
    ]
  }
];

interface Props {
  onComplete: (stage: string) => void;
}

export default function StagesOfChange({ onComplete }: Props) {
  const [selectedStage, setSelectedStage] = useState<string>('');
  const toast = useToast();

  const handleSubmit = () => {
    if (!selectedStage) {
      toast({
        title: 'Please select your current stage',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onComplete(selectedStage);
    toast({
      title: 'Stage assessment completed',
      status: 'success',
      duration: 3000,
    });
  };

  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Stages of Change Assessment</Heading>
        <Text mt={2} color="gray.600">
          Identify your current stage in the journey to financial wellness
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          <Text>
            Understanding where you are in the change process helps create a more effective plan.
            Review each stage and select the one that best describes your current situation.
          </Text>

          <RadioGroup onChange={setSelectedStage} value={selectedStage}>
            <Stack spacing={4}>
              {STAGES.map((stage) => (
                <Box
                  key={stage.id}
                  p={6}
                  bg="gray.50"
                  rounded="lg"
                  borderWidth={selectedStage === stage.id ? 2 : 1}
                  borderColor={selectedStage === stage.id ? 'purple.500' : 'gray.200'}
                >
                  <Radio value={stage.id} colorScheme="purple" mb={2}>
                    <Text fontWeight="bold">{stage.name}</Text>
                  </Radio>
                  
                  <Text color="gray.600" mb={4} pl={6}>
                    {stage.description}
                  </Text>
                  
                  <VStack align="start" spacing={1} pl={6}>
                    {stage.characteristics.map((char, index) => (
                      <Text key={index} fontSize="sm" color="gray.600">
                        • {char}
                      </Text>
                    ))}
                  </VStack>
                </Box>
              ))}
            </Stack>
          </RadioGroup>

          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleSubmit}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
            }}
          >
            Complete Assessment
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}