import { useState } from 'react';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  HStack,
  Slider,
  SliderTrack,
  SliderFilledTrack,
  SliderThumb,
  IconButton,
} from '@chakra-ui/react';
import { AddIcon, DeleteIcon } from '@chakra-ui/icons';
import type { Emotion, ThoughtAnalysis, ThoughtRecord } from '../../types/exercises';

interface Props {
  thoughtAnalysis: ThoughtAnalysis;
  onComplete: (data: Partial<ThoughtRecord>) => void;
}

export default function EmotionInput({ thoughtAnalysis, onComplete }: Props) {
  const [emotions, setEmotions] = useState<Emotion[]>([{ name: '', intensity: 5 }]);

  const addEmotion = () => {
    setEmotions([...emotions, { name: '', intensity: 5 }]);
  };

  const removeEmotion = (index: number) => {
    setEmotions(emotions.filter((_, i) => i !== index));
  };

  const updateEmotion = (index: number, field: keyof Emotion, value: string | number) => {
    const newEmotions = [...emotions];
    newEmotions[index] = { ...newEmotions[index], [field]: value };
    setEmotions(newEmotions);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onComplete({ emotions });
  };

  return (
    <Box as="form" onSubmit={handleSubmit}>
      <VStack spacing={6} align="stretch">
        <Text fontSize="lg" fontWeight="medium">
          What emotions are you experiencing?
        </Text>

        {thoughtAnalysis.recommendations.map((rec, index) => (
          <Text key={index} color="gray.600">
            Tip: {rec}
          </Text>
        ))}

        {emotions.map((emotion, index) => (
          <Box key={index} p={4} borderWidth={1} borderRadius="md">
            <VStack spacing={4}>
              <HStack w="full">
                <FormControl isRequired>
                  <FormLabel>Emotion {index + 1}</FormLabel>
                  <Input
                    value={emotion.name}
                    onChange={(e) => updateEmotion(index, 'name', e.target.value)}
                    placeholder="e.g., Anxiety, Sadness, Joy"
                  />
                </FormControl>
                {index > 0 && (
                  <IconButton
                    aria-label="Remove emotion"
                    icon={<DeleteIcon />}
                    onClick={() => removeEmotion(index)}
                    alignSelf="flex-end"
                  />
                )}
              </HStack>

              <FormControl>
                <FormLabel>Intensity ({emotion.intensity})</FormLabel>
                <Slider
                  value={emotion.intensity}
                  onChange={(value) => updateEmotion(index, 'intensity', value)}
                  min={1}
                  max={10}
                >
                  <SliderTrack>
                    <SliderFilledTrack />
                  </SliderTrack>
                  <SliderThumb />
                </Slider>
              </FormControl>
            </VStack>
          </Box>
        ))}

        <Button
          leftIcon={<AddIcon />}
          onClick={addEmotion}
          variant="ghost"
        >
          Add Another Emotion
        </Button>

        <Button
          type="submit"
          colorScheme="blue"
          isDisabled={emotions.some(e => !e.name.trim())}
        >
          Continue
        </Button>
      </VStack>
    </Box>
  );
}