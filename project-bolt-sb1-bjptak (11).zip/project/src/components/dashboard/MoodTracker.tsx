import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  HStack,
  Text,
  VStack,
  Circle,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { useState } from 'react';

const MOODS = [
  { type: 'great', emoji: '😊', label: 'Great', color: 'brand.500' },
  { type: 'good', emoji: '🙂', label: 'Good', color: 'mindful.400' },
  { type: 'neutral', emoji: '😐', label: 'Okay', color: 'calm.400' },
  { type: 'low', emoji: '😕', label: 'Low', color: 'calm.500' },
  { type: 'bad', emoji: '😢', label: 'Bad', color: 'calm.600' }
];

export default function MoodTracker() {
  const [selectedMood, setSelectedMood] = useState<string | null>(null);

  return (
    <Card>
      <CardHeader>
        <VStack spacing={2} align="center">
          <Heading size="md" fontWeight="medium">How are you feeling?</Heading>
          <Text color="calm.600" fontSize="sm">
            Take a moment to check in with yourself
          </Text>
        </VStack>
      </CardHeader>

      <CardBody>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <HStack spacing={4} justify="center">
            {MOODS.map(({ type, emoji, label, color }) => (
              <motion.div
                key={type}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
              >
                <VStack spacing={2}>
                  <Button
                    onClick={() => setSelectedMood(type)}
                    size="lg"
                    variant="ghost"
                    rounded="full"
                    h="16"
                    w="16"
                    fontSize="2xl"
                    bg={selectedMood === type ? `${color}` : 'transparent'}
                    color={selectedMood === type ? 'white' : 'inherit'}
                    _hover={{
                      bg: selectedMood === type ? color : 'calm.50',
                    }}
                  >
                    {emoji}
                  </Button>
                  <Text 
                    fontSize="sm" 
                    color={selectedMood === type ? color : 'calm.600'}
                    fontWeight={selectedMood === type ? 'medium' : 'normal'}
                  >
                    {label}
                  </Text>
                </VStack>
              </motion.div>
            ))}
          </HStack>
        </motion.div>
      </CardBody>
    </Card>
  );
}