import { useEffect } from 'react';
import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Progress,
  Stack,
  Text,
  VStack,
} from '@chakra-ui/react';
import { motion, AnimatePresence } from 'framer-motion';
import { useAssessmentFlow } from '../../hooks/useAssessmentFlow';
import { MoodQuestion } from './questions/MoodQuestion';
import { MultiSelectQuestion } from './questions/MultiSelectQuestion';
import { ScaleQuestion } from './questions/ScaleQuestion';
import { TextQuestion } from './questions/TextQuestion';

export function AssessmentFlow() {
  const {
    state,
    setResponse,
    nextStep,
    previousStep,
    getCurrentStep,
    getProgress,
    canProceed
  } = useAssessmentFlow();

  const currentStep = getCurrentStep();
  const progress = getProgress();

  const renderQuestion = () => {
    const value = state.responses[currentStep.id]?.response;

    switch (currentStep.type) {
      case 'mood':
        return (
          <MoodQuestion
            options={currentStep.options || []}
            value={value}
            onChange={(val) => setResponse(currentStep.id, val)}
          />
        );
      case 'multi-select':
        return (
          <MultiSelectQuestion
            options={currentStep.options || []}
            value={value || []}
            onChange={(val) => setResponse(currentStep.id, val)}
          />
        );
      case 'scale':
        return (
          <ScaleQuestion
            value={value}
            onChange={(val) => setResponse(currentStep.id, val)}
          />
        );
      case 'text':
        return (
          <TextQuestion
            value={value}
            onChange={(val) => setResponse(currentStep.id, val)}
          />
        );
      default:
        return null;
    }
  };

  return (
    <Box maxW="2xl" mx="auto" p={4}>
      <VStack spacing={8} align="stretch">
        <Box>
          <Progress value={progress} size="sm" colorScheme="purple" mb={2} />
          <Text fontSize="sm" color="gray.600">
            Step {state.currentStep + 1} of {assessmentSteps.length}
          </Text>
        </Box>

        <AnimatePresence mode="wait">
          <motion.div
            key={state.currentStep}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.3 }}
          >
            <Card>
              <CardHeader>
                <Heading size="lg">{currentStep.title}</Heading>
                {currentStep.description && (
                  <Text mt={2} color="gray.600">
                    {currentStep.description}
                  </Text>
                )}
              </CardHeader>

              <CardBody>
                <VStack spacing={6} align="stretch">
                  {renderQuestion()}

                  <Stack direction="row" spacing={4} justify="space-between">
                    <Button
                      variant="outline"
                      onClick={previousStep}
                      isDisabled={state.currentStep === 0}
                    >
                      Previous
                    </Button>

                    <Button
                      colorScheme="purple"
                      onClick={nextStep}
                      isDisabled={!canProceed()}
                    >
                      {state.currentStep === assessmentSteps.length - 1 ? 'Complete' : 'Next'}
                    </Button>
                  </Stack>
                </VStack>
              </CardBody>
            </Card>
          </motion.div>
        </AnimatePresence>
      </VStack>
    </Box>
  );
}