import {
  Box,
  Button,
  Circle,
  Flex,
  Icon,
  IconButton,
  Input,
  Text,
  VStack,
  useDisclosure,
  Collapse,
  Tooltip,
  Badge,
  InputGroup,
  InputRightElement,
  Spinner,
} from '@chakra-ui/react';
import { FiMessageSquare, FiX, FiSend, FiHelpCircle } from 'react-icons/fi';
import { useRef, useEffect, useState } from 'react';
import { useAIChat } from '../../hooks/useAIChat';
import ChatExplainer from './ChatExplainer';
import { motion, AnimatePresence } from 'framer-motion';

interface Props {
  context?: string;
  initialMessage?: string;
  position?: 'fixed' | 'relative';
  showExplainer?: boolean;
}

export default function AIChat({ 
  context = 'general',
  initialMessage = "Hi! I'm your AI financial wellness assistant. How can I help you today?",
  position = 'fixed',
  showExplainer = true,
}: Props) {
  const { isOpen, onToggle } = useDisclosure();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [showExplainerModal, setShowExplainerModal] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const {
    messages,
    input,
    isTyping,
    setInput,
    sendMessage
  } = useAIChat(context, initialMessage);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const handleOpen = () => {
    onToggle();
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);
  };

  return (
    <AnimatePresence>
      <Box
        position={position}
        bottom={6}
        right={6}
        zIndex={1000}
        maxW="400px"
        w="full"
      >
        <Collapse in={isOpen} animateOpacity>
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
          >
            <Box
              bg="white"
              rounded="lg"
              shadow="lg"
              overflow="hidden"
              maxH="600px"
              display="flex"
              flexDirection="column"
              borderWidth="1px"
              borderColor="gray.200"
            >
              {/* Header */}
              <Flex
                align="center"
                justify="space-between"
                p={4}
                bg="purple.500"
                color="white"
              >
                <Flex align="center" gap={2}>
                  <Icon as={FiMessageSquare} boxSize={5} />
                  <Text fontWeight="medium">AI Assistant</Text>
                  {isTyping && (
                    <Badge colorScheme="green" variant="solid" fontSize="xs">
                      typing...
                    </Badge>
                  )}
                </Flex>
                <Flex gap={2}>
                  {showExplainer && (
                    <Tooltip label="Learn about AI assistance">
                      <IconButton
                        icon={<FiHelpCircle />}
                        aria-label="Help"
                        variant="ghost"
                        color="white"
                        _hover={{ bg: 'purple.600' }}
                        onClick={() => setShowExplainerModal(true)}
                      />
                    </Tooltip>
                  )}
                  <IconButton
                    icon={<FiX />}
                    aria-label="Close chat"
                    variant="ghost"
                    color="white"
                    _hover={{ bg: 'purple.600' }}
                    onClick={onToggle}
                  />
                </Flex>
              </Flex>

              {/* Messages */}
              <VStack
                spacing={4}
                p={4}
                overflowY="auto"
                maxH="400px"
                bg="gray.50"
                align="stretch"
              >
                {messages.map((message) => (
                  <Flex
                    key={message.id}
                    justify={message.sender === 'user' ? 'flex-end' : 'flex-start'}
                  >
                    <Box
                      maxW="80%"
                      bg={message.sender === 'user' ? 'purple.500' : 'white'}
                      color={message.sender === 'user' ? 'white' : 'gray.800'}
                      px={4}
                      py={2}
                      rounded="lg"
                      shadow="sm"
                    >
                      <Text>{message.text}</Text>
                    </Box>
                  </Flex>
                ))}
                <div ref={messagesEndRef} />
              </VStack>

              {/* Input */}
              <Box p={4} bg="white" borderTop="1px" borderColor="gray.100">
                <InputGroup size="lg">
                  <Input
                    ref={inputRef}
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    onKeyPress={handleKeyPress}
                    placeholder="Type your message..."
                    pr="4.5rem"
                    _focus={{
                      borderColor: 'purple.500',
                      boxShadow: '0 0 0 1px var(--chakra-colors-purple-500)',
                    }}
                  />
                  <InputRightElement width="4.5rem">
                    <IconButton
                      h="1.75rem"
                      size="sm"
                      icon={isTyping ? <Spinner size="sm" /> : <FiSend />}
                      onClick={() => sendMessage()}
                      aria-label="Send message"
                      isDisabled={!input.trim() || isTyping}
                      colorScheme="purple"
                    />
                  </InputRightElement>
                </InputGroup>
              </Box>
            </Box>
          </motion.div>
        </Collapse>

        {/* Toggle Button */}
        {!isOpen && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
          >
            <Button
              position={position}
              bottom={6}
              right={6}
              colorScheme="purple"
              leftIcon={<FiMessageSquare />}
              onClick={handleOpen}
              shadow="md"
              size="lg"
              _hover={{
                transform: 'translateY(-2px)',
                shadow: 'lg',
              }}
              transition="all 0.2s"
            >
              Chat with AI Assistant
            </Button>
          </motion.div>
        )}

        {/* Explainer Modal */}
        <ChatExplainer
          isOpen={showExplainerModal}
          onClose={() => setShowExplainerModal(false)}
        />
      </Box>
    </AnimatePresence>
  );
}