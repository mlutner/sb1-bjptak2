import { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import { signInWithEmailAndPassword, signInWithPopup } from 'firebase/auth';
import { auth, googleProvider } from '../../config/firebase';
import { saveUserPreferences } from '../../lib/firebase/db';
import {
  Box,
  Button,
  VStack,
  Text,
  useToast,
  Heading,
  Image,
  Divider,
  Link,
  Center,
  Icon,
  Card,
  CardBody,
  FormControl,
  FormLabel,
  Input,
  ButtonGroup,
  FormErrorMessage,
} from '@chakra-ui/react';
import { FcGoogle } from 'react-icons/fc';

export default function SignIn() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const toast = useToast();
  const navigate = useNavigate();

  const handleSignIn = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      navigate('/');
    } catch (error: any) {
      console.error('Sign in error:', error);
      setError(error.message);
      toast({
        title: 'Error signing in',
        description: 'Invalid email or password.',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleDemoLogin = async () => {
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, 'demo@finwell.com', 'demo123');
      
      await saveUserPreferences({
        isFirstTimeUser: true,
        onboardingCompleted: false,
        preferences: {
          theme: 'light',
          notifications: true
        }
      });
      
      navigate('/');
    } catch (error) {
      console.error('Demo login error:', error);
      toast({
        title: 'Error signing in',
        description: 'Demo account login failed. Please try again.',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleSignIn = async () => {
    setLoading(true);
    try {
      const result = await signInWithPopup(auth, googleProvider);
      if (result.user) {
        navigate('/');
      }
    } catch (error) {
      console.error('Google sign in error:', error);
      toast({
        title: 'Error signing in',
        description: 'Google sign in failed. Please try again.',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box maxW="md" mx="auto" mt={8}>
      <Card>
        <CardBody>
          <VStack spacing={6}>
            <Image src="/owl-logo.png" alt="FinWell Logo" boxSize="120px" />
            
            <Heading as="h1" size="xl" color="headspace.slate">
              FinWell
            </Heading>
            
            <Text fontSize="lg" color="gray.600">
              Your Financial Wellness Journey
            </Text>

            <form onSubmit={handleSignIn} style={{ width: '100%' }}>
              <VStack spacing={4}>
                <FormControl isInvalid={!!error}>
                  <FormLabel>Email</FormLabel>
                  <Input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    focusBorderColor="purple.500"
                    isRequired
                  />
                </FormControl>

                <FormControl isInvalid={!!error}>
                  <FormLabel>Password</FormLabel>
                  <Input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    focusBorderColor="purple.500"
                    isRequired
                  />
                  <FormErrorMessage>{error}</FormErrorMessage>
                </FormControl>

                <ButtonGroup spacing={4} width="full">
                  <Button
                    type="submit"
                    colorScheme="purple"
                    isLoading={loading}
                    flex={1}
                  >
                    Sign In
                  </Button>
                </ButtonGroup>
              </VStack>
            </form>

            <Center w="full" position="relative" py={4}>
              <Divider />
              <Text
                position="absolute"
                bg="white"
                px={4}
                color="gray.500"
              >
                OR
              </Text>
            </Center>

            <Button
              w="full"
              variant="outline"
              onClick={handleDemoLogin}
              isLoading={loading}
              colorScheme="purple"
            >
              Try Demo Account
            </Button>

            <Button
              w="full"
              variant="outline"
              leftIcon={<Icon as={FcGoogle} boxSize={5} />}
              onClick={handleGoogleSignIn}
              isLoading={loading}
            >
              Continue with Google
            </Button>

            <Text color="gray.600" fontSize="sm">
              Don't have an account?{' '}
              <Link as={RouterLink} to="/signup" color="purple.500">
                Sign up
              </Link>
            </Text>
          </VStack>
        </CardBody>
      </Card>
    </Box>
  );
}