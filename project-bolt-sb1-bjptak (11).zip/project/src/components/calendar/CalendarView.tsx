import { Box } from '@chakra-ui/react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import timeGridPlugin from '@fullcalendar/timegrid';
import interactionPlugin from '@fullcalendar/interaction';
import type { Event } from '../../types/calendar';

interface CalendarViewProps {
  events: Event[];
  onDateSelect: (selectInfo: { start: Date }) => void;
}

export default function CalendarView({ events, onDateSelect }: CalendarViewProps) {
  return (
    <Box 
      bg="white" 
      p={6} 
      rounded="lg" 
      shadow="sm"
      sx={{
        '.fc': { // FullCalendar root class
          '--fc-border-color': 'var(--chakra-colors-gray-200)',
          '--fc-button-bg-color': 'var(--chakra-colors-purple-500)',
          '--fc-button-border-color': 'var(--chakra-colors-purple-500)',
          '--fc-button-hover-bg-color': 'var(--chakra-colors-purple-600)',
          '--fc-button-hover-border-color': 'var(--chakra-colors-purple-600)',
          '--fc-button-active-bg-color': 'var(--chakra-colors-purple-700)',
          '--fc-button-active-border-color': 'var(--chakra-colors-purple-700)',
        },
        '.fc-button': {
          boxShadow: 'none',
          padding: '0.5rem 1rem',
          fontWeight: 'medium',
          borderRadius: 'md',
        },
        '.fc-event': {
          borderRadius: 'sm',
          padding: '2px 4px',
          fontSize: 'sm',
        },
      }}
    >
      <FullCalendar
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        initialView="dayGridMonth"
        headerToolbar={{
          left: 'prev,next today',
          center: 'title',
          right: 'dayGridMonth,timeGridWeek,timeGridDay',
        }}
        events={events}
        selectable={true}
        select={onDateSelect}
        height="auto"
        aspectRatio={1.8}
        eventColor="purple.500"
        eventTextColor="white"
        dayMaxEvents={true}
        weekends={true}
        nowIndicator={true}
        editable={true}
        droppable={true}
      />
    </Box>
  );
}