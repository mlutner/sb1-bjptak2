import {
  Box,
  Container,
  Flex,
  IconButton,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  MenuDivider,
  Avatar,
  Text,
  HStack,
  useColorMode,
  Tooltip,
  Badge,
  MenuGroup,
  useDisclosure,
} from '@chakra-ui/react';
import { 
  FiSettings, 
  FiUser, 
  FiHelpCircle, 
  FiLogOut, 
  FiMoon, 
  FiSun, 
  FiBell,
  FiSliders,
  FiPieChart,
} from 'react-icons/fi';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';
import AnalyticsFoldout from '../analytics/AnalyticsFoldout';

export default function Navigation() {
  const { user, signOut } = useAuth();
  const navigate = useNavigate();
  const { colorMode, toggleColorMode } = useColorMode();
  const analytics = useDisclosure();

  const handleSignOut = async () => {
    try {
      await signOut();
      navigate('/signin');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <>
      <Box bg="white" px={4} shadow="sm" position="sticky" top={0} zIndex={100}>
        <Container maxW="container.xl">
          <Flex h={16} alignItems="center" justifyContent="space-between">
            <Text
              fontSize="xl"
              fontWeight="bold"
              bgGradient="linear(to-r, purple.500, blue.500)"
              bgClip="text"
            >
              FinWell
            </Text>

            <HStack spacing={4}>
              {/* Analytics Button */}
              <Tooltip label="Analytics">
                <IconButton
                  variant="ghost"
                  aria-label="Analytics"
                  icon={<FiPieChart size={20} />}
                  onClick={analytics.onOpen}
                />
              </Tooltip>

              {/* Notifications */}
              <Menu>
                <Tooltip label="Notifications">
                  <MenuButton
                    as={IconButton}
                    variant="ghost"
                    aria-label="Notifications"
                    icon={
                      <Box position="relative">
                        <FiBell size={20} />
                        <Badge
                          position="absolute"
                          top="-2px"
                          right="-2px"
                          colorScheme="red"
                          variant="solid"
                          borderRadius="full"
                          boxSize="4"
                          p={0}
                          fontSize="xs"
                          display="flex"
                          alignItems="center"
                          justifyContent="center"
                        >
                          3
                        </Badge>
                      </Box>
                    }
                  />
                </Tooltip>
                <MenuList p={2}>
                  <MenuGroup title="Notifications">
                    <MenuItem>
                      <Box>
                        <Text fontWeight="medium">Streak Achievement</Text>
                        <Text fontSize="sm" color="gray.600">You've maintained a 7-day streak!</Text>
                      </Box>
                    </MenuItem>
                    <MenuItem>
                      <Box>
                        <Text fontWeight="medium">New Module Available</Text>
                        <Text fontSize="sm" color="gray.600">Check out the latest learning content</Text>
                      </Box>
                    </MenuItem>
                    <MenuItem>
                      <Box>
                        <Text fontWeight="medium">Weekly Progress Report</Text>
                        <Text fontSize="sm" color="gray.600">View your weekly insights</Text>
                      </Box>
                    </MenuItem>
                  </MenuGroup>
                </MenuList>
              </Menu>

              {/* User Menu */}
              <Menu>
                <MenuButton>
                  <HStack spacing={3} cursor="pointer">
                    <Avatar
                      size="sm"
                      name={user?.email || 'User'}
                      src={user?.photoURL || undefined}
                      bg="purple.500"
                    />
                    <Box display={{ base: 'none', md: 'block' }}>
                      <Text fontWeight="medium" fontSize="sm">
                        {user?.email?.split('@')[0] || 'User'}
                      </Text>
                      <Text fontSize="xs" color="gray.500">
                        Free Plan
                      </Text>
                    </Box>
                  </HStack>
                </MenuButton>
                <MenuList
                  shadow="lg"
                  rounded="xl"
                  p={2}
                  minW="200px"
                  border="1px"
                  borderColor="gray.200"
                >
                  <MenuItem
                    icon={<FiUser />}
                    rounded="lg"
                    _hover={{ bg: 'purple.50' }}
                  >
                    Profile
                  </MenuItem>
                  <MenuItem
                    icon={<FiSettings />}
                    rounded="lg"
                    _hover={{ bg: 'purple.50' }}
                  >
                    Settings
                  </MenuItem>
                  <MenuItem
                    icon={<FiSliders />}
                    rounded="lg"
                    _hover={{ bg: 'purple.50' }}
                  >
                    Preferences
                  </MenuItem>
                  <MenuItem
                    icon={colorMode === 'light' ? <FiMoon /> : <FiSun />}
                    rounded="lg"
                    _hover={{ bg: 'purple.50' }}
                    onClick={toggleColorMode}
                  >
                    {colorMode === 'light' ? 'Dark Mode' : 'Light Mode'}
                  </MenuItem>
                  <MenuItem
                    icon={<FiHelpCircle />}
                    rounded="lg"
                    _hover={{ bg: 'purple.50' }}
                  >
                    Help & Support
                  </MenuItem>
                  <MenuDivider />
                  <MenuItem
                    icon={<FiLogOut />}
                    rounded="lg"
                    _hover={{ bg: 'red.50', color: 'red.500' }}
                    onClick={handleSignOut}
                  >
                    Sign Out
                  </MenuItem>
                </MenuList>
              </Menu>
            </HStack>
          </Flex>
        </Container>
      </Box>

      <AnalyticsFoldout 
        isOpen={analytics.isOpen} 
        onClose={analytics.onClose} 
      />
    </>
  );
}