import { Box, Flex, Button } from '@chakra-ui/react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

function Navigation() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleSignOut = async () => {
    try {
      await auth.signOut();
      navigate('/signin');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  return (
    <Box bg="white" px={4} shadow="sm">
      <Flex h={16} alignItems="center" justifyContent="flex-end">
        {user && (
          <Button onClick={handleSignOut} variant="ghost">
            Sign Out
          </Button>
        )}
      </Flex>
    </Box>
  );
}

export default Navigation;