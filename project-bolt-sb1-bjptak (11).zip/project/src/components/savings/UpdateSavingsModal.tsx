import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  FormControl,
  FormLabel,
  NumberInput,
  NumberInputField,
  VStack,
  Button,
  Text,
} from '@chakra-ui/react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
  currentGoals: Array<{
    name: string;
    current: number;
    target: number;
    color: string;
  }>;
  onUpdate: (goals: any) => void;
}

export default function UpdateSavingsModal({ isOpen, onClose, currentGoals, onUpdate }: Props) {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.target as HTMLFormElement;
    const formData = new FormData(form);
    
    const updatedGoals = currentGoals.map(goal => ({
      ...goal,
      current: Number(formData.get(`${goal.name}-current`)),
      target: Number(formData.get(`${goal.name}-target`))
    }));

    onUpdate(updatedGoals);
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="lg">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Update Savings Goals</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <form onSubmit={handleSubmit}>
            <VStack spacing={6}>
              {currentGoals.map((goal) => (
                <VStack key={goal.name} spacing={4} align="stretch" w="full">
                  <Text fontWeight="medium">{goal.name}</Text>
                  
                  <FormControl>
                    <FormLabel>Current Amount</FormLabel>
                    <NumberInput defaultValue={goal.current} min={0}>
                      <NumberInputField name={`${goal.name}-current`} />
                    </NumberInput>
                  </FormControl>

                  <FormControl>
                    <FormLabel>Target Amount</FormLabel>
                    <NumberInput defaultValue={goal.target} min={0}>
                      <NumberInputField name={`${goal.name}-target`} />
                    </NumberInput>
                  </FormControl>
                </VStack>
              ))}

              <Button type="submit" colorScheme="purple" w="full">
                Update Goals
              </Button>
            </VStack>
          </form>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}