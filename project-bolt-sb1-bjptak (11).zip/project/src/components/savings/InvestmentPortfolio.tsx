import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  SimpleGrid,
  Text,
  Flex,
  Button,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import UpdateInvestmentsModal from './UpdateInvestmentsModal';

interface Investment {
  type: string;
  value: number;
  change: number;
  allocation: number;
}

export default function InvestmentPortfolio() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [investments, setInvestments] = useState<Investment[]>([
    {
      type: "Stocks",
      value: 45000,
      change: 12.5,
      allocation: 45
    },
    {
      type: "Bonds",
      value: 25000,
      change: 3.2,
      allocation: 25
    },
    {
      type: "ETFs",
      value: 20000,
      change: 8.7,
      allocation: 20
    },
    {
      type: "Cash",
      value: 10000,
      change: 0,
      allocation: 10
    }
  ]);

  return (
    <>
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center">
            <Box>
              <Heading size="md">Investment Portfolio</Heading>
              <Text color="gray.600" mt={1}>
                Track your investment allocation and performance
              </Text>
            </Box>
            <Button
              colorScheme="purple"
              variant="outline"
              onClick={onOpen}
            >
              Update Investments
            </Button>
          </Flex>
        </CardHeader>

        <CardBody>
          <SimpleGrid columns={{ base: 1, md: 2, lg: 4 }} spacing={6}>
            {investments.map((investment) => (
              <Card key={investment.type} variant="outline">
                <CardBody>
                  <Stat>
                    <StatLabel>{investment.type}</StatLabel>
                    <StatNumber>${investment.value.toLocaleString()}</StatNumber>
                    <StatHelpText>
                      <Flex justify="space-between">
                        <Box>
                          <StatArrow type={investment.change >= 0 ? 'increase' : 'decrease'} />
                          {Math.abs(investment.change)}%
                        </Box>
                        <Text>{investment.allocation}% allocation</Text>
                      </Flex>
                    </StatHelpText>
                  </Stat>
                </CardBody>
              </Card>
            ))}
          </SimpleGrid>
        </CardBody>
      </Card>

      <UpdateInvestmentsModal
        isOpen={isOpen}
        onClose={onClose}
        currentInvestments={investments}
        onUpdate={setInvestments}
      />
    </>
  );
}