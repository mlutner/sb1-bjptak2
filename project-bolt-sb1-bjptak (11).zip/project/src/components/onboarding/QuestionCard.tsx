import {
  Card,
  CardBody,
  Text,
  VStack,
} from '@chakra-ui/react';

interface Props {
  label: string;
  description: string;
  isSelected: boolean;
  onClick: () => void;
}

export default function QuestionCard({ label, description, isSelected, onClick }: Props) {
  return (
    <Card
      onClick={onClick}
      cursor="pointer"
      bg={isSelected ? 'purple.500' : 'white'}
      color={isSelected ? 'white' : 'inherit'}
      _hover={{
        transform: 'translateY(-2px)',
        shadow: 'lg',
      }}
      transition="all 0.2s"
    >
      <CardBody>
        <VStack align="start" spacing={1}>
          <Text fontWeight="bold">{label}</Text>
          <Text 
            fontSize="sm"
            color={isSelected ? 'whiteAlpha.900' : 'gray.600'}
          >
            {description}
          </Text>
        </VStack>
      </CardBody>
    </Card>
  );
}