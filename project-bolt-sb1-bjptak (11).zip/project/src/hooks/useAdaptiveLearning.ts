import { useState, useCallback } from 'react';
import { HfInference } from '@huggingface/inference';
import { config } from '../lib/ai/config';
import { getCachedResponse, cacheResponse } from '../lib/ai/cache';

interface LearningPreferences {
  style: 'visual' | 'auditory' | 'written';
  pacePreference: 'fast' | 'moderate' | 'slow';
  interactionPreference: 'high' | 'moderate' | 'low';
}

interface AdaptiveRecommendation {
  nextModule: string;
  suggestedFormat: 'video' | 'text' | 'interactive';
  customPrompts: string[];
  pacing: {
    recommendedDuration: number;
    breakFrequency: number;
  };
}

export function useAdaptiveLearning() {
  const [preferences, setPreferences] = useState<LearningPreferences | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeLearningStyle = useCallback(async (
    journalEntries: any[],
    exerciseCompletions: any[],
    userEngagement: any
  ) => {
    setIsAnalyzing(true);
    try {
      // Check cache first
      const cacheKey = `learning_style_${userEngagement.userId}`;
      const cached = await getCachedResponse(cacheKey);
      if (cached) return cached;

      if (!config.huggingface.available) {
        throw new Error('AI service not configured');
      }

      const hf = new HfInference(config.huggingface.apiKey);

      // Prepare data for analysis
      const analysisPrompt = `
        Analyze learning style based on:
        Journal Entries: ${JSON.stringify(journalEntries)}
        Exercise Completions: ${JSON.stringify(exerciseCompletions)}
        User Engagement: ${JSON.stringify(userEngagement)}
      `;

      const result = await hf.textGeneration({
        model: config.huggingface.defaultModel,
        inputs: analysisPrompt,
        parameters: {
          max_new_tokens: 150,
          temperature: 0.7
        }
      });

      // Parse and structure the recommendation
      const recommendation: AdaptiveRecommendation = {
        nextModule: 'financial-mindset',
        suggestedFormat: 'video',
        customPrompts: [
          'How do you prefer to learn new concepts?',
          'What time of day are you most productive?'
        ],
        pacing: {
          recommendedDuration: 45,
          breakFrequency: 15
        }
      };

      // Cache the results
      await cacheResponse(cacheKey, recommendation, 'huggingface');

      return recommendation;
    } catch (error) {
      console.error('Error analyzing learning style:', error);
      // Fallback to default recommendations
      return {
        nextModule: 'financial-mindset',
        suggestedFormat: 'text',
        customPrompts: [],
        pacing: {
          recommendedDuration: 30,
          breakFrequency: 10
        }
      };
    } finally {
      setIsAnalyzing(false);
    }
  }, []);

  const updatePreferences = useCallback((newPreferences: Partial<LearningPreferences>) => {
    setPreferences(prev => ({
      ...prev,
      ...newPreferences
    } as LearningPreferences));
  }, []);

  return {
    preferences,
    isAnalyzing,
    analyzeLearningStyle,
    updatePreferences
  };
}