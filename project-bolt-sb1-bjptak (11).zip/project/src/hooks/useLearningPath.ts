import { useQuery } from '@tanstack/react-query';
import { getUserPreferences } from '../lib/firebase/db';
import { pathModules, pathNames } from '../data/learningPaths';
import { cacheHelpers } from '../lib/cache/store';

const CACHE_KEY = 'learning_path';
const CACHE_MAX_AGE = 1000 * 60 * 30; // 30 minutes

export function useLearningPath() {
  return useQuery({
    queryKey: ['learningPath'],
    queryFn: async () => {
      try {
        // Check cache first
        const cached = await cacheHelpers.get(CACHE_KEY);
        if (cached) return cached;

        const preferences = await getUserPreferences();
        const pathType = preferences?.preferences?.primary_concern || 'confidence';
        
        const path = {
          type: pathType,
          modules: pathModules[pathType] || pathModules.confidence,
          name: pathNames[pathType] || 'Your Learning Path'
        };

        // Cache the result
        await cacheHelpers.set(CACHE_KEY, path, CACHE_MAX_AGE);
        return path;
      } catch (error) {
        console.error('Learning path error:', error);
        // Return default path on error
        return {
          type: 'confidence',
          modules: pathModules.confidence,
          name: pathNames.confidence
        };
      }
    },
    staleTime: CACHE_MAX_AGE,
    cacheTime: 1000 * 60 * 60, // 1 hour
    suspense: false,
    useErrorBoundary: false,
    retry: 2,
    refetchOnWindowFocus: false
  });
}