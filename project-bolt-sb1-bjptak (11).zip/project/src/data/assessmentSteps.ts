import { AssessmentStep } from '../types/assessment';

export const assessmentSteps: AssessmentStep[] = [
  {
    id: 'emotional-state',
    title: 'How are you feeling about your finances today?',
    description: 'Select the option that best describes your current emotional state.',
    type: 'mood',
    options: [
      { id: 'confident', label: 'Confident', icon: 'sun' },
      { id: 'neutral', label: 'Neutral', icon: 'cloud' },
      { id: 'anxious', label: 'Anxious', icon: 'cloud-rain' },
      { id: 'overwhelmed', label: 'Overwhelmed', icon: 'zap' }
    ]
  },
  {
    id: 'primary-concerns',
    title: 'What brings you here today?',
    description: 'Select all that apply to your current situation.',
    type: 'multi-select',
    options: [
      { 
        id: 'anxiety', 
        label: 'Financial Anxiety',
        description: 'Feeling worried or stressed about money matters'
      },
      { 
        id: 'spending', 
        label: 'Spending Habits',
        description: 'Difficulty controlling spending or making impulsive purchases'
      },
      { 
        id: 'debt', 
        label: 'Debt Concerns',
        description: 'Struggling with debt or worried about taking on debt'
      },
      { 
        id: 'planning', 
        label: 'Future Planning',
        description: 'Want to improve financial planning and security'
      }
    ],
    required: true
  }
];