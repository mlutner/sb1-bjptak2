import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence, initializeFirestore, persistentLocalCache, persistentMultipleTabManager } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBv2OAfu3wO-Fa0a7azVrtEyAlKiJ1Rbqk",
  authDomain: "finwell-72e98.firebaseapp.com",
  projectId: "finwell-72e98",
  storageBucket: "finwell-72e98.appspot.com",
  messagingSenderId: "858768264942",
  appId: "1:858768264942:web:ef563eebd38df2153f6dff"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize services with modern persistence settings
const auth = getAuth(app);
const db = initializeFirestore(app, {
  localCache: persistentLocalCache({
    tabManager: persistentMultipleTabManager()
  })
});

const googleProvider = new GoogleAuthProvider();

// Enable offline persistence with error handling
try {
  await enableIndexedDbPersistence(db);
} catch (err: any) {
  if (err.code === 'failed-precondition') {
    console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
  } else if (err.code === 'unimplemented') {
    console.warn('The current browser doesn\'t support persistence.');
  } else {
    console.error('Persistence error:', err);
  }
}

export { auth, db, googleProvider };