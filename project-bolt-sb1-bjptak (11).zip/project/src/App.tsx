import { Box } from '@chakra-ui/react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import ErrorBoundary from './components/ErrorBoundary';
import Layout from './components/layout/Layout';
import Dashboard from './pages/Dashboard';
import Budget from './pages/Budget';
import Transactions from './pages/Transactions';
import Assessment from './pages/Assessment';
import CBTProgram from './pages/CBTProgram';
import SignIn from './components/auth/SignIn';
import SignUp from './components/auth/SignUp';
import OnboardingFlow from './components/onboarding/OnboardingFlow';
import AuthWrapper from './components/auth/AuthWrapper';
import Calendar from './pages/Calendar';
import Savings from './pages/Savings';
import AIChat from './components/chat/AIChat';

function App() {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <Router>
          <Box minH="100vh" bg="gray.50">
            <Routes>
              <Route path="/signin" element={<SignIn />} />
              <Route path="/signup" element={<SignUp />} />
              <Route path="/onboarding" element={<OnboardingFlow />} />
              <Route
                path="/*"
                element={
                  <AuthWrapper>
                    <Layout>
                      <Routes>
                        <Route path="/" element={<Dashboard />} />
                        <Route path="/budget" element={<Budget />} />
                        <Route path="/transactions" element={<Transactions />} />
                        <Route path="/assessment" element={<Assessment />} />
                        <Route path="/cbt-program" element={<CBTProgram />} />
                        <Route path="/calendar" element={<Calendar />} />
                        <Route path="/savings" element={<Savings />} />
                        <Route path="*" element={<Navigate to="/" />} />
                      </Routes>
                      <AIChat
                        position="fixed"
                        context="general"
                        initialMessage="Hi! I'm your AI financial wellness assistant. How can I help you today?"
                      />
                    </Layout>
                  </AuthWrapper>
                }
              />
            </Routes>
          </Box>
        </Router>
      </AuthProvider>
    </ErrorBoundary>
  );
}

export default App;