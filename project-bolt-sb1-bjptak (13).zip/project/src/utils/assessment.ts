interface Responses {
  financial_stress?: string;
  primary_goal?: string;
  support_preference?: string;
  learning_style?: string;
  time_commitment?: string;
}

interface Pathway {
  name: string;
  description: string;
  features: string[];
}

export function determinePathway(responses: Responses): Pathway {
  const stressLevel = responses.financial_stress;
  const primaryGoal = responses.primary_goal;
  const supportType = responses.support_preference;

  if (stressLevel === 'high' && supportType === 'therapy') {
    return {
      name: "Intensive Support Pathway",
      description: "A comprehensive program combining one-on-one therapy with financial tools",
      features: [
        "Weekly therapy sessions",
        "Stress management tools",
        "Guided financial planning"
      ]
    };
  }

  if (primaryGoal === 'debt') {
    return {
      name: "Debt Management Pathway",
      description: "Focus on debt reduction and financial recovery strategies",
      features: [
        "Debt reduction planning",
        "Spending analysis",
        "Credit improvement tips"
      ]
    };
  }

  return {
    name: "Financial Growth Pathway",
    description: "Build strong financial habits and work toward your goals",
    features: [
      "Budgeting tools",
      "Savings strategies",
      "Investment education"
    ]
  };
}