import { cacheHelpers } from '../cache/store';
import { DEFAULT_PREFERENCES } from '../storage/demoData';

const CACHE_KEY = 'user_preferences';

const DEFAULT_DATA = {
  preferences: DEFAULT_PREFERENCES,
  userId: 'demo-user',
  createdAt: new Date().toISOString()
};

export async function getUserPreferences() {
  try {
    const cached = await cacheHelpers.get(`${CACHE_KEY}_demo`);
    if (cached) return cached;

    await cacheHelpers.set(`${CACHE_KEY}_demo`, DEFAULT_DATA);
    return DEFAULT_DATA;
  } catch (error) {
    console.error('Error getting user preferences:', error);
    return DEFAULT_DATA;
  }
}

export async function saveUserPreferences(data: any) {
  try {
    await cacheHelpers.set(`${CACHE_KEY}_demo`, {
      ...data,
      updatedAt: new Date().toISOString()
    });
    return true;
  } catch (error) {
    console.error('Error saving user preferences:', error);
    throw error;
  }
}