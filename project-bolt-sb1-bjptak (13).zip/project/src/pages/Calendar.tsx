import { useState } from 'react';
import {
  Container,
  Heading,
  useDisclosure,
  useToast,
  VStack,
  Box,
} from '@chakra-ui/react';
import CalendarView from '../components/calendar/CalendarView';
import EventModal from '../components/calendar/EventModal';
import type { Event, EventFormData } from '../types/calendar';

export default function Calendar() {
  const [events, setEvents] = useState<Event[]>([]);
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);
  const { isOpen, onOpen, onClose } = useDisclosure();
  const toast = useToast();

  const handleDateSelect = (selectInfo: { start: Date }) => {
    setSelectedDate(selectInfo.start);
    onOpen();
  };

  const handleEventAdd = (formData: EventFormData) => {
    if (!selectedDate) return;

    const newEvent: Event = {
      id: Date.now().toString(),
      title: formData.title,
      start: selectedDate,
      end: new Date(selectedDate.getTime() + 60 * 60 * 1000), // 1 hour duration
      type: formData.type,
      description: formData.description,
    };

    setEvents(prev => [...prev, newEvent]);
    onClose();
    setSelectedDate(null);

    toast({
      title: 'Event added',
      description: 'Your event has been successfully scheduled',
      status: 'success',
      duration: 3000,
    });
  };

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={6} align="stretch">
        <Box>
          <Heading size="lg" mb={2}>Calendar</Heading>
        </Box>
        
        <Box bg="white" p={6} rounded="lg" shadow="sm">
          <CalendarView events={events} onDateSelect={handleDateSelect} />
        </Box>

        <EventModal 
          isOpen={isOpen} 
          onClose={onClose} 
          onSubmit={handleEventAdd} 
        />
      </VStack>
    </Container>
  );
}