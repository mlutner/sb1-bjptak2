import {
  Box,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  Button,
  useDisclosure,
  Card,
  CardHeader,
  CardBody,
  Flex,
  Select,
  Badge,
  Icon,
  Table,
  Thead,
  Tbody,
  Tr,
  Th,
  Td,
} from '@chakra-ui/react';
import { FiPlus, FiTrendingUp, FiTrendingDown, FiDollarSign } from 'react-icons/fi';
import { Line } from 'react-chartjs-2';
import { defaultChartOptions } from '../lib/charts/chartConfig';

// Mock data for the chart
const spendingData = {
  labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
  datasets: [
    {
      label: 'Monthly Spending',
      data: [1200, 1350, 1100, 1400, 1250, 1300],
      borderColor: 'rgb(124, 58, 237)',
      backgroundColor: 'rgba(124, 58, 237, 0.1)',
      fill: true,
    }
  ]
};

// Mock transactions
const recentTransactions = [
  {
    id: 1,
    date: '2023-12-15',
    description: 'Grocery Store',
    category: 'Food',
    amount: 85.50,
    type: 'expense'
  },
  {
    id: 2,
    date: '2023-12-14',
    description: 'Monthly Salary',
    category: 'Income',
    amount: 3000.00,
    type: 'income'
  },
  {
    id: 3,
    date: '2023-12-13',
    description: 'Internet Bill',
    category: 'Utilities',
    amount: 65.00,
    type: 'expense'
  },
  {
    id: 4,
    date: '2023-12-12',
    description: 'Restaurant',
    category: 'Food',
    amount: 45.75,
    type: 'expense'
  },
];

export default function Expenses() {
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Container maxW="container.xl" py={8}>
      <VStack spacing={8} align="stretch">
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="lg" mb={2}>Expenses</Heading>
            <Text color="gray.600">Track and analyze your spending</Text>
          </Box>
          <Button
            colorScheme="purple"
            leftIcon={<Icon as={FiPlus} />}
            onClick={onOpen}
          >
            Add Transaction
          </Button>
        </Flex>

        <Grid templateColumns={{ base: '1fr', lg: '3fr 1fr' }} gap={6}>
          {/* Main Content */}
          <VStack spacing={6}>
            {/* Spending Overview */}
            <Card w="full">
              <CardHeader>
                <Flex justify="space-between" align="center">
                  <Heading size="md">Spending Overview</Heading>
                  <Select defaultValue="6months" size="sm" w="150px">
                    <option value="1month">Last Month</option>
                    <option value="3months">Last 3 Months</option>
                    <option value="6months">Last 6 Months</option>
                    <option value="1year">Last Year</option>
                  </Select>
                </Flex>
              </CardHeader>
              <CardBody>
                <Box h="300px">
                  <Line options={defaultChartOptions} data={spendingData} />
                </Box>
              </CardBody>
            </Card>

            {/* Recent Transactions */}
            <Card w="full">
              <CardHeader>
                <Heading size="md">Recent Transactions</Heading>
              </CardHeader>
              <CardBody>
                <Table>
                  <Thead>
                    <Tr>
                      <Th>Date</Th>
                      <Th>Description</Th>
                      <Th>Category</Th>
                      <Th isNumeric>Amount</Th>
                    </Tr>
                  </Thead>
                  <Tbody>
                    {recentTransactions.map((transaction) => (
                      <Tr key={transaction.id}>
                        <Td>{transaction.date}</Td>
                        <Td>{transaction.description}</Td>
                        <Td>
                          <Badge
                            colorScheme={transaction.type === 'income' ? 'green' : 'purple'}
                          >
                            {transaction.category}
                          </Badge>
                        </Td>
                        <Td isNumeric>
                          <Flex align="center" justify="flex-end" gap={2}>
                            <Icon
                              as={transaction.type === 'income' ? FiTrendingUp : FiTrendingDown}
                              color={transaction.type === 'income' ? 'green.500' : 'red.500'}
                            />
                            ${transaction.amount.toFixed(2)}
                          </Flex>
                        </Td>
                      </Tr>
                    ))}
                  </Tbody>
                </Table>
              </CardBody>
            </Card>
          </VStack>

          {/* Side Panel */}
          <VStack spacing={6}>
            {/* Monthly Summary */}
            <Card w="full">
              <CardHeader>
                <Heading size="md">Monthly Summary</Heading>
              </CardHeader>
              <CardBody>
                <VStack spacing={4} align="stretch">
                  <Flex justify="space-between" align="center">
                    <Text color="gray.600">Total Income</Text>
                    <Text fontWeight="bold" color="green.500">$3,000.00</Text>
                  </Flex>
                  <Flex justify="space-between" align="center">
                    <Text color="gray.600">Total Expenses</Text>
                    <Text fontWeight="bold" color="red.500">$1,950.25</Text>
                  </Flex>
                  <Box borderTop="1px" borderColor="gray.200" pt={4}>
                    <Flex justify="space-between" align="center">
                      <Text fontWeight="bold">Net Balance</Text>
                      <Text fontWeight="bold" color="blue.500">$1,049.75</Text>
                    </Flex>
                  </Box>
                </VStack>
              </CardBody>
            </Card>

            {/* Category Breakdown */}
            <Card w="full">
              <CardHeader>
                <Heading size="md">Top Categories</Heading>
              </CardHeader>
              <CardBody>
                <VStack spacing={4} align="stretch">
                  {[
                    { name: 'Food', amount: 450, color: 'green' },
                    { name: 'Utilities', amount: 350, color: 'blue' },
                    { name: 'Transportation', amount: 250, color: 'purple' },
                  ].map((category) => (
                    <Box key={category.name}>
                      <Flex justify="space-between" mb={2}>
                        <Text fontSize="sm">{category.name}</Text>
                        <Text fontSize="sm" fontWeight="medium">
                          ${category.amount}
                        </Text>
                      </Flex>
                      <Box
                        h="2"
                        bg={`${category.color}.100`}
                        rounded="full"
                        overflow="hidden"
                      >
                        <Box
                          w={`${(category.amount / 1000) * 100}%`}
                          h="full"
                          bg={`${category.color}.500`}
                          rounded="full"
                        />
                      </Box>
                    </Box>
                  ))}
                </VStack>
              </CardBody>
            </Card>
          </VStack>
        </Grid>
      </VStack>
    </Container>
  );
}