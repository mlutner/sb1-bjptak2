import { useState } from 'react';
import {
  Box,
  Container,
  VStack,
  useToast,
} from '@chakra-ui/react';
import AssessmentProgress from '../components/assessment/AssessmentProgress';
import InitialAssessment from '../components/assessment/InitialAssessment';
import EmotionalAssessment from '../components/assessment/EmotionalAssessment';
import FinancialAssessment from '../components/assessment/FinancialAssessment';
import AssessmentResults from '../components/assessment/AssessmentResults';
import AIChat from '../components/chat/AIChat';
import { useAIAnalysis } from '../hooks/useAIAnalysis';

export default function Assessment() {
  const [currentStep, setCurrentStep] = useState(1);
  const [assessmentData, setAssessmentData] = useState({});
  const toast = useToast();
  const { analyzeResponses, isAnalyzing } = useAIAnalysis();

  const handleStepComplete = async (stepData: any) => {
    const updatedData = { ...assessmentData, ...stepData };
    setAssessmentData(updatedData);

    if (currentStep === 3) {
      try {
        const analysis = await analyzeResponses(updatedData);
        setAssessmentData(prev => ({ ...prev, analysis }));
      } catch (error) {
        toast({
          title: 'Analysis Error',
          description: 'Failed to analyze responses. Please try again.',
          status: 'error',
          duration: 5000,
        });
        return;
      }
    }

    setCurrentStep(prev => prev + 1);
  };

  return (
    <Box minH="100vh" bg="gray.50" pt={24}>
      <AssessmentProgress
        currentStep={currentStep}
        totalSteps={4}
      />
      
      <Container maxW="3xl">
        <VStack spacing={8} align="stretch">
          {currentStep === 1 && (
            <InitialAssessment onComplete={handleStepComplete} />
          )}
          {currentStep === 2 && (
            <EmotionalAssessment onComplete={handleStepComplete} />
          )}
          {currentStep === 3 && (
            <FinancialAssessment 
              onComplete={handleStepComplete}
              isAnalyzing={isAnalyzing}
            />
          )}
          {currentStep === 4 && (
            <AssessmentResults 
              data={assessmentData}
              analysis={assessmentData.analysis}
            />
          )}
        </VStack>
      </Container>

      <AIChat
        context="assessment"
        initialMessage="Hi! I'm here to help you with the assessment. Feel free to ask any questions about the process."
        showExplainer={true}
      />
    </Box>
  );
}