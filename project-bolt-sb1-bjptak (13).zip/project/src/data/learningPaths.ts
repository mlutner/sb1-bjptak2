export const pathModules = {
  spending: [
    {
      id: 'spending-awareness',
      title: 'Spending Awareness',
      description: 'Track and understand your spending patterns',
      status: 'available',
      progress: 0
    },
    {
      id: 'emotional-triggers',
      title: 'Emotional Triggers',
      description: 'Identify triggers that lead to overspending',
      status: 'locked',
      progress: 0
    },
    {
      id: 'healthy-habits',
      title: 'Building Healthy Habits',
      description: 'Develop sustainable spending habits',
      status: 'locked',
      progress: 0
    }
  ],
  confidence: [
    {
      id: 'foundations',
      title: 'Financial Foundations',
      description: 'Master the basics of financial wellness',
      status: 'available',
      progress: 0
    },
    {
      id: 'decision-making',
      title: 'Decision Making',
      description: 'Improve your financial decision-making skills',
      status: 'locked',
      progress: 0
    },
    {
      id: 'goal-setting',
      title: 'Goal Achievement',
      description: 'Set and achieve meaningful financial goals',
      status: 'locked',
      progress: 0
    }
  ]
};

export const pathNames = {
  spending: 'Spending Control Journey',
  anxiety: 'Financial Mindfulness Path',
  confidence: 'Confidence Building Track'
};