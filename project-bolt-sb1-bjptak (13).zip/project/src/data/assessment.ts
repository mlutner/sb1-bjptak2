export const programBenefits = [
  {
    title: "Financial Wellness",
    description: "Learn to manage money stress and build healthy financial habits",
    metrics: "78% of participants report reduced financial anxiety"
  },
  {
    title: "Professional Support",
    description: "Access to financial therapists and AI-powered guidance",
    metrics: "24/7 support available through our platform"
  },
  {
    title: "Practical Tools",
    description: "Interactive budgeting, mood tracking, and spending analysis",
    metrics: "Average 15% improvement in financial confidence"
  },
  {
    title: "Personalized Journey",
    description: "Customized pathway based on your needs and goals",
    metrics: "92% program completion rate"
  }
];

export const assessmentQuestions = [
  {
    id: 'financial_stress',
    question: "How would you rate your current level of financial stress?",
    options: [
      { value: 'high', label: 'High - It affects my daily life and well-being' },
      { value: 'moderate', label: 'Moderate - I worry about finances occasionally' },
      { value: 'low', label: 'Low - I feel generally in control of my finances' }
    ]
  },
  {
    id: 'primary_goal',
    question: "What's your primary financial goal right now?",
    options: [
      { value: 'debt', label: 'Managing or reducing debt' },
      { value: 'savings', label: 'Building savings and emergency fund' },
      { value: 'investing', label: 'Learning about investing and growth' },
      { value: 'budgeting', label: 'Creating and sticking to a budget' }
    ]
  },
  {
    id: 'support_preference',
    question: "What type of support would you find most helpful?",
    options: [
      { value: 'self_guided', label: 'Self-guided with digital tools' },
      { value: 'therapy', label: 'One-on-one therapy sessions' },
      { value: 'group', label: 'Group workshops and peer support' },
      { value: 'mixed', label: 'Combination of different support types' }
    ]
  },
  {
    id: 'learning_style',
    question: "How do you prefer to learn new information?",
    options: [
      { value: 'visual', label: 'Visual - charts, videos, and graphics' },
      { value: 'interactive', label: 'Interactive - exercises and practice' },
      { value: 'reading', label: 'Reading - articles and written content' },
      { value: 'audio', label: 'Audio - podcasts and voice content' }
    ]
  },
  {
    id: 'time_commitment',
    question: "How much time can you commit to the program weekly?",
    options: [
      { value: 'minimal', label: '15-30 minutes' },
      { value: 'moderate', label: '1-2 hours' },
      { value: 'extensive', label: '3+ hours' }
    ]
  }
];