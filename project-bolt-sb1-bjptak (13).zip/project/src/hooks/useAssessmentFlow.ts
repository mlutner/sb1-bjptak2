import { useState, useCallback } from 'react';
import { AssessmentStep, AssessmentResponse, AssessmentState } from '../types/assessment';
import { assessmentSteps } from '../data/assessmentSteps';

export function useAssessmentFlow() {
  const [state, setState] = useState<AssessmentState>({
    currentStep: 0,
    responses: {},
    isComplete: false
  });

  const setResponse = useCallback((stepId: string, response: any) => {
    setState(prev => ({
      ...prev,
      responses: {
        ...prev.responses,
        [stepId]: {
          stepId,
          response,
          timestamp: Date.now()
        }
      }
    }));
  }, []);

  const nextStep = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentStep: Math.min(prev.currentStep + 1, assessmentSteps.length - 1),
      isComplete: prev.currentStep === assessmentSteps.length - 1
    }));
  }, []);

  const previousStep = useCallback(() => {
    setState(prev => ({
      ...prev,
      currentStep: Math.max(0, prev.currentStep - 1)
    }));
  }, []);

  const getCurrentStep = useCallback(() => {
    return assessmentSteps[state.currentStep];
  }, [state.currentStep]);

  const getProgress = useCallback(() => {
    return ((state.currentStep + 1) / assessmentSteps.length) * 100;
  }, [state.currentStep]);

  const canProceed = useCallback(() => {
    const currentStep = getCurrentStep();
    if (!currentStep.required) return true;
    return !!state.responses[currentStep.id];
  }, [state.currentStep, state.responses]);

  return {
    state,
    setResponse,
    nextStep,
    previousStep,
    getCurrentStep,
    getProgress,
    canProceed
  };
}