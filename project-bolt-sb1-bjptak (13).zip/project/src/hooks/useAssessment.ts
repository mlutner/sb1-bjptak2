import { useState, useEffect } from 'react';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import { db } from '../config/firebase';
import { UserAssessment } from '../types/assessment';

export const useAssessment = (userId: string) => {
  const [assessment, setAssessment] = useState<UserAssessment | null>(null);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    const loadAssessment = async () => {
      try {
        const docRef = doc(db, 'assessments', userId);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setAssessment(docSnap.data() as UserAssessment);
        }
      } catch (error) {
        console.error('Error loading assessment:', error);
      } finally {
        setLoading(false);
      }
    };
    
    if (userId) {
      loadAssessment();
    }
  }, [userId]);
  
  const saveAssessment = async (data: Partial<UserAssessment>) => {
    if (!userId) return;
    
    try {
      const docRef = doc(db, 'assessments', userId);
      await setDoc(docRef, data, { merge: true });
      setAssessment(prev => prev ? { ...prev, ...data } : null);
      return true;
    } catch (error) {
      console.error('Error saving assessment:', error);
      return false;
    }
  };
  
  return { assessment, loading, saveAssessment };
};