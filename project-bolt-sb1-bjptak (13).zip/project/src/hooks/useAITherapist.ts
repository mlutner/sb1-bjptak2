import { useState, useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import { config } from '../lib/ai/config';
import type { Message } from '../types/chat';

const MOCK_RESPONSES = [
  "I understand how challenging financial stress can be. Let's explore what's troubling you.",
  "That's a common concern. Have you noticed any patterns in when these feelings arise?",
  "It sounds like you're taking important steps to improve your financial wellness.",
  "Let's break this down into smaller, manageable steps.",
  "How does this financial situation make you feel emotionally?",
  "Would you like to explore some coping strategies for financial stress?",
  "I notice you're making progress. How do you feel about these changes?",
  "Let's focus on what you can control in this situation.",
];

export function useAITherapist() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '0',
      text: "Hi! I'm your AI Financial Therapist. How can I help you today?",
      sender: 'ai',
      timestamp: new Date(),
    },
  ]);
  const [isLoading, setIsLoading] = useState(false);
  const toast = useToast();

  const getAIResponse = async (prompt: string) => {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Return random mock response
    return MOCK_RESPONSES[Math.floor(Math.random() * MOCK_RESPONSES.length)];
  };

  const sendMessage = useCallback(async (text: string) => {
    try {
      setIsLoading(true);
      
      const userMessage: Message = {
        id: Date.now().toString(),
        text,
        sender: 'user',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, userMessage]);

      const response = await getAIResponse(text);
      
      const aiMessage: Message = {
        id: (Date.now() + 1).toString(),
        text: response,
        sender: 'ai',
        timestamp: new Date(),
      };
      setMessages(prev => [...prev, aiMessage]);

    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to get AI response. Please try again.',
        status: 'error',
        duration: 3000,
      });
    } finally {
      setIsLoading(false);
    }
  }, [toast]);

  return {
    messages,
    sendMessage,
    isLoading,
  };
}