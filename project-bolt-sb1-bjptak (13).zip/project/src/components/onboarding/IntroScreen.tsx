import {
  Box,
  Button,
  Container,
  Heading,
  Text,
  VStack,
  SimpleGrid,
  Card,
  CardBody,
  Icon,
} from '@chakra-ui/react';
import { FiBookOpen, FiHeart, FiDollarSign, FiTarget } from 'react-icons/fi';

const FEATURES = [
  {
    icon: FiBookOpen,
    title: 'Personalized Path',
    description: 'Tailored to your unique needs and goals'
  },
  {
    icon: FiHeart,
    title: 'Expert Support',
    description: 'AI and human guidance when you need it'
  },
  {
    icon: FiDollarSign,
    title: 'Financial Tools',
    description: 'Track progress and build healthy habits'
  },
  {
    icon: FiTarget,
    title: 'Goal Setting',
    description: 'Achieve your financial objectives'
  }
];

interface Props {
  onStart: () => void;
}

export default function IntroScreen({ onStart }: Props) {
  return (
    <Box minH="100vh" bg="gray.50">
      <Container maxW="container.lg" py={16}>
        <VStack spacing={12} textAlign="center">
          <VStack spacing={4}>
            <Heading size="2xl" bgGradient="linear(to-r, purple.500, blue.500)" bgClip="text">
              Welcome to FinWell
            </Heading>
            <Text fontSize="xl" color="gray.600">
              Your journey to financial wellness begins here
            </Text>
          </VStack>

          <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6} w="full">
            {FEATURES.map((feature) => (
              <Card key={feature.title}>
                <CardBody>
                  <VStack>
                    <Icon as={feature.icon} boxSize={8} color="purple.500" />
                    <Text fontWeight="bold">{feature.title}</Text>
                    <Text fontSize="sm" color="gray.600">
                      {feature.description}
                    </Text>
                  </VStack>
                </CardBody>
              </Card>
            ))}
          </SimpleGrid>

          <Button
            size="lg"
            colorScheme="purple"
            onClick={onStart}
            px={12}
            py={7}
            fontSize="lg"
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
              transform: "translateY(-2px)",
            }}
            shadow="lg"
          >
            Start Your Journey
          </Button>
        </VStack>
      </Container>
    </Box>
  );
}