import {
  Box,
  Button,
  Container,
  Heading,
  Text,
  VStack,
  Image,
  useDisclosure,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalBody,
  ModalCloseButton,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';

export default function WelcomeScreen() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const navigate = useNavigate();

  const handleStart = () => {
    navigate('/assessment');
  };

  return (
    <Box minH="100vh" bg="gray.50">
      <Container maxW="container.md" py={16}>
        <VStack spacing={8} textAlign="center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <Image
              src="/finwell-logo.svg"
              alt="FinWell Logo"
              boxSize="150px"
              mb={6}
            />
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <Heading
              size="2xl"
              bgGradient="linear(to-r, purple.500, blue.500)"
              bgClip="text"
              mb={4}
            >
              Welcome to FinWell
            </Heading>
            <Text fontSize="xl" color="gray.600">
              Your journey to financial wellness begins here
            </Text>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.4 }}
          >
            <Button
              size="lg"
              colorScheme="purple"
              onClick={handleStart}
              px={12}
              py={7}
              fontSize="lg"
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
                transform: "translateY(-2px)",
              }}
              shadow="lg"
            >
              Start Your Journey
            </Button>
          </motion.div>
        </VStack>
      </Container>

      <Modal isOpen={isOpen} onClose={onClose} size="xl">
        <ModalOverlay />
        <ModalContent>
          <ModalCloseButton />
          <ModalBody p={8}>
            <VStack spacing={6}>
              <Heading size="lg">How FinWell Works</Heading>
              <Text>
                FinWell combines financial wellness with behavioral psychology to help
                you build better money habits and reduce financial stress.
              </Text>
              {/* Add more content about how the platform works */}
            </VStack>
          </ModalBody>
        </ModalContent>
      </Modal>
    </Box>
  );
}