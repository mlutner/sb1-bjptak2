import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  VStack,
  Image,
  Progress,
  Button,
  Grid,
  GridItem,
  useBreakpointValue,
} from '@chakra-ui/react';
import { useState } from 'react';
import AudioPlayer from '../AudioPlayer';
import VideoLesson from './VideoLesson';
import EmotionalAwarenessExercise from './exercises/EmotionalAwarenessExercise';
import MoneyBeliefsWorksheet from './exercises/MoneyBeliefsWorksheet';
import EmotionalSpendingLog from './exercises/EmotionalSpendingLog';

const steps = [
  { id: 'intro', title: 'Introduction' },
  { id: 'video', title: 'Video Lesson' },
  { id: 'awareness', title: 'Emotional Awareness Exercise' },
  { id: 'beliefs', title: 'Money Beliefs Worksheet' },
  { id: 'spending', title: 'Emotional Spending Log' }
];

export default function Module2Intro() {
  const [currentStep, setCurrentStep] = useState(0);
  const progress = ((currentStep + 1) / steps.length) * 100;
  const isMobile = useBreakpointValue({ base: true, md: false });

  const handleNext = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentStep > 0) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const renderStep = () => {
    switch (steps[currentStep].id) {
      case 'intro':
        return (
          <VStack spacing={6} align="stretch">
            <Box
              borderRadius="xl"
              overflow="hidden"
              height="300px"
              position="relative"
            >
              <Image
                src="https://images.unsplash.com/photo-1633158829585-23ba8f7c8caf"
                alt="Understanding Money Emotions"
                objectFit="cover"
                w="100%"
                h="100%"
              />
              <Box
                position="absolute"
                bottom={0}
                left={0}
                right={0}
                bg="blackAlpha.600"
                p={6}
                color="white"
              >
                <Heading size="lg">Module 2: Understanding Money Emotions</Heading>
                <Text mt={2}>Explore the emotional aspects of your financial decisions</Text>
              </Box>
            </Box>

            <AudioPlayer 
              title="Listen to Module Introduction" 
              duration="3:15"
            />

            <Grid templateColumns={{ base: '1fr', md: '1fr 1fr' }} gap={6}>
              <GridItem>
                <Box bg="purple.50" p={6} rounded="lg">
                  <Heading size="md" color="purple.700" mb={4}>What You'll Learn</Heading>
                  <VStack align="start" spacing={3}>
                    <Text>• Identify emotional triggers in financial decisions</Text>
                    <Text>• Understand your money beliefs and their origins</Text>
                    <Text>• Recognize patterns in emotional spending</Text>
                    <Text>• Develop healthier financial relationships</Text>
                  </VStack>
                </Box>
              </GridItem>

              <GridItem>
                <Box bg="blue.50" p={6} rounded="lg">
                  <Heading size="md" color="blue.700" mb={4}>Module Activities</Heading>
                  <VStack align="start" spacing={3}>
                    <Text>• Guided video lesson</Text>
                    <Text>• Emotional awareness exercises</Text>
                    <Text>• Money beliefs worksheet</Text>
                    <Text>• Spending patterns analysis</Text>
                  </VStack>
                </Box>
              </GridItem>
            </Grid>
          </VStack>
        );

      case 'video':
        return <VideoLesson videoUrl="/module2-lesson.mp4" onComplete={handleNext} />;

      case 'awareness':
        return <EmotionalAwarenessExercise onComplete={handleNext} />;

      case 'beliefs':
        return <MoneyBeliefsWorksheet onComplete={handleNext} />;

      case 'spending':
        return <EmotionalSpendingLog onComplete={handleNext} />;

      default:
        return null;
    }
  };

  return (
    <Card>
      <CardHeader p={0}>
        <Box p={4}>
          <Text mb={2} color="gray.600">Module Progress</Text>
          <Progress
            value={progress}
            size="sm"
            colorScheme="purple"
            borderRadius="full"
            mb={4}
          />
          <Text fontSize="sm" color="gray.600">
            Step {currentStep + 1} of {steps.length}: {steps[currentStep].title}
          </Text>
        </Box>
      </CardHeader>

      <CardBody>
        {renderStep()}

        <Grid templateColumns="repeat(2, 1fr)" gap={4} mt={6}>
          <Button
            onClick={handlePrevious}
            isDisabled={currentStep === 0}
            variant="outline"
          >
            Previous
          </Button>
          <Button
            onClick={handleNext}
            isDisabled={currentStep === steps.length - 1}
            colorScheme="purple"
          >
            {currentStep === steps.length - 1 ? 'Complete' : 'Next'}
          </Button>
        </Grid>
      </CardBody>
    </Card>
  );
}