import {
  AspectRatio,
  Box,
  Button,
  Text,
  VStack,
  Progress,
  Icon,
} from '@chakra-ui/react';
import { useState, useRef } from 'react';
import { FiPlay, FiPause } from 'react-icons/fi';

interface Props {
  videoUrl: string;
  onComplete: () => void;
}

export default function VideoLesson({ videoUrl, onComplete }: Props) {
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const videoRef = useRef<HTMLVideoElement>(null);

  const handlePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      const progress = (videoRef.current.currentTime / videoRef.current.duration) * 100;
      setProgress(progress);
      
      if (progress >= 100) {
        onComplete();
      }
    }
  };

  return (
    <VStack spacing={6} align="stretch">
      <Box bg="gray.900" rounded="lg" overflow="hidden">
        <AspectRatio ratio={16 / 9}>
          <video
            ref={videoRef}
            src={videoUrl}
            onTimeUpdate={handleTimeUpdate}
            onPlay={() => setIsPlaying(true)}
            onPause={() => setIsPlaying(false)}
            style={{ width: '100%', height: '100%', objectFit: 'cover' }}
          />
        </AspectRatio>
      </Box>

      <Box>
        <Text mb={2}>Lesson Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      <Button
        leftIcon={<Icon as={isPlaying ? FiPause : FiPlay} />}
        onClick={handlePlayPause}
        colorScheme="purple"
        variant="outline"
      >
        {isPlaying ? 'Pause' : 'Play'} Lesson
      </Button>
    </VStack>
  );
}