import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Text,
  VStack,
  useToast,
  Grid,
  Progress,
} from '@chakra-ui/react';
import { useState } from 'react';
import { motion } from 'framer-motion';
import SmartCriteria from './SmartCriteria';
import GoalForm from './GoalForm';
import GoalSummary from './GoalSummary';
import type { Goal } from '../../../types/goals';

interface Props {
  onComplete: (goals: Goal[]) => void;
}

export default function GoalSettingWorksheet({ onComplete }: Props) {
  const [goals, setGoals] = useState<Goal[]>([{
    type: '',
    timeframe: '',
    description: '',
    target: '',
    steps: [''],
    obstacles: [''],
    support: [''],
    metrics: ''
  }]);
  const toast = useToast();

  const handleSubmit = () => {
    if (!validateGoals()) {
      toast({
        title: 'Please complete all fields',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    onComplete(goals);
    toast({
      title: 'Goals saved successfully',
      description: 'Your SMART goals have been saved',
      status: 'success',
      duration: 3000,
    });
  };

  const validateGoals = () => {
    return goals.every(goal => 
      Object.entries(goal).every(([key, value]) => {
        if (Array.isArray(value)) {
          return value.length > 0 && value.every(item => item.trim() !== '');
        }
        return value.trim() !== '';
      })
    );
  };

  const addGoal = () => {
    setGoals([...goals, {
      type: '',
      timeframe: '',
      description: '',
      target: '',
      steps: [''],
      obstacles: [''],
      support: [''],
      metrics: ''
    }]);
  };

  const updateGoal = (index: number, updatedGoal: Goal) => {
    const updatedGoals = [...goals];
    updatedGoals[index] = updatedGoal;
    setGoals(updatedGoals);
  };

  const removeGoal = (index: number) => {
    if (goals.length > 1) {
      const updatedGoals = goals.filter((_, i) => i !== index);
      setGoals(updatedGoals);
    }
  };

  const progress = Math.round(
    (goals.reduce((acc, goal) => 
      acc + Object.values(goal).filter(v => 
        Array.isArray(v) ? v.some(item => item.trim() !== '') : v.trim() !== ''
      ).length, 0
    ) / (goals.length * 8)) * 100
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
    >
      <Card>
        <CardHeader>
          <Grid templateColumns={{ base: '1fr', md: '2fr 1fr' }} gap={4} alignItems="center">
            <Box>
              <Heading size="lg">SMART Goal Setting</Heading>
              <Text mt={2} color="gray.600">
                Define your financial and wellness goals using the SMART framework
              </Text>
            </Box>
            <Box>
              <Text mb={2} fontWeight="medium">Overall Progress</Text>
              <Progress 
                value={progress} 
                size="lg" 
                colorScheme="purple" 
                borderRadius="full"
                hasStripe
                isAnimated
              />
            </Box>
          </Grid>
        </CardHeader>

        <CardBody>
          <VStack spacing={8} align="stretch">
            <SmartCriteria />

            {goals.map((goal, index) => (
              <GoalForm
                key={index}
                goal={goal}
                onUpdate={(updatedGoal) => updateGoal(index, updatedGoal)}
                onRemove={() => removeGoal(index)}
                isRemovable={goals.length > 1}
                index={index}
              />
            ))}

            <Button
              onClick={addGoal}
              variant="outline"
              colorScheme="purple"
              size="lg"
            >
              Add Another Goal
            </Button>

            {goals.length > 0 && (
              <GoalSummary goals={goals} />
            )}

            <Button
              colorScheme="purple"
              size="lg"
              onClick={handleSubmit}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Save Goals
            </Button>
          </VStack>
        </CardBody>
      </Card>
    </motion.div>
  );
}