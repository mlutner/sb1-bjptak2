import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Textarea,
  VStack,
  Text,
  Radio,
  RadioGroup,
  Stack,
  Progress,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: () => void;
}

export default function EmotionalAwarenessExercise({ onComplete }: Props) {
  const [step, setStep] = useState(0);
  const [responses, setResponses] = useState({
    situation: '',
    emotion: '',
    intensity: '',
    reflection: ''
  });

  const handleNext = () => {
    if (step < 3) {
      setStep(step + 1);
    } else {
      onComplete();
    }
  };

  const progress = ((step + 1) / 4) * 100;

  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text mb={2}>Exercise Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      {step === 0 && (
        <FormControl>
          <FormLabel>Describe a recent financial situation that triggered strong emotions:</FormLabel>
          <Textarea
            value={responses.situation}
            onChange={(e) => setResponses({ ...responses, situation: e.target.value })}
            placeholder="Example: Checking my credit card statement..."
            minH="150px"
          />
        </FormControl>
      )}

      {step === 1 && (
        <FormControl>
          <FormLabel>What emotions did you experience?</FormLabel>
          <RadioGroup
            value={responses.emotion}
            onChange={(value) => setResponses({ ...responses, emotion: value })}
          >
            <Stack spacing={3}>
              <Radio value="anxiety">Anxiety</Radio>
              <Radio value="guilt">Guilt</Radio>
              <Radio value="shame">Shame</Radio>
              <Radio value="fear">Fear</Radio>
              <Radio value="other">Other</Radio>
            </Stack>
          </RadioGroup>
        </FormControl>
      )}

      {step === 2 && (
        <FormControl>
          <FormLabel>How intense was this emotion? (1-10)</FormLabel>
          <RadioGroup
            value={responses.intensity}
            onChange={(value) => setResponses({ ...responses, intensity: value })}
          >
            <Stack spacing={3} direction="row">
              {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                <Radio key={num} value={num.toString()}>
                  {num}
                </Radio>
              ))}
            </Stack>
          </RadioGroup>
        </FormControl>
      )}

      {step === 3 && (
        <FormControl>
          <FormLabel>Reflect on how this emotion influenced your financial behavior:</FormLabel>
          <Textarea
            value={responses.reflection}
            onChange={(e) => setResponses({ ...responses, reflection: e.target.value })}
            placeholder="How did this emotion affect your decisions or actions?"
            minH="150px"
          />
        </FormControl>
      )}

      <Button
        colorScheme="purple"
        onClick={handleNext}
        isDisabled={
          (step === 0 && !responses.situation) ||
          (step === 1 && !responses.emotion) ||
          (step === 2 && !responses.intensity) ||
          (step === 3 && !responses.reflection)
        }
      >
        {step === 3 ? 'Complete' : 'Next'}
      </Button>
    </VStack>
  );
}