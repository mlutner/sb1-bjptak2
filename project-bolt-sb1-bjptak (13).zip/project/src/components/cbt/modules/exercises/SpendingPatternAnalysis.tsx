import {
  Box,
  Button,
  FormControl,
  FormLabel,
  VStack,
  Text,
  Progress,
  Grid,
  GridItem,
  Textarea,
  Select,
  Input,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: () => void;
}

export default function SpendingPatternAnalysis({ onComplete }: Props) {
  const [analysis, setAnalysis] = useState({
    timePatterns: '',
    locationPatterns: '',
    emotionalStates: '',
    typicalAmount: '',
    frequency: '',
    satisfaction: '',
    alternatives: '',
    insights: ''
  });

  const isComplete = Object.values(analysis).every(value => value.trim() !== '');
  const progress = (Object.values(analysis).filter(value => value.trim() !== '').length / 8) * 100;

  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text mb={2}>Analysis Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
        <GridItem>
          <FormControl>
            <FormLabel>When do you typically spend?</FormLabel>
            <Textarea
              value={analysis.timePatterns}
              onChange={(e) => setAnalysis({ ...analysis, timePatterns: e.target.value })}
              placeholder="Time of day, days of week, etc."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Where do you typically spend?</FormLabel>
            <Textarea
              value={analysis.locationPatterns}
              onChange={(e) => setAnalysis({ ...analysis, locationPatterns: e.target.value })}
              placeholder="Locations, websites, stores..."
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Common emotional states when spending:</FormLabel>
            <Select
              value={analysis.emotionalStates}
              onChange={(e) => setAnalysis({ ...analysis, emotionalStates: e.target.value })}
            >
              <option value="">Select state</option>
              <option value="stressed">Stressed</option>
              <option value="happy">Happy</option>
              <option value="bored">Bored</option>
              <option value="anxious">Anxious</option>
              <option value="other">Other</option>
            </Select>
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Typical amount spent:</FormLabel>
            <Input
              value={analysis.typicalAmount}
              onChange={(e) => setAnalysis({ ...analysis, typicalAmount: e.target.value })}
              placeholder="Average amount"
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>How often does this occur?</FormLabel>
            <Select
              value={analysis.frequency}
              onChange={(e) => setAnalysis({ ...analysis, frequency: e.target.value })}
            >
              <option value="">Select frequency</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
              <option value="occasionally">Occasionally</option>
            </Select>
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Post-spending satisfaction (1-10):</FormLabel>
            <Select
              value={analysis.satisfaction}
              onChange={(e) => setAnalysis({ ...analysis, satisfaction: e.target.value })}
            >
              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                <option key={num} value={num}>{num}</option>
              ))}
            </Select>
          </FormControl>
        </GridItem>

        <GridItem colSpan={{ base: 1, md: 2 }}>
          <FormControl>
            <FormLabel>Alternative activities or coping mechanisms:</FormLabel>
            <Textarea
              value={analysis.alternatives}
              onChange={(e) => setAnalysis({ ...analysis, alternatives: e.target.value })}
              placeholder="What else could you do instead?"
            />
          </FormControl>
        </GridItem>

        <GridItem colSpan={{ base: 1, md: 2 }}>
          <FormControl>
            <FormLabel>Key insights from this analysis:</FormLabel>
            <Textarea
              value={analysis.insights}
              onChange={(e) => setAnalysis({ ...analysis, insights: e.target.value })}
              placeholder="What patterns do you notice?"
            />
          </FormControl>
        </GridItem>
      </Grid>

      <Button
        colorScheme="purple"
        onClick={onComplete}
        isDisabled={!isComplete}
      >
        Complete Analysis
      </Button>
    </VStack>
  );
}