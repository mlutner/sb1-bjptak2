import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  Textarea,
  Select,
  Progress,
  Grid,
  GridItem,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Props {
  onComplete: () => void;
}

export default function TriggerIdentificationExercise({ onComplete }: Props) {
  const [triggers, setTriggers] = useState({
    situation: '',
    location: '',
    time: '',
    people: '',
    emotion: '',
    thoughts: '',
    behavior: '',
    intensity: ''
  });

  const isComplete = Object.values(triggers).every(value => value.trim() !== '');
  const progress = (Object.values(triggers).filter(value => value.trim() !== '').length / 8) * 100;

  return (
    <VStack spacing={6} align="stretch">
      <Box>
        <Text mb={2}>Exercise Progress</Text>
        <Progress value={progress} size="sm" colorScheme="purple" rounded="full" />
      </Box>

      <Grid templateColumns={{ base: '1fr', md: 'repeat(2, 1fr)' }} gap={6}>
        <GridItem>
          <FormControl>
            <FormLabel>Describe the situation:</FormLabel>
            <Textarea
              value={triggers.situation}
              onChange={(e) => setTriggers({ ...triggers, situation: e.target.value })}
              placeholder="What happened?"
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Where were you?</FormLabel>
            <Input
              value={triggers.location}
              onChange={(e) => setTriggers({ ...triggers, location: e.target.value })}
              placeholder="Location"
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>When did it happen?</FormLabel>
            <Input
              value={triggers.time}
              onChange={(e) => setTriggers({ ...triggers, time: e.target.value })}
              placeholder="Time of day"
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Who was involved?</FormLabel>
            <Input
              value={triggers.people}
              onChange={(e) => setTriggers({ ...triggers, people: e.target.value })}
              placeholder="People present"
            />
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>What emotion did you feel?</FormLabel>
            <Select
              value={triggers.emotion}
              onChange={(e) => setTriggers({ ...triggers, emotion: e.target.value })}
            >
              <option value="">Select emotion</option>
              <option value="anxiety">Anxiety</option>
              <option value="stress">Stress</option>
              <option value="frustration">Frustration</option>
              <option value="excitement">Excitement</option>
              <option value="other">Other</option>
            </Select>
          </FormControl>
        </GridItem>

        <GridItem>
          <FormControl>
            <FormLabel>Intensity (1-10):</FormLabel>
            <Select
              value={triggers.intensity}
              onChange={(e) => setTriggers({ ...triggers, intensity: e.target.value })}
            >
              {[1,2,3,4,5,6,7,8,9,10].map(num => (
                <option key={num} value={num}>{num}</option>
              ))}
            </Select>
          </FormControl>
        </GridItem>

        <GridItem colSpan={{ base: 1, md: 2 }}>
          <FormControl>
            <FormLabel>What thoughts went through your mind?</FormLabel>
            <Textarea
              value={triggers.thoughts}
              onChange={(e) => setTriggers({ ...triggers, thoughts: e.target.value })}
              placeholder="Your thoughts..."
            />
          </FormControl>
        </GridItem>

        <GridItem colSpan={{ base: 1, md: 2 }}>
          <FormControl>
            <FormLabel>How did you respond (behavior)?</FormLabel>
            <Textarea
              value={triggers.behavior}
              onChange={(e) => setTriggers({ ...triggers, behavior: e.target.value })}
              placeholder="Your response..."
            />
          </FormControl>
        </GridItem>
      </Grid>

      <Button
        colorScheme="purple"
        onClick={onComplete}
        isDisabled={!isComplete}
      >
        Complete Exercise
      </Button>
    </VStack>
  );
}