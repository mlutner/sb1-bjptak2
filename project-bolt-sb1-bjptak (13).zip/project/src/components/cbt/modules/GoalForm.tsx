import {
  Box,
  Button,
  Card,
  Collapse,
  Flex,
  FormControl,
  FormLabel,
  IconButton,
  Input,
  Select,
  Text,
  Textarea,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import { FiTrash2, FiPlus, FiChevronUp, FiChevronDown } from 'react-icons/fi';
import type { Goal } from '../../../types/goals';

interface Props {
  goal: Goal;
  onUpdate: (goal: Goal) => void;
  onRemove: () => void;
  isRemovable: boolean;
  index: number;
}

export default function GoalForm({ goal, onUpdate, onRemove, isRemovable, index }: Props) {
  const { isOpen, onToggle } = useDisclosure({ defaultIsOpen: true });

  const handleChange = (field: keyof Goal, value: string | string[]) => {
    onUpdate({ ...goal, [field]: value });
  };

  const addArrayItem = (field: 'steps' | 'obstacles' | 'support') => {
    const updatedArray = [...goal[field], ''];
    handleChange(field, updatedArray);
  };

  const updateArrayItem = (
    field: 'steps' | 'obstacles' | 'support',
    index: number,
    value: string
  ) => {
    const updatedArray = [...goal[field]];
    updatedArray[index] = value;
    handleChange(field, updatedArray);
  };

  const removeArrayItem = (field: 'steps' | 'obstacles' | 'support', index: number) => {
    if (goal[field].length > 1) {
      const updatedArray = goal[field].filter((_, i) => i !== index);
      handleChange(field, updatedArray);
    }
  };

  return (
    <Card variant="outline">
      <Box p={6}>
        <Flex justify="space-between" align="center" mb={4}>
          <Text fontSize="lg" fontWeight="medium">Goal {index + 1}</Text>
          <Flex gap={2}>
            {isRemovable && (
              <IconButton
                aria-label="Remove goal"
                icon={<FiTrash2 />}
                onClick={onRemove}
                variant="ghost"
                colorScheme="red"
                size="sm"
              />
            )}
            <IconButton
              aria-label={isOpen ? 'Collapse' : 'Expand'}
              icon={isOpen ? <FiChevronUp /> : <FiChevronDown />}
              onClick={onToggle}
              variant="ghost"
              size="sm"
            />
          </Flex>
        </Flex>

        <Collapse in={isOpen}>
          <VStack spacing={6} align="stretch">
            <FormControl>
              <FormLabel>Goal Type</FormLabel>
              <Select
                value={goal.type}
                onChange={(e) => handleChange('type', e.target.value)}
              >
                <option value="">Select type</option>
                <option value="saving">Saving</option>
                <option value="spending">Spending</option>
                <option value="debt">Debt Management</option>
                <option value="income">Income</option>
                <option value="investment">Investment</option>
                <option value="wellness">Financial Wellness</option>
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Timeframe</FormLabel>
              <Select
                value={goal.timeframe}
                onChange={(e) => handleChange('timeframe', e.target.value)}
              >
                <option value="">Select timeframe</option>
                <option value="1month">1 Month</option>
                <option value="3months">3 Months</option>
                <option value="6months">6 Months</option>
                <option value="1year">1 Year</option>
                <option value="2years">2+ Years</option>
              </Select>
            </FormControl>

            <FormControl>
              <FormLabel>Goal Description</FormLabel>
              <Textarea
                value={goal.description}
                onChange={(e) => handleChange('description', e.target.value)}
                placeholder="What do you want to achieve? Be specific."
              />
            </FormControl>

            <FormControl>
              <FormLabel>Target (Measurable Outcome)</FormLabel>
              <Input
                value={goal.target}
                onChange={(e) => handleChange('target', e.target.value)}
                placeholder="e.g., Save $5000, Reduce spending by 20%"
              />
            </FormControl>

            <FormControl>
              <FormLabel>Success Metrics</FormLabel>
              <Input
                value={goal.metrics}
                onChange={(e) => handleChange('metrics', e.target.value)}
                placeholder="How will you measure success?"
              />
            </FormControl>

            {/* Action Steps */}
            <Box>
              <Flex justify="space-between" align="center" mb={2}>
                <FormLabel mb={0}>Action Steps</FormLabel>
                <IconButton
                  size="sm"
                  icon={<FiPlus />}
                  aria-label="Add step"
                  onClick={() => addArrayItem('steps')}
                  variant="ghost"
                />
              </Flex>
              <VStack spacing={2}>
                {goal.steps.map((step, index) => (
                  <Flex key={index} gap={2}>
                    <Input
                      value={step}
                      onChange={(e) => updateArrayItem('steps', index, e.target.value)}
                      placeholder={`Step ${index + 1}`}
                    />
                    {goal.steps.length > 1 && (
                      <IconButton
                        icon={<FiTrash2 />}
                        aria-label="Remove step"
                        onClick={() => removeArrayItem('steps', index)}
                        variant="ghost"
                        size="sm"
                      />
                    )}
                  </Flex>
                ))}
              </VStack>
            </Box>

            {/* Obstacles */}
            <Box>
              <Flex justify="space-between" align="center" mb={2}>
                <FormLabel mb={0}>Potential Obstacles</FormLabel>
                <IconButton
                  size="sm"
                  icon={<FiPlus />}
                  aria-label="Add obstacle"
                  onClick={() => addArrayItem('obstacles')}
                  variant="ghost"
                />
              </Flex>
              <VStack spacing={2}>
                {goal.obstacles.map((obstacle, index) => (
                  <Flex key={index} gap={2}>
                    <Input
                      value={obstacle}
                      onChange={(e) => updateArrayItem('obstacles', index, e.target.value)}
                      placeholder="What might get in your way?"
                    />
                    {goal.obstacles.length > 1 && (
                      <IconButton
                        icon={<FiTrash2 />}
                        aria-label="Remove obstacle"
                        onClick={() => removeArrayItem('obstacles', index)}
                        variant="ghost"
                        size="sm"
                      />
                    )}
                  </Flex>
                ))}
              </VStack>
            </Box>

            {/* Support & Resources */}
            <Box>
              <Flex justify="space-between" align="center" mb={2}>
                <FormLabel mb={0}>Support & Resources</FormLabel>
                <IconButton
                  size="sm"
                  icon={<FiPlus />}
                  aria-label="Add support"
                  onClick={() => addArrayItem('support')}
                  variant="ghost"
                />
              </Flex>
              <VStack spacing={2}>
                {goal.support.map((support, index) => (
                  <Flex key={index} gap={2}>
                    <Input
                      value={support}
                      onChange={(e) => updateArrayItem('support', index, e.target.value)}
                      placeholder="What resources or support will help you succeed?"
                    />
                    {goal.support.length > 1 && (
                      <IconButton
                        icon={<FiTrash2 />}
                        aria-label="Remove support"
                        onClick={() => removeArrayItem('support', index)}
                        variant="ghost"
                        size="sm"
                      />
                    )}
                  </Flex>
                ))}
              </VStack>
            </Box>
          </VStack>
        </Collapse>
      </Box>
    </Card>
  );
}