import {
  Box,
  Button,
  Container,
  Flex,
  Menu,
  MenuButton,
  MenuList,
  MenuItem,
  Avatar,
  Text,
  HStack,
  VStack,
  useColorMode,
  Image,
  Icon,
  IconButton,
  useBreakpointValue,
  Drawer,
  DrawerBody,
  DrawerHeader,
  DrawerOverlay,
  DrawerContent,
  DrawerCloseButton,
  useDisclosure,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { FiShield, FiMenu } from 'react-icons/fi';

export default function Navigation() {
  const { logout } = useAuth();
  const navigate = useNavigate();
  const { colorMode, toggleColorMode } = useColorMode();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const isMobile = useBreakpointValue({ base: true, md: false });

  const handleLogout = async () => {
    try {
      await logout();
      navigate('/signin');
    } catch (error) {
      console.error('Error signing out:', error);
    }
  };

  const handleAdminPanel = () => {
    navigate('/admin');
  };

  const NavContent = () => (
    <HStack spacing={4}>
      <Button
        leftIcon={<Icon as={FiShield} />}
        colorScheme="purple"
        variant="outline"
        size="sm"
        onClick={handleAdminPanel}
      >
        Admin Panel
      </Button>

      <Menu>
        <MenuButton>
          <HStack spacing={3} cursor="pointer">
            <Avatar
              size="sm"
              name="Demo User"
              bg="purple.500"
            />
            <Box display={{ base: 'none', md: 'block' }}>
              <Text fontWeight="medium" fontSize="sm">
                Demo User
              </Text>
              <Text fontSize="xs" color="gray.500">
                Free Plan
              </Text>
            </Box>
          </HStack>
        </MenuButton>
        <MenuList>
          <MenuItem onClick={handleLogout}>Sign Out</MenuItem>
        </MenuList>
      </Menu>
    </HStack>
  );

  return (
    <Box bg="white" px={4} shadow="sm" position="sticky" top={0} zIndex={100}>
      <Container maxW="container.xl">
        <Flex h={16} alignItems="center" justifyContent="space-between">
          <HStack spacing={3}>
            <Image 
              src="/finwell-logo.svg" 
              h="12" 
              w="12" 
              alt="FinWell Logo"
              fallbackSrc="https://via.placeholder.com/48"
            />
            <Text
              fontSize="xl"
              fontWeight="bold"
              bgGradient="linear(to-r, purple.500, blue.500)"
              bgClip="text"
            >
              FinWell
            </Text>
          </HStack>

          {isMobile ? (
            <>
              <IconButton
                aria-label="Open menu"
                icon={<FiMenu />}
                variant="ghost"
                onClick={onOpen}
              />
              <Drawer isOpen={isOpen} onClose={onClose} placement="right">
                <DrawerOverlay />
                <DrawerContent>
                  <DrawerCloseButton />
                  <DrawerHeader>Menu</DrawerHeader>
                  <DrawerBody>
                    <VStack spacing={4} align="stretch">
                      <NavContent />
                    </VStack>
                  </DrawerBody>
                </DrawerContent>
              </Drawer>
            </>
          ) : (
            <NavContent />
          )}
        </Flex>
      </Container>
    </Box>
  );
}