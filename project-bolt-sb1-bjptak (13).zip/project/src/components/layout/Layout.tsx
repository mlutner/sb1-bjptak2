import { Box, useBreakpointValue } from '@chakra-ui/react';
import Sidebar from './Sidebar';
import Navigation from './Navigation';
import AIChat from '../chat/AIChat';
import MobileNav from './MobileNav';
import { useUIStore } from '../../lib/cache/store';

interface LayoutProps {
  children: React.ReactNode;
}

export default function Layout({ children }: LayoutProps) {
  const isCollapsed = useUIStore(state => state.sidebarCollapsed);
  const isMobile = useBreakpointValue({ base: true, md: false });

  return (
    <Box minH="100vh" bg="gray.50">
      {!isMobile && <Sidebar />}
      <Box
        ml={{ base: 0, md: isCollapsed ? '20' : '64' }}
        transition="margin 0.3s ease"
        position="relative"
      >
        <Navigation />
        <Box 
          p={{ base: 4, md: 8 }} 
          maxW="1600px" 
          mx="auto"
          pb={{ base: '80px', md: '0' }} // Space for mobile nav
        >
          {children}
        </Box>
        <AIChat />
        {isMobile && <MobileNav />}
      </Box>
    </Box>
  );
}