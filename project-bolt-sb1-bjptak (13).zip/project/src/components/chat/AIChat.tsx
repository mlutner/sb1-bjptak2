import { Box, useBreakpointValue } from '@chakra-ui/react';
import DesktopChat from './DesktopChat';
import MobileChat from './MobileChat';

interface Props {
  context?: string;
  initialMessage?: string;
  position?: 'fixed' | 'relative';
  showExplainer?: boolean;
}

export default function AIChat({
  context = 'general',
  initialMessage = "Hi! I'm your AI financial wellness assistant. How can I help you today?",
  position = 'fixed',
  showExplainer = true,
}: Props) {
  const isMobile = useBreakpointValue({ base: true, md: false });

  if (isMobile) {
    return <MobileChat context={context} initialMessage={initialMessage} />;
  }

  return (
    <DesktopChat 
      context={context} 
      initialMessage={initialMessage} 
      position={position} 
      showExplainer={showExplainer} 
    />
  );
}