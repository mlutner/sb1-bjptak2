import { useState } from 'react';
import { 
  Box, 
  Button, 
  Input, 
  VStack, 
  Text, 
  IconButton,
  useDisclosure,
  Flex,
  DrawerHeader
} from '@chakra-ui/react';
import { FiMessageSquare, FiSend } from 'react-icons/fi';
import BottomSheet from '../common/BottomSheet';

interface Props {
  context?: string;
  initialMessage?: string;
}

export default function MobileChat({ context, initialMessage }: Props) {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [messages, setMessages] = useState([{
    id: '0',
    text: initialMessage,
    sender: 'ai' as const,
    timestamp: new Date()
  }]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      text: input,
      sender: 'user' as const,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    // Simulate AI response
    setTimeout(() => {
      const aiMessage = {
        id: (Date.now() + 1).toString(),
        text: "I understand. Let me help you with that. What specific aspect would you like to explore?",
        sender: 'ai' as const,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, aiMessage]);
      setIsTyping(false);
    }, 1500);
  };

  return (
    <>
      <Button
        position="fixed"
        bottom="80px"
        right="4"
        colorScheme="purple"
        onClick={onOpen}
        size="lg"
        rounded="full"
        shadow="lg"
        leftIcon={<FiMessageSquare />}
        zIndex={1000}
      >
        Chat
      </Button>

      <BottomSheet 
        isOpen={isOpen} 
        onDismiss={onClose}
        header={
          <DrawerHeader p={4}>
            <Flex align="center">
              <Text fontWeight="bold">AI Assistant</Text>
              {isTyping && (
                <Text ml={2} fontSize="sm" color="gray.500">
                  typing...
                </Text>
              )}
            </Flex>
          </DrawerHeader>
        }
      >
        <VStack spacing={4} h="full">
          <Box flex={1} w="full" overflowY="auto">
            {messages.map((msg) => (
              <Box
                key={msg.id}
                alignSelf={msg.sender === 'user' ? 'flex-end' : 'flex-start'}
                maxW="80%"
                mb={4}
              >
                <Box
                  bg={msg.sender === 'user' ? 'purple.500' : 'gray.100'}
                  color={msg.sender === 'user' ? 'white' : 'gray.800'}
                  px={4}
                  py={2}
                  borderRadius="lg"
                >
                  <Text>{msg.text}</Text>
                </Box>
              </Box>
            ))}
          </Box>

          <Flex w="full" gap={2}>
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Type your message..."
              onKeyPress={(e) => e.key === 'Enter' && handleSendMessage()}
            />
            <IconButton
              colorScheme="purple"
              aria-label="Send message"
              icon={<FiSend />}
              onClick={handleSendMessage}
              isDisabled={!input.trim() || isTyping}
            />
          </Flex>
        </VStack>
      </BottomSheet>
    </>
  );
}