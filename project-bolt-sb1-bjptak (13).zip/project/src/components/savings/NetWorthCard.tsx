import {
  Box,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Grid,
  Heading,
  Stat,
  StatLabel,
  StatNumber,
  StatHelpText,
  StatArrow,
  Text,
  Button,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import UpdateNetWorthModal from './UpdateNetWorthModal';

export default function NetWorthCard() {
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [netWorth, setNetWorth] = useState({
    total: 125000,
    change: 12.5,
    assets: 250000,
    liabilities: 125000
  });

  return (
    <>
      <Card>
        <CardHeader>
          <Flex justify="space-between" align="center">
            <Heading size="md">Net Worth Overview</Heading>
            <Button
              colorScheme="purple"
              variant="outline"
              size="sm"
              onClick={onOpen}
            >
              Update Values
            </Button>
          </Flex>
        </CardHeader>

        <CardBody>
          <Grid templateColumns={{ base: '1fr', md: 'repeat(3, 1fr)' }} gap={6}>
            <Stat>
              <StatLabel>Total Net Worth</StatLabel>
              <StatNumber>${netWorth.total.toLocaleString()}</StatNumber>
              <StatHelpText>
                <StatArrow type={netWorth.change >= 0 ? 'increase' : 'decrease'} />
                {Math.abs(netWorth.change)}%
              </StatHelpText>
            </Stat>

            <Stat>
              <StatLabel>Total Assets</StatLabel>
              <StatNumber color="green.500">
                ${netWorth.assets.toLocaleString()}
              </StatNumber>
              <StatHelpText>Including investments</StatHelpText>
            </Stat>

            <Stat>
              <StatLabel>Total Liabilities</StatLabel>
              <StatNumber color="red.500">
                ${netWorth.liabilities.toLocaleString()}
              </StatNumber>
              <StatHelpText>Including debts</StatHelpText>
            </Stat>
          </Grid>
        </CardBody>
      </Card>

      <UpdateNetWorthModal
        isOpen={isOpen}
        onClose={onClose}
        currentValues={netWorth}
        onUpdate={setNetWorth}
      />
    </>
  );
}