import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  FormControl,
  FormLabel,
  Input,
  VStack,
  Text,
  useToast,
  Card,
  CardBody,
  Container,
  Alert,
  AlertIcon,
} from '@chakra-ui/react';
import { useAuth } from '../../contexts/AuthContext';

export default function SignUp() {
  const [loading, setLoading] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const navigate = useNavigate();
  const toast = useToast();
  const { login } = useAuth();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast({
        title: 'Passwords do not match',
        status: 'error',
        duration: 3000,
      });
      return;
    }

    try {
      setLoading(true);
      // In demo mode, we just log in directly
      login();
      navigate('/');
      toast({
        title: 'Welcome to FinWell!',
        description: 'Demo account created successfully.',
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Error creating account',
        description: 'Please try again.',
        status: 'error',
        duration: 5000,
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Box minH="100vh" bg="gray.50" py={12}>
      <Container maxW="md">
        <Card shadow="lg">
          <CardBody>
            <VStack spacing={6}>
              <Alert status="info" rounded="md">
                <AlertIcon />
                <Text>
                  This is a demo version. All accounts will be created as demo accounts.
                </Text>
              </Alert>
              
              <form onSubmit={handleSubmit} style={{ width: '100%' }}>
                <VStack spacing={4}>
                  <FormControl>
                    <FormLabel>Email</FormLabel>
                    <Input 
                      type="email" 
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      required
                      focusBorderColor="purple.500"
                    />
                  </FormControl>

                  <FormControl>
                    <FormLabel>Password</FormLabel>
                    <Input 
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      required
                      minLength={6}
                      focusBorderColor="purple.500"
                    />
                  </FormControl>

                  <FormControl>
                    <FormLabel>Confirm Password</FormLabel>
                    <Input 
                      type="password"
                      value={confirmPassword}
                      onChange={(e) => setConfirmPassword(e.target.value)}
                      required
                      minLength={6}
                      focusBorderColor="purple.500"
                    />
                  </FormControl>

                  <Button
                    type="submit"
                    width="full"
                    isLoading={loading}
                    colorScheme="purple"
                    size="lg"
                    mt={4}
                    bgGradient="linear(to-r, purple.500, purple.600)"
                    _hover={{
                      bgGradient: "linear(to-r, purple.600, purple.700)",
                    }}
                  >
                    Create Demo Account
                  </Button>
                </VStack>
              </form>

              <Text color="gray.600" fontSize="sm" textAlign="center">
                Note: This is a demo version with pre-populated data.
              </Text>
            </VStack>
          </CardBody>
        </Card>
      </Container>
    </Box>
  );
}