import { useState } from 'react';
import { Box, Container, VStack, Alert, AlertIcon, Button, Heading, Text } from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import ProgramBenefits from './ProgramBenefits';
import AudioIntro from './AudioIntro';
import AssessmentQuestion from './AssessmentQuestion';
import PathwayRecommendation from './PathwayRecommendation';
import { assessmentQuestions, programBenefits } from '../../data/assessment';
import { determinePathway } from '../../utils/assessment';

export default function InitialAssessment() {
  const [step, setStep] = useState(0);
  const [responses, setResponses] = useState<Record<string, string>>({});
  const [isPlaying, setIsPlaying] = useState(false);
  const [assessmentComplete, setAssessmentComplete] = useState(false);
  const [recommendedPath, setRecommendedPath] = useState<any>(null);

  const handleAudioToggle = () => {
    setIsPlaying(!isPlaying);
    // Audio playback logic would go here
  };

  const handleResponse = (value: string) => {
    const currentQuestion = assessmentQuestions[step - 1];
    setResponses(prev => ({
      ...prev,
      [currentQuestion.id]: value
    }));
  };

  const handleNext = () => {
    if (step < assessmentQuestions.length) {
      setStep(step + 1);
    } else {
      const pathway = determinePathway(responses);
      setRecommendedPath(pathway);
      setAssessmentComplete(true);
    }
  };

  const handlePrevious = () => {
    if (step > 0) {
      setStep(step - 1);
    }
  };

  const renderContent = () => {
    if (assessmentComplete) {
      return <PathwayRecommendation pathway={recommendedPath} />;
    }

    if (step === 0) {
      return (
        <VStack spacing={6} align="stretch">
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <Heading size="lg">Welcome to FinWell</Heading>
            <AudioIntro isPlaying={isPlaying} onToggle={handleAudioToggle} />
          </Box>

          <Text color="gray.600">
            FinWell is your personalized journey to financial wellness. Through this brief assessment,
            we'll create a customized path that fits your needs, goals, and learning style.
          </Text>

          <ProgramBenefits benefits={programBenefits} />

          <Alert status="info">
            <AlertIcon />
            This assessment takes about 5 minutes to complete. Your answers will help us create
            your personalized financial wellness journey.
          </Alert>

          <Button
            colorScheme="blue"
            size="lg"
            onClick={handleNext}
            bgGradient="linear(to-r, blue.500, purple.500)"
            _hover={{
              bgGradient: "linear(to-r, blue.600, purple.600)",
            }}
          >
            Begin Assessment
          </Button>
        </VStack>
      );
    }

    const currentQuestion = assessmentQuestions[step - 1];
    return (
      <AssessmentQuestion
        question={currentQuestion.question}
        options={currentQuestion.options}
        currentResponse={responses[currentQuestion.id]}
        onAnswer={handleResponse}
        onNext={handleNext}
        onPrevious={handlePrevious}
        isLastQuestion={step === assessmentQuestions.length}
      />
    );
  };

  return (
    <Box minH="100vh" bg="gray.50" py={8}>
      <Container maxW="2xl">{renderContent()}</Container>
    </Box>
  );
}