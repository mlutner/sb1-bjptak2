import {
  Box,
  Button,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  SimpleGrid,
  useDisclosure,
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MetricsCard from './MetricsCard';
import MoodTracker from './MoodTracker';
import QuickActions from './QuickActions';
import SpendingGraph from './SpendingGraph';
import LearningPathways from './LearningPathways';
import WearablesConnect from '../wearables/WearablesConnect';
import WellnessMetrics from '../wearables/WellnessMetrics';
import BankImportModal from '../bank/BankImportModal';
import { getUserPreferences } from '../../lib/firebase/db';

export default function Dashboard() {
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [userName, setUserName] = useState('');

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const preferences = await getUserPreferences();
        if (preferences?.isFirstTimeUser) {
          setUserName('Welcome to FinWell! ');
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      }
    };

    loadUserData();
  }, []);

  return (
    <Container maxW="container.xl">
      {/* Header Section */}
      <Box textAlign="center" pt={8} pb={6}>
        <Heading size="lg" mb={2}>Dashboard</Heading>
        <Text color="gray.600" mb={6}>
          {userName}Here's your financial wellness overview
        </Text>
      </Box>

      <VStack spacing={8} align="stretch">
        {/* Main Content */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <MetricsCard />
          <SpendingGraph />
        </SimpleGrid>

        {/* Learning Pathways */}
        <LearningPathways />

        {/* Mood Tracker */}
        <Box maxW="container.sm" mx="auto">
          <MoodTracker />
        </Box>

        {/* Wearables Section */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <VStack spacing={4}>
            <WearablesConnect />
            <Button
              size="lg"
              colorScheme="blue"
              onClick={onOpen}
              w="full"
            >
              Connect Your Bank
            </Button>
          </VStack>
          <WellnessMetrics />
        </SimpleGrid>

        {/* Secondary Content */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <QuickActions />
        </Grid>
      </VStack>

      {/* Bank Connection Modal */}
      <BankImportModal isOpen={isOpen} onClose={onClose} />
    </Container>
  );
}