import {
  Box,
  Card,
  CardBody,
  Heading,
  Text,
  Button,
  Badge,
  VStack,
  Icon,
} from '@chakra-ui/react';
import { FiLock, FiPlay, FiCheck } from 'react-icons/fi';

interface ModuleProps {
  module: {
    id: string;
    title: string;
    description: string;
    status: 'locked' | 'available' | 'in-progress' | 'completed';
    progress: number;
  };
  onNavigate: () => void;
}

export default function ModuleCard({ module, onNavigate }: ModuleProps) {
  const getStatusConfig = (status: string) => {
    switch (status) {
      case 'completed':
        return { color: 'green', icon: FiCheck, text: 'Completed' };
      case 'in-progress':
        return { color: 'blue', icon: FiPlay, text: 'In Progress' };
      case 'available':
        return { color: 'purple', icon: FiPlay, text: 'Available' };
      default:
        return { color: 'gray', icon: FiLock, text: 'Locked' };
    }
  };

  const statusConfig = getStatusConfig(module.status);

  return (
    <Card
      variant="outline"
      opacity={module.status === 'locked' ? 0.7 : 1}
      transition="all 0.2s"
      _hover={
        module.status !== 'locked'
          ? {
              transform: 'translateY(-2px)',
              shadow: 'md',
            }
          : undefined
      }
    >
      <CardBody>
        <VStack align="start" spacing={4}>
          <Icon 
            as={statusConfig.icon} 
            boxSize={6} 
            color={module.status === 'locked' ? 'gray.400' : `${statusConfig.color}.500`} 
          />
          
          <Box>
            <Heading size="sm" mb={1}>{module.title}</Heading>
            <Text fontSize="sm" color="gray.600">
              {module.description}
            </Text>
          </Box>

          <Box w="full">
            <Badge
              colorScheme={statusConfig.color}
              mb={2}
            >
              {statusConfig.text}
            </Badge>

            {module.status !== 'locked' && (
              <Button
                size="sm"
                colorScheme="purple"
                onClick={onNavigate}
                w="full"
              >
                {module.status === 'completed' ? 'Review' : 'Start'}
              </Button>
            )}
          </Box>
        </VStack>
      </CardBody>
    </Card>
  );
}