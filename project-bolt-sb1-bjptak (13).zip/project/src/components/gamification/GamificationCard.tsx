import {
  Box,
  Card,
  CardBody,
  Flex,
  Text,
  VStack,
  Icon,
  Progress,
  Badge,
  Tooltip,
  IconButton,
  useDisclosure,
  Button,
} from '@chakra-ui/react';
import { motion, AnimatePresence } from 'framer-motion';
import { FiStar, FiTrendingUp, FiAward, FiChevronLeft, FiChevronRight } from 'react-icons/fi';

export default function GamificationCard() {
  const { isOpen, onToggle } = useDisclosure({ defaultIsOpen: false });

  return (
    <Box
      position="fixed"
      top="50%"
      right={0}
      transform="translateY(-50%)"
      zIndex={10}
      display="flex"
    >
      <AnimatePresence mode="wait">
        {isOpen ? (
          <motion.div
            key="card"
            initial={{ opacity: 0, x: 300 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 300 }}
            transition={{ type: "spring", damping: 25, stiffness: 120 }}
          >
            <Card 
              bg="white" 
              shadow="lg"
              w="300px"
              borderLeftRadius="xl"
              borderRightRadius="none"
              position="relative"
            >
              <CardBody p={4}>
                <VStack spacing={4} align="stretch">
                  <Flex align="center" gap={2}>
                    <Icon as={FiStar} color="yellow.400" boxSize={6} />
                    <Text fontWeight="bold" color="gray.700" fontSize="lg">
                      Your Progress
                    </Text>
                  </Flex>

                  {/* Streak */}
                  <Flex align="center" justify="space-between">
                    <Flex align="center" gap={2}>
                      <Icon as={FiTrendingUp} color="orange.400" />
                      <Text fontSize="sm">Current Streak</Text>
                    </Flex>
                    <Badge colorScheme="orange" fontSize="sm">7 Days</Badge>
                  </Flex>

                  {/* Level Progress */}
                  <Box>
                    <Flex justify="space-between" mb={1}>
                      <Text fontSize="sm" color="gray.600">Level 3</Text>
                      <Text fontSize="sm" color="gray.600">450/1000 XP</Text>
                    </Flex>
                    <Progress
                      value={45}
                      size="sm"
                      colorScheme="purple"
                      borderRadius="full"
                    />
                  </Box>

                  {/* Recent Achievements */}
                  <VStack align="stretch" spacing={2}>
                    <Text fontSize="sm" fontWeight="medium" color="gray.700">
                      Recent Achievements
                    </Text>
                    <Tooltip label="Complete 7 days of mood tracking">
                      <Flex
                        p={2}
                        bg="purple.50"
                        borderRadius="md"
                        align="center"
                        gap={2}
                      >
                        <Icon as={FiAward} color="purple.500" />
                        <Text fontSize="sm" color="purple.700">
                          Consistency Master
                        </Text>
                      </Flex>
                    </Tooltip>
                    <Tooltip label="Connect your first wearable device">
                      <Flex
                        p={2}
                        bg="blue.50"
                        borderRadius="md"
                        align="center"
                        gap={2}
                      >
                        <Icon as={FiAward} color="blue.500" />
                        <Text fontSize="sm" color="blue.700">
                          Tech Savvy
                        </Text>
                      </Flex>
                    </Tooltip>
                  </VStack>
                </VStack>

                {/* Enhanced Back Button */}
                <IconButton
                  position="absolute"
                  left="-48px"
                  top="50%"
                  transform="translateY(-50%)"
                  size="lg"
                  colorScheme="purple"
                  onClick={onToggle}
                  borderRadius="full"
                  w="40px"
                  h="40px"
                  p={0}
                  shadow="lg"
                  _hover={{
                    transform: "translateY(-50%) scale(1.1)",
                    shadow: "xl",
                  }}
                  transition="all 0.2s"
                  bgGradient="linear(to-r, purple.500, purple.600)"
                >
                  <Icon as={FiChevronLeft} boxSize={6} />
                </IconButton>
              </CardBody>
            </Card>
          </motion.div>
        ) : (
          <motion.div
            key="button"
            initial={{ opacity: 0, x: 100 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: 100 }}
            transition={{ type: "spring", damping: 25, stiffness: 120 }}
          >
            <Button
              colorScheme="purple"
              onClick={onToggle}
              size="lg"
              borderLeftRadius="xl"
              borderRightRadius="none"
              shadow="lg"
              px={4}
              leftIcon={<Icon as={FiStar} boxSize={5} />}
              rightIcon={<Icon as={FiChevronRight} boxSize={5} />}
              _hover={{
                transform: "translateX(-5px)",
              }}
              transition="all 0.2s"
              bgGradient="linear(to-r, purple.500, purple.600)"
            >
              Progress
            </Button>
          </motion.div>
        )}
      </AnimatePresence>
    </Box>
  );
}