// Demo user data
export const DEMO_USER = {
  id: 'demo-user',
  email: 'demo@finwell.com',
  name: 'Demo User'
};

// Mock data store
class MockDataStore {
  private data: { [key: string]: any } = {};

  async get(key: string) {
    return this.data[key] || null;
  }

  async set(key: string, value: any) {
    this.data[key] = value;
    return value;
  }

  async update(key: string, value: any) {
    this.data[key] = { ...this.data[key], ...value };
    return this.data[key];
  }
}

// Export mock instances
export const db = new MockDataStore();
export const isDemoMode = true;