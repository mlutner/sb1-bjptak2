export interface Event {
  id: string;
  title: string;
  start: Date;
  end: Date;
  type: 'consultation' | 'goal' | 'reminder';
  description?: string;
}

export interface EventFormData {
  title: string;
  type: 'consultation' | 'goal' | 'reminder';
  description: string;
}