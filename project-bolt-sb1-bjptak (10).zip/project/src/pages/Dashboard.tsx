import {
  Box,
  Button,
  Container,
  Grid,
  Heading,
  Text,
  VStack,
  SimpleGrid,
  useDisclosure,
  Fade,
  HStack,
  Icon,
  Card,
  CardBody,
  Divider,
} from '@chakra-ui/react';
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { FiStar } from 'react-icons/fi';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import WearablesConnect from '../components/wearables/WearablesConnect';
import WellnessMetrics from '../components/wearables/WellnessMetrics';
import BankImportModal from '../components/bank/BankImportModal';
import { getUserPreferences } from '../lib/firebase/db';

export default function Dashboard() {
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();
  const [userName, setUserName] = useState('');
  const [showWelcome, setShowWelcome] = useState(false);

  useEffect(() => {
    const loadUserData = async () => {
      try {
        const preferences = await getUserPreferences();
        if (preferences?.isFirstTimeUser) {
          setUserName('Welcome to FinWell!');
          setShowWelcome(true);
          // Auto-hide welcome message after 5 seconds
          setTimeout(() => setShowWelcome(false), 5000);
        }
      } catch (error) {
        console.error('Error loading user data:', error);
      }
    };

    loadUserData();
  }, []);

  return (
    <Container maxW="container.xl">
      {/* Header Section */}
      <Box textAlign="center" pt={8} pb={6}>
        <Heading size="lg" mb={2}>Dashboard</Heading>
        <Text color="gray.600" mb={6}>
          {userName || "Here's your financial wellness overview"}
        </Text>

        {/* Action Buttons */}
        <SimpleGrid columns={{ base: 1, md: 2 }} spacing={4} maxW="2xl" mx="auto" mb={8}>
          <Button
            size="lg"
            colorScheme="purple"
            onClick={() => navigate('/assessment')}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
              transform: "translateY(-2px)",
            }}
            shadow="md"
          >
            Start Your Wellbeing Journey
          </Button>
          <Button
            size="lg"
            colorScheme="blue"
            onClick={() => navigate('/cbt-program')}
            bgGradient="linear(to-r, blue.500, purple.500)"
            _hover={{
              bgGradient: "linear(to-r, blue.600, purple.600)",
              transform: "translateY(-2px)",
            }}
            shadow="md"
          >
            Continue Your Learning Path
          </Button>
        </SimpleGrid>
      </Box>

      {/* Welcome Banner */}
      <Fade in={showWelcome} unmountOnExit>
        <Card 
          mb={6} 
          bg="purple.50" 
          borderColor="purple.200"
          borderWidth={1}
        >
          <CardBody>
            <HStack spacing={4} justify="center">
              <Icon as={FiStar} boxSize={6} color="purple.500" />
              <Box>
                <Text fontWeight="medium" color="purple.700">
                  {userName}
                </Text>
                <Text color="purple.600" fontSize="sm">
                  Your financial wellness journey continues
                </Text>
              </Box>
            </HStack>
          </CardBody>
        </Card>
      </Fade>

      <VStack spacing={8} align="stretch">
        {/* Main Content */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <MetricsCard />
          <SpendingGraph />
        </SimpleGrid>

        {/* Learning Pathways */}
        <LearningPathways />

        {/* Mood Tracker */}
        <Box maxW="container.sm" mx="auto">
          <MoodTracker />
        </Box>

        {/* Wearables Section */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <VStack spacing={4}>
            <WearablesConnect />
            <Button
              size="lg"
              colorScheme="blue"
              onClick={onOpen}
              w="full"
            >
              Connect Your Bank
            </Button>
          </VStack>
          <WellnessMetrics />
        </SimpleGrid>

        {/* Secondary Content */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <QuickActions />
        </Grid>
      </VStack>

      {/* Bank Connection Modal */}
      <BankImportModal isOpen={isOpen} onClose={onClose} />
    </Container>
  );
}