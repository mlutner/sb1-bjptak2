import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore, enableIndexedDbPersistence } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBv2OAfu3wO-Fa0a7azVrtEyAlKiJ1Rbqk",
  authDomain: "finwell-72e98.firebaseapp.com",
  projectId: "finwell-72e98",
  storageBucket: "finwell-72e98.appspot.com",
  messagingSenderId: "858768264942",
  appId: "1:858768264942:web:ef563eebd38df2153f6dff"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with offline persistence
export const db = getFirestore(app);
enableIndexedDbPersistence(db).catch((err) => {
  if (err.code === 'failed-precondition') {
    console.warn('Multiple tabs open, persistence can only be enabled in one tab at a time.');
  } else if (err.code === 'unimplemented') {
    console.warn('The current browser does not support offline persistence.');
  }
});