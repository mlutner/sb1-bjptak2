import { doc, getDoc, setDoc, enableNetwork, disableNetwork } from 'firebase/firestore';
import { auth, db } from '../../config/firebase';

let isOffline = false;
const CACHE_VERSION = '1';

// Helper to manage local storage with versioning
const storage = {
  get: (key: string) => {
    try {
      const item = localStorage.getItem(`${key}_v${CACHE_VERSION}`);
      return item ? JSON.parse(item) : null;
    } catch (error) {
      console.error('Error reading from localStorage:', error);
      return null;
    }
  },
  set: (key: string, value: any) => {
    try {
      localStorage.setItem(`${key}_v${CACHE_VERSION}`, JSON.stringify(value));
    } catch (error) {
      console.error('Error writing to localStorage:', error);
    }
  },
  remove: (key: string) => {
    try {
      localStorage.removeItem(`${key}_v${CACHE_VERSION}`);
    } catch (error) {
      console.error('Error removing from localStorage:', error);
    }
  }
};

export async function toggleOfflineMode(offline: boolean) {
  if (offline === isOffline) return;
  
  try {
    if (offline) {
      await disableNetwork(db);
    } else {
      await enableNetwork(db);
    }
    isOffline = offline;
  } catch (error) {
    console.error('Error toggling network:', error);
  }
}

export async function getUserPreferences() {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) {
      throw new Error('User not authenticated');
    }

    // Try cache first for faster loading
    const cachedData = storage.get(`userPreferences_${userId}`);
    if (cachedData) {
      return cachedData;
    }

    // Then try Firestore
    const preferencesRef = doc(db, 'userPreferences', userId);
    const preferencesDoc = await getDoc(preferencesRef);
    
    if (preferencesDoc.exists()) {
      const data = preferencesDoc.data();
      storage.set(`userPreferences_${userId}`, data);
      return data;
    }

    // Return default preferences if nothing found
    const defaultPreferences = { onboardingCompleted: false };
    storage.set(`userPreferences_${userId}`, defaultPreferences);
    return defaultPreferences;

  } catch (error: any) {
    console.error('Error getting user preferences:', error);
    
    // Return cached data if available during network errors
    if (error.code === 'unavailable' || error.code === 'failed-precondition') {
      const cachedData = storage.get(`userPreferences_${userId}`);
      if (cachedData) {
        return cachedData;
      }
    }

    // Return default preferences as fallback
    return { onboardingCompleted: false };
  }
}

export async function saveUserPreferences(preferences: any) {
  try {
    const userId = auth.currentUser?.uid;
    if (!userId) {
      throw new Error('User not authenticated');
    }

    const data = {
      ...preferences,
      userId,
      updatedAt: new Date().toISOString()
    };

    // Save to cache immediately
    storage.set(`userPreferences_${userId}`, data);

    // Attempt to save to Firestore
    const preferencesRef = doc(db, 'userPreferences', userId);
    await setDoc(preferencesRef, data, { merge: true });

    return true;
  } catch (error: any) {
    console.error('Error saving user preferences:', error);
    
    // If it's just a network error and we saved to cache, consider it a success
    if (error.code === 'unavailable' || error.code === 'failed-precondition') {
      return true;
    }
    
    throw error;
  }
}

export function clearPreferencesCache() {
  const userId = auth.currentUser?.uid;
  if (userId) {
    storage.remove(`userPreferences_${userId}`);
  }
}