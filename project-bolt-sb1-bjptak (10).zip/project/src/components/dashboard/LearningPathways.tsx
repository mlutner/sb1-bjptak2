import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Flex,
  Heading,
  Progress,
  Text,
  VStack,
  Badge,
  Icon,
  SimpleGrid,
  Divider,
} from '@chakra-ui/react';
import { useNavigate } from 'react-router-dom';
import { FiTarget, FiBook, FiHeart, FiDollarSign, FiTrendingUp } from 'react-icons/fi';
import { getUserPreferences } from '../../lib/firebase/db';
import { useEffect, useState } from 'react';

interface PathModule {
  id: string;
  title: string;
  description: string;
  icon: any;
  progress: number;
  status: 'locked' | 'available' | 'in-progress' | 'completed';
}

const pathModules: Record<string, PathModule[]> = {
  'spending': [
    {
      id: 'spending-awareness',
      title: 'Spending Awareness',
      description: 'Track and understand your spending patterns',
      icon: FiDollarSign,
      progress: 0,
      status: 'available'
    },
    {
      id: 'emotional-triggers',
      title: 'Emotional Triggers',
      description: 'Identify triggers that lead to overspending',
      icon: FiHeart,
      progress: 0,
      status: 'locked'
    },
    {
      id: 'healthy-habits',
      title: 'Building Healthy Habits',
      description: 'Develop sustainable spending habits',
      icon: FiTrendingUp,
      progress: 0,
      status: 'locked'
    }
  ],
  'anxiety': [
    {
      id: 'stress-management',
      title: 'Financial Stress Management',
      description: 'Tools and techniques for managing money anxiety',
      icon: FiHeart,
      progress: 0,
      status: 'available'
    },
    {
      id: 'mindfulness',
      title: 'Money Mindfulness',
      description: 'Practice mindful financial decision-making',
      icon: FiBook,
      progress: 0,
      status: 'locked'
    },
    {
      id: 'confidence',
      title: 'Building Confidence',
      description: 'Strengthen your financial confidence',
      icon: FiTarget,
      progress: 0,
      status: 'locked'
    }
  ],
  'confidence': [
    {
      id: 'foundations',
      title: 'Financial Foundations',
      description: 'Master the basics of financial wellness',
      icon: FiBook,
      progress: 0,
      status: 'available'
    },
    {
      id: 'decision-making',
      title: 'Decision Making',
      description: 'Improve your financial decision-making skills',
      icon: FiTarget,
      progress: 0,
      status: 'locked'
    },
    {
      id: 'goal-setting',
      title: 'Goal Achievement',
      description: 'Set and achieve meaningful financial goals',
      icon: FiTrendingUp,
      progress: 0,
      status: 'locked'
    }
  ]
};

export default function LearningPathways() {
  const navigate = useNavigate();
  const [userPath, setUserPath] = useState<{
    type: string;
    modules: PathModule[];
    name: string;
  } | null>(null);

  useEffect(() => {
    const loadUserPath = async () => {
      try {
        const preferences = await getUserPreferences();
        if (preferences?.preferences?.primary_concern) {
          const pathType = preferences.preferences.primary_concern;
          const modules = pathModules[pathType] || [];
          const pathNames = {
            'spending': 'Spending Control Journey',
            'anxiety': 'Financial Mindfulness Path',
            'confidence': 'Confidence Building Track'
          };

          setUserPath({
            type: pathType,
            modules,
            name: pathNames[pathType as keyof typeof pathNames] || 'Your Learning Path'
          });
        }
      } catch (error) {
        console.error('Error loading user path:', error);
      }
    };

    loadUserPath();
  }, []);

  if (!userPath) return null;

  return (
    <Card>
      <CardHeader>
        <VStack align="stretch" spacing={4}>
          <Flex justify="space-between" align="center">
            <Box>
              <Heading size="md">Your Learning Journey</Heading>
              <Text color="gray.600" mt={1}>Track your progress</Text>
            </Box>
            <Badge
              colorScheme="purple"
              fontSize="sm"
              px={3}
              py={1}
              borderRadius="full"
            >
              {userPath.name}
            </Badge>
          </Flex>
          <Progress value={0} size="sm" colorScheme="purple" borderRadius="full" />
        </VStack>
      </CardHeader>

      <CardBody>
        <VStack spacing={6} align="stretch">
          <SimpleGrid columns={{ base: 1, md: 2, lg: 3 }} spacing={4}>
            {userPath.modules.map((module) => (
              <Card
                key={module.id}
                variant="outline"
                opacity={module.status === 'locked' ? 0.7 : 1}
              >
                <CardBody>
                  <VStack align="start" spacing={4}>
                    <Icon 
                      as={module.icon} 
                      boxSize={6} 
                      color={module.status === 'locked' ? 'gray.400' : 'purple.500'} 
                    />
                    <Box>
                      <Heading size="sm" mb={1}>{module.title}</Heading>
                      <Text fontSize="sm" color="gray.600">
                        {module.description}
                      </Text>
                    </Box>
                    <Flex w="full" justify="space-between" align="center">
                      <Badge
                        colorScheme={
                          module.status === 'completed' ? 'green' :
                          module.status === 'in-progress' ? 'blue' :
                          module.status === 'available' ? 'purple' :
                          'gray'
                        }
                      >
                        {module.status}
                      </Badge>
                      {module.status !== 'locked' && (
                        <Button
                          size="sm"
                          variant="ghost"
                          colorScheme="purple"
                          onClick={() => navigate('/cbt-program')}
                        >
                          {module.status === 'completed' ? 'Review' : 'Start'}
                        </Button>
                      )}
                    </Flex>
                  </VStack>
                </CardBody>
              </Card>
            ))}
          </SimpleGrid>

          <Divider />

          <Button
            colorScheme="purple"
            size="lg"
            onClick={() => navigate('/cbt-program')}
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
              transform: "translateY(-2px)",
            }}
          >
            Continue Your Journey
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}