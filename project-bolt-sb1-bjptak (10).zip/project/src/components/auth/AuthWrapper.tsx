import { useEffect, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { getUserPreferences } from '../../lib/firebase/db';
import { Spinner, Center } from '@chakra-ui/react';

interface Props {
  children: React.ReactNode;
}

export default function AuthWrapper({ children }: Props) {
  const { user, loading: authLoading } = useAuth();
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    const checkOnboarding = async () => {
      if (!user) {
        setLoading(false);
        return;
      }

      try {
        const preferences = await getUserPreferences();
        
        // Only redirect to onboarding if explicitly not completed
        if (preferences?.onboardingCompleted === false && location.pathname !== '/onboarding') {
          navigate('/onboarding', { replace: true });
        }
      } catch (error) {
        console.error('Error checking onboarding status:', error);
      } finally {
        setLoading(false);
      }
    };

    if (!authLoading) {
      checkOnboarding();
    }
  }, [user, authLoading, navigate, location.pathname]);

  if (loading || authLoading) {
    return (
      <Center h="100vh" bg="gray.50">
        <Spinner 
          size="xl" 
          color="purple.500" 
          thickness="4px"
          speed="0.8s"
        />
      </Center>
    );
  }

  return <>{children}</>;
}