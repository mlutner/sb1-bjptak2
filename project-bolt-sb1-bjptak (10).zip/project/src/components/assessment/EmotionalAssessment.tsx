import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Radio,
  RadioGroup,
  Stack,
  Text,
  VStack,
} from '@chakra-ui/react';
import { useState } from 'react';

interface Question {
  id: number;
  text: string;
  options: string[];
}

const questions: Question[] = [
  {
    id: 1,
    text: 'How often do you feel anxious about your financial situation?',
    options: ['Never', 'Rarely', 'Sometimes', 'Often', 'Always']
  },
  {
    id: 2,
    text: 'Do you notice any patterns between your mood and spending habits?',
    options: ['No connection', 'Slight connection', 'Moderate connection', 'Strong connection']
  },
  {
    id: 3,
    text: 'How do you typically cope with financial stress?',
    options: ['Avoid thinking about it', 'Seek support', 'Make a plan', 'Emotional spending']
  }
];

interface Props {
  onComplete: (data: any) => void;
}

export default function EmotionalAssessment({ onComplete }: Props) {
  const [responses, setResponses] = useState<Record<number, string>>({});

  const handleResponse = (questionId: number, value: string) => {
    setResponses(prev => ({
      ...prev,
      [questionId]: value
    }));
  };

  const handleSubmit = () => {
    onComplete({
      emotional: {
        responses,
        timestamp: new Date().toISOString()
      }
    });
  };

  const isComplete = Object.keys(responses).length === questions.length;

  return (
    <Card>
      <CardHeader>
        <Heading size="lg">Emotional Assessment</Heading>
        <Text mt={2} color="gray.600">
          Let's understand how emotions influence your financial decisions
        </Text>
      </CardHeader>

      <CardBody>
        <VStack spacing={8} align="stretch">
          {questions.map((question) => (
            <Box key={question.id}>
              <Text mb={4} fontSize="lg">
                {question.text}
              </Text>
              <RadioGroup
                onChange={(value) => handleResponse(question.id, value)}
                value={responses[question.id] || ''}
              >
                <Stack spacing={4}>
                  {question.options.map((option) => (
                    <Radio
                      key={option}
                      value={option}
                      colorScheme="purple"
                      size="lg"
                    >
                      {option}
                    </Radio>
                  ))}
                </Stack>
              </RadioGroup>
            </Box>
          ))}

          <Button
            colorScheme="purple"
            size="lg"
            onClick={handleSubmit}
            isDisabled={!isComplete}
          >
            Continue
          </Button>
        </VStack>
      </CardBody>
    </Card>
  );
}