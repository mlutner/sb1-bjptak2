# FinWell Project Overview

## Core Features
- Financial CBT application
- Mental health support
- AI-enhanced guidance
- Progress tracking
- Professional support integration

## Technical Stack
- React + TypeScript
- Chakra UI
- Firebase Auth
- Chart.js
- React Router

## Key Components

### Authentication
- Sign In/Sign Up
- Demo account access
- Firebase integration

### Dashboard
- Financial wellbeing score
- Mood tracking
- Spending visualization
- Quick actions
- Learning pathways

### CBT Integration
- Progressive thought record
- AI analysis
- Mood-spending correlation
- Therapist chat interface

### File Structure
```
src/
├── components/
│   ├── auth/
│   ├── dashboard/
│   ├── exercises/
│   ├── layout/
│   └── progress/
├── contexts/
├── hooks/
├── lib/
├── pages/
└── types/
```

## Development Notes

### Environment Variables
```
VITE_FIREBASE_API_KEY=...
VITE_FIREBASE_AUTH_DOMAIN=...
VITE_FIREBASE_PROJECT_ID=...
VITE_FIREBASE_STORAGE_BUCKET=...
VITE_FIREBASE_MESSAGING_SENDER_ID=...
VITE_FIREBASE_APP_ID=...
VITE_FIREBASE_MEASUREMENT_ID=...
```

### Key Dependencies
- @chakra-ui/react
- firebase
- react-router-dom
- chart.js
- react-icons

### Getting Started
1. Clone repository
2. Install dependencies: `npm install`
3. Set up environment variables
4. Start development server: `npm run dev`

### Current Progress
- ✅ Basic authentication
- ✅ Dashboard layout
- ✅ Sidebar navigation
- ✅ Mood tracking
- ✅ Financial metrics
- 🚧 AI integration
- 🚧 CBT exercises
- 📝 Professional support