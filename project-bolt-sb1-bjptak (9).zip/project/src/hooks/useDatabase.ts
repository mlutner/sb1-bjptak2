import { useCallback } from 'react';
import { useToast } from '@chakra-ui/react';
import * as db from '../lib/firebase/db';
import type { MoodEntry } from '../types/mood';
import type { JournalEntry } from '../types/journal';

export function useDatabase() {
  const toast = useToast();

  const handleError = useCallback((error: any, operation: string) => {
    console.error(`Database error during ${operation}:`, error);
    
    // Check if error is due to Firebase not being initialized
    if (error.message?.includes('firestore is not available')) {
      toast({
        title: 'Development Mode',
        description: 'Using mock data. Firebase is not configured.',
        status: 'info',
        duration: 5000,
      });
      return null;
    }

    toast({
      title: 'Error',
      description: `Failed to ${operation}. Please try again.`,
      status: 'error',
      duration: 5000,
    });
    return null;
  }, [toast]);

  const saveMoodEntry = useCallback(async (entry: MoodEntry) => {
    try {
      return await db.saveMoodEntry(entry);
    } catch (error) {
      return handleError(error, 'save mood entry');
    }
  }, [handleError]);

  // ... rest of the hook implementation remains the same

  return {
    saveMoodEntry,
    getMoodEntries,
    saveJournalEntry,
    getJournalEntries,
    updateModuleProgress,
    getModuleProgress,
    saveAssessment,
    getLatestAssessment,
    saveUserPreferences,
    getUserPreferences,
  };
}