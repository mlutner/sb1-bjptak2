import { openDB } from 'idb';
import { hash } from 'object-hash';

const DB_NAME = 'finwell';
const STORE_NAME = 'ai_responses';
const CACHE_DURATION = 3600000; // 1 hour in milliseconds

const dbPromise = openDB(DB_NAME, 1, {
  upgrade(db) {
    db.createObjectStore(STORE_NAME);
  },
});

export const hashPrompt = (prompt: string): string => {
  return hash(prompt);
};

export interface CachedResponse {
  data: any;
  timestamp: number;
}

export const cacheResponse = async (key: string, response: any): Promise<void> => {
  const db = await dbPromise;
  const cachedData: CachedResponse = {
    data: response,
    timestamp: Date.now(),
  };
  await db.put(STORE_NAME, cachedData, key);
};

export const getCachedResponse = async (key: string): Promise<any | null> => {
  const db = await dbPromise;
  const cached: CachedResponse | undefined = await db.get(STORE_NAME, key);

  if (!cached) return null;

  // Check if cache is expired
  if (Date.now() - cached.timestamp > CACHE_DURATION) {
    await db.delete(STORE_NAME, key);
    return null;
  }

  return cached.data;
};

export const clearCache = async (): Promise<void> => {
  const db = await dbPromise;
  await db.clear(STORE_NAME);
};

export async function getAIResponse<T>(
  prompt: string,
  generateResponse: () => Promise<T>
): Promise<T> {
  const cacheKey = hashPrompt(prompt);
  
  try {
    // Check cache first
    const cached = await getCachedResponse(cacheKey);
    if (cached) return cached as T;

    // Get new response if not cached
    const response = await generateResponse();
    await cacheResponse(cacheKey, response);
    
    return response;
  } catch (error) {
    console.error('Error in AI response caching:', error);
    // If cache fails, fallback to direct response
    return generateResponse();
  }
}</content>