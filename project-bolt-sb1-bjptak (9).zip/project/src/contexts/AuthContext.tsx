import { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signOut } from 'firebase/auth';
import { auth } from '../config/firebase';
import { useToast } from '@chakra-ui/react';
import { toggleOfflineMode, clearPreferencesCache } from '../lib/firebase/db';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isOffline: boolean;
  signOut: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  isOffline: false,
  signOut: async () => {},
});

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const toast = useToast();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      setLoading(false);
    });

    const handleOnline = () => {
      setIsOffline(false);
      toggleOfflineMode(false);
      toast({
        title: 'Back Online',
        description: 'Syncing your data...',
        status: 'success',
        duration: 3000,
      });
    };

    const handleOffline = () => {
      setIsOffline(true);
      toggleOfflineMode(true);
      toast({
        title: 'You are offline',
        description: "Some features may be limited. Your changes will sync when you're back online",
        status: 'warning',
        duration: null,
        isClosable: true,
      });
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Check initial online status
    if (!navigator.onLine) {
      handleOffline();
    }

    return () => {
      unsubscribe();
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [toast]);

  const handleSignOut = async () => {
    try {
      clearPreferencesCache();
      await signOut(auth);
      toast({
        title: 'Signed out successfully',
        status: 'success',
        duration: 3000,
      });
    } catch (error) {
      toast({
        title: 'Error signing out',
        status: 'error',
        duration: 3000,
      });
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, signOut: handleSignOut, isOffline }}>
      {!loading && children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);