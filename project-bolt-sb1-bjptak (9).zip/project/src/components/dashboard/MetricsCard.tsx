import {
  Box,
  Button,
  CircularProgress,
  CircularProgressLabel,
  Grid,
  Heading,
  Text,
  VStack,
  Flex,
  ButtonGroup,
} from '@chakra-ui/react';
import { useState } from 'react';
import { motion } from 'framer-motion';

interface MetricBarProps {
  label: string;
  value: number;
  icon?: React.ReactNode;
}

function MetricBar({ label, value, icon }: MetricBarProps) {
  return (
    <VStack spacing={2} align="stretch">
      <Flex justify="space-between" align="center">
        <Text color="gray.600" fontSize="sm">{label}</Text>
        <Text fontWeight="medium">{value}%</Text>
      </Flex>
      <Box h="2" bg="gray.100" rounded="full" overflow="hidden">
        <Box
          h="full"
          bg="purple.500"
          rounded="full"
          transition="width 0.3s"
          w={`${value}%`}
        />
      </Box>
    </VStack>
  );
}

export default function MetricsCard() {
  const [activeView, setActiveView] = useState<'wellbeing' | 'mood'>('wellbeing');
  const wellbeingScore = 78;
  const moodScore = 82;

  return (
    <Box bg="white" rounded="lg" shadow="sm" p={6}>
      <VStack spacing={6} align="stretch">
        <Flex justify="space-between" align="center">
          <Box>
            <Heading size="md" mb={1}>Financial Wellbeing</Heading>
            <ButtonGroup size="sm" isAttached variant="outline" borderRadius="full" p="1" bg="gray.50">
              <Button
                onClick={() => setActiveView('wellbeing')}
                borderRadius="full"
                bg={activeView === 'wellbeing' ? 'white' : 'transparent'}
                color={activeView === 'wellbeing' ? 'purple.600' : 'gray.600'}
                borderColor={activeView === 'wellbeing' ? 'purple.200' : 'transparent'}
                boxShadow={activeView === 'wellbeing' ? 'sm' : 'none'}
                _hover={{ bg: activeView === 'wellbeing' ? 'white' : 'gray.100' }}
              >
                Score
              </Button>
              <Button
                onClick={() => setActiveView('mood')}
                borderRadius="full"
                bg={activeView === 'mood' ? 'white' : 'transparent'}
                color={activeView === 'mood' ? 'purple.600' : 'gray.600'}
                borderColor={activeView === 'mood' ? 'purple.200' : 'transparent'}
                boxShadow={activeView === 'mood' ? 'sm' : 'none'}
                _hover={{ bg: activeView === 'mood' ? 'white' : 'gray.100' }}
              >
                Mood vs. Spend
              </Button>
            </ButtonGroup>
          </Box>
        </Flex>

        {activeView === 'wellbeing' ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Flex justify="center" py={6}>
              <CircularProgress
                value={wellbeingScore}
                size="160px"
                thickness="8px"
                color="purple.500"
                trackColor="purple.50"
              >
                <CircularProgressLabel>
                  <VStack spacing={0}>
                    <Text fontSize="4xl" fontWeight="bold" lineHeight="1">
                      {wellbeingScore}
                    </Text>
                    <Text fontSize="sm" color="gray.500">/100</Text>
                  </VStack>
                </CircularProgressLabel>
              </CircularProgress>
            </Flex>

            <Grid templateColumns="repeat(2, 1fr)" gap={4}>
              <MetricBar label="Mindset" value={80} />
              <MetricBar label="Resiliency" value={75} />
              <MetricBar label="Consistency" value={85} />
              <MetricBar label="Spending" value={70} />
            </Grid>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <Box h="300px">
              <Text textAlign="center" color="gray.600">
                Mood and spending correlation visualization
              </Text>
            </Box>
          </motion.div>
        )}
      </VStack>
    </Box>
  );
}