import { useState } from 'react';
import {
  Box,
  Button,
  Card,
  CardBody,
  CardHeader,
  Heading,
  Progress,
  Stack,
  Text,
  VStack,
} from '@chakra-ui/react';
import { motion } from 'framer-motion';
import { AssessmentQuestion, UserAssessment } from '../../types/assessment';
import { QuestionRenderer } from './QuestionRenderer';

interface Props {
  onComplete: (data: any) => void;
}

const questions: AssessmentQuestion[] = [
  {
    id: 'motivation',
    title: "What brings you here today?",
    type: 'multiple-select',
    options: [
      { id: 'anxiety', label: 'Financial anxiety' },
      { id: 'spending', label: 'Spending concerns' },
      { id: 'debt', label: 'Debt stress' },
      { id: 'habits', label: 'Better habits' }
    ]
  },
  // Add more questions as needed
];

export default function InitialAssessment({ onComplete }: Props) {
  const [step, setStep] = useState(0);
  const [assessment, setAssessment] = useState<Partial<UserAssessment>>({
    emotionalState: {
      currentMood: '',
      stressLevel: 5,
      confidence: 5,
      timestamp: new Date()
    },
    financialBehavior: {
      spendingTriggers: [],
      riskFactors: [],
      copingMechanisms: []
    },
    riskLevel: 'medium',
    goals: [],
    preferences: {
      learningStyle: [],
      timeCommitment: '',
      supportPreference: []
    }
  });

  const handleNext = () => {
    if (step === questions.length - 1) {
      onComplete({ initial: assessment });
    } else {
      setStep(s => s + 1);
    }
  };

  const handlePrevious = () => {
    setStep(s => Math.max(0, s - 1));
  };

  const currentQuestion = questions[step];
  const progress = ((step + 1) / questions.length) * 100;

  return (
    <Card>
      <CardHeader>
        <VStack spacing={4} align="stretch">
          <Heading size="lg">Initial Assessment</Heading>
          <Text color="gray.600">
            Let's understand your current situation better
          </Text>
          <Progress
            value={progress}
            size="sm"
            colorScheme="purple"
            borderRadius="full"
          />
        </VStack>
      </CardHeader>

      <CardBody>
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -20 }}
        >
          <VStack spacing={6} align="stretch">
            <Box>
              <Heading size="md" mb={4}>
                {currentQuestion.title}
              </Heading>
              
              <QuestionRenderer
                question={currentQuestion}
                value={assessment}
                onChange={(value) => setAssessment(prev => ({ ...prev, ...value }))}
              />
            </Box>

            <Stack direction="row" spacing={4} justify="space-between">
              <Button
                variant="outline"
                onClick={handlePrevious}
                isDisabled={step === 0}
              >
                Previous
              </Button>
              
              <Button
                colorScheme="purple"
                onClick={handleNext}
              >
                {step === questions.length - 1 ? 'Complete' : 'Next'}
              </Button>
            </Stack>
          </VStack>
        </motion.div>
      </CardBody>
    </Card>
  );
}