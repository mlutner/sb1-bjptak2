import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Box,
  Button,
  Container,
  Heading,
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalFooter,
  Text,
  VStack,
  useDisclosure,
} from '@chakra-ui/react';
import ProgressSteps from './ProgressSteps';

export default function StartAssessment() {
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();

  const handleStartAssessment = () => {
    onClose();
    navigate('/assessment');
  };

  return (
    <>
      <Box bg="linear-gradient(to bottom, var(--chakra-colors-purple-50), white)" py={12}>
        <Container maxW="3xl" textAlign="center">
          <VStack spacing={6}>
            <Heading as="h1" size="2xl" color="gray.900">
              Begin Your Financial Wellness Journey
            </Heading>
            <Text fontSize="xl" color="gray.600">
              Take our 5-minute assessment to get your personalized pathway to financial well-being
            </Text>
            <Button
              size="lg"
              colorScheme="purple"
              px={8}
              py={7}
              onClick={onOpen}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
                transform: "translateY(-2px)",
              }}
              shadow="lg"
              _hover={{ shadow: "xl" }}
              transition="all 0.2s"
            >
              Start Your Assessment
            </Button>
          </VStack>
        </Container>
      </Box>

      <Modal isOpen={isOpen} onClose={onClose} size="lg">
        <ModalOverlay />
        <ModalContent mx={4}>
          <ModalHeader>Your Journey Map</ModalHeader>
          <ModalBody>
            <ProgressSteps
              steps={[
                { label: 'Assessment', time: '5 mins' },
                { label: 'Pathway Selection', time: '2 mins' },
                { label: 'Module Access', time: '1 min' }
              ]}
            />
          </ModalBody>
          <ModalFooter flexDir="column" gap={3}>
            <Button
              w="full"
              colorScheme="purple"
              onClick={handleStartAssessment}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Begin Assessment
            </Button>
            <Button w="full" variant="ghost" onClick={onClose}>
              Maybe Later
            </Button>
          </ModalFooter>
        </ModalContent>
      </Modal>
    </>
  );
}