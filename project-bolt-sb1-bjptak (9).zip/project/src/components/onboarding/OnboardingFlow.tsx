import {
  Box,
  Container,
  Flex,
  Heading,
  Progress,
  Stack,
  Text,
  VStack,
  useToast,
} from '@chakra-ui/react';
import { useState, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import IntroScreen from './IntroScreen';
import QuestionCard from './QuestionCard';
import SummaryScreen from './SummaryScreen';
import { questions } from './questions';
import { saveUserPreferences } from '../../lib/firebase/db';

type OnboardingStage = 'intro' | 'questions' | 'summary';

export default function OnboardingFlow() {
  const [stage, setStage] = useState<OnboardingStage>('intro');
  const [currentStep, setCurrentStep] = useState(0);
  const [responses, setResponses] = useState<Record<string, string>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const navigate = useNavigate();
  const toast = useToast();

  const handleAnswer = useCallback((value: string) => {
    setResponses(prev => ({
      ...prev,
      [questions[currentStep].id]: value
    }));
  }, [currentStep]);

  const handleNext = useCallback(() => {
    if (currentStep < questions.length - 1) {
      setCurrentStep(prev => prev + 1);
    } else {
      setStage('summary');
    }
  }, [currentStep]);

  const completeOnboarding = useCallback(async () => {
    if (isSubmitting) return;
    
    setIsSubmitting(true);
    try {
      // Save preferences first
      await saveUserPreferences({
        onboardingCompleted: true,
        preferences: responses,
        completedAt: new Date().toISOString()
      });

      // Show success message
      toast({
        title: 'Welcome to FinWell!',
        description: 'Your personalized journey has been created',
        status: 'success',
        duration: 3000,
      });

      // Navigate to dashboard
      navigate('/dashboard', { replace: true });
    } catch (error) {
      console.error('Error completing onboarding:', error);
      setIsSubmitting(false);
      toast({
        title: 'Error',
        description: 'Unable to complete onboarding. Please try again.',
        status: 'error',
        duration: 5000,
      });
    }
  }, [responses, navigate, toast]);

  if (stage === 'intro') {
    return <IntroScreen onStart={() => setStage('questions')} />;
  }

  if (stage === 'summary') {
    return (
      <SummaryScreen 
        responses={responses} 
        onComplete={completeOnboarding}
        isSubmitting={isSubmitting}
      />
    );
  }

  const currentQuestion = questions[currentStep];
  const progress = ((currentStep + 1) / questions.length) * 100;

  return (
    <Box minH="100vh" bg="gray.50">
      <Container maxW="container.md" py={16}>
        <VStack spacing={8} align="stretch">
          <VStack spacing={2} align="stretch">
            <Flex justify="space-between">
              <Text color="gray.600">Step {currentStep + 1} of {questions.length}</Text>
              <Text color="gray.600">{Math.round(progress)}%</Text>
            </Flex>
            <Progress
              value={progress}
              size="sm"
              colorScheme="purple"
              borderRadius="full"
            />
          </VStack>

          <AnimatePresence mode="wait">
            <motion.div
              key={currentStep}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.2 }}
            >
              <VStack spacing={8} align="stretch">
                <Heading size="lg">{currentQuestion.title}</Heading>

                <Stack spacing={4}>
                  {currentQuestion.options.map((option) => (
                    <QuestionCard
                      key={option.value}
                      label={option.label}
                      description={option.description}
                      isSelected={responses[currentQuestion.id] === option.value}
                      onClick={() => {
                        handleAnswer(option.value);
                        setTimeout(handleNext, 300);
                      }}
                    />
                  ))}
                </Stack>
              </VStack>
            </motion.div>
          </AnimatePresence>
        </VStack>
      </Container>
    </Box>
  );
}