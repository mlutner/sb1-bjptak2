import {
  Box,
  Button,
  Container,
  Heading,
  Text,
  VStack,
  Card,
  CardBody,
  SimpleGrid,
  Icon,
  Progress,
  Badge,
} from '@chakra-ui/react';
import { FiTarget, FiBook, FiHeart } from 'react-icons/fi';
import { motion } from 'framer-motion';

interface Props {
  responses: Record<string, string>;
  onComplete: () => void;
  isSubmitting: boolean;
}

export default function SummaryScreen({ responses, onComplete, isSubmitting }: Props) {
  const getPathName = () => {
    switch (responses.primary_concern) {
      case 'anxiety':
        return 'Financial Mindfulness Path';
      case 'spending':
        return 'Spending Control Journey';
      case 'confidence':
        return 'Confidence Building Track';
      default:
        return 'Personalized Financial Journey';
    }
  };

  const getRecommendations = () => {
    const recommendations = [];
    
    if (responses.stress_level === 'high') {
      recommendations.push({
        icon: FiHeart,
        title: 'Wellness Focus',
        description: 'Starting with stress management and emotional awareness exercises'
      });
    }

    if (responses.learning_style === 'guidance') {
      recommendations.push({
        icon: FiBook,
        title: 'Expert Sessions',
        description: 'Regular check-ins with financial wellness professionals'
      });
    }

    recommendations.push({
      icon: FiTarget,
      title: 'Goal Setting',
      description: 'Personalized milestones based on your preferences'
    });

    return recommendations;
  };

  return (
    <Box minH="100vh" bg="gray.50" py={12}>
      <Container maxW="container.md">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.3 }}
        >
          <VStack spacing={8} align="stretch">
            <VStack spacing={4} textAlign="center">
              <Heading size="lg">Your Personalized Path</Heading>
              <Text color="gray.600">
                Based on your responses, we've crafted a journey tailored to your needs
              </Text>
              <Badge
                colorScheme="purple"
                fontSize="md"
                px={4}
                py={2}
                borderRadius="full"
              >
                {getPathName()}
              </Badge>
            </VStack>

            <Card>
              <CardBody>
                <VStack spacing={6}>
                  <Box w="full">
                    <Text fontWeight="medium" mb={2}>Journey Preparation</Text>
                    <Progress value={100} size="sm" colorScheme="green" rounded="full" />
                  </Box>
                  
                  <SimpleGrid columns={{ base: 1, md: 2 }} spacing={6} w="full">
                    {getRecommendations().map((rec, index) => (
                      <Card key={index} variant="outline">
                        <CardBody>
                          <VStack align="start" spacing={3}>
                            <Icon as={rec.icon} boxSize={6} color="purple.500" />
                            <Box>
                              <Text fontWeight="bold">{rec.title}</Text>
                              <Text fontSize="sm" color="gray.600">
                                {rec.description}
                              </Text>
                            </Box>
                          </VStack>
                        </CardBody>
                      </Card>
                    ))}
                  </SimpleGrid>

                  <Button
                    size="lg"
                    colorScheme="purple"
                    onClick={onComplete}
                    w="full"
                    isLoading={isSubmitting}
                    loadingText="Creating Your Journey..."
                    bgGradient="linear(to-r, purple.500, blue.500)"
                    _hover={{
                      bgGradient: "linear(to-r, purple.600, blue.600)",
                      transform: "translateY(-2px)",
                    }}
                  >
                    Begin Your Journey
                  </Button>
                </VStack>
              </CardBody>
            </Card>
          </VStack>
        </motion.div>
      </Container>
    </Box>
  );
}