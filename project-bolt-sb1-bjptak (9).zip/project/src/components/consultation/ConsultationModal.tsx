import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalBody,
  ModalCloseButton,
  Button,
  VStack,
  HStack,
  Text,
  Box,
  Icon,
  useToast,
} from '@chakra-ui/react';
import { FiVideo, FiPhone, FiMessageSquare, FiCalendar } from 'react-icons/fi';
import { useState } from 'react';

interface Props {
  isOpen: boolean;
  onClose: () => void;
}

const CONSULTATION_TYPES = [
  { id: 'video', icon: FiVideo, label: 'Video Call' },
  { id: 'phone', icon: FiPhone, label: 'Phone Call' },
  { id: 'chat', icon: FiMessageSquare, label: 'Chat Session' },
];

const TIME_SLOTS = [
  '9:00 AM', '10:00 AM', '11:00 AM',
  '2:00 PM', '3:00 PM', '4:00 PM',
];

export default function ConsultationModal({ isOpen, onClose }: Props) {
  const [selectedType, setSelectedType] = useState<string>('');
  const [selectedTime, setSelectedTime] = useState<string>('');
  const toast = useToast();

  const handleBooking = () => {
    if (!selectedType || !selectedTime) {
      toast({
        title: 'Please select both consultation type and time',
        status: 'warning',
        duration: 3000,
      });
      return;
    }

    toast({
      title: 'Consultation Booked!',
      description: `Your ${selectedType} consultation is scheduled for ${selectedTime}`,
      status: 'success',
      duration: 5000,
    });
    onClose();
  };

  return (
    <Modal isOpen={isOpen} onClose={onClose} size="xl">
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Schedule Your Consultation</ModalHeader>
        <ModalCloseButton />
        <ModalBody pb={6}>
          <VStack spacing={6} align="stretch">
            <Box>
              <Text fontWeight="medium" mb={3}>Select Consultation Type</Text>
              <HStack spacing={4}>
                {CONSULTATION_TYPES.map(({ id, icon, label }) => (
                  <Button
                    key={id}
                    variant={selectedType === id ? 'solid' : 'outline'}
                    colorScheme="purple"
                    leftIcon={<Icon as={icon} />}
                    onClick={() => setSelectedType(id)}
                    flex={1}
                  >
                    {label}
                  </Button>
                ))}
              </HStack>
            </Box>

            <Box>
              <Text fontWeight="medium" mb={3}>Select Time Slot</Text>
              <VStack spacing={2} align="stretch">
                {TIME_SLOTS.map((time) => (
                  <Button
                    key={time}
                    variant={selectedTime === time ? 'solid' : 'outline'}
                    colorScheme="purple"
                    onClick={() => setSelectedTime(time)}
                    leftIcon={<Icon as={FiCalendar} />}
                    justifyContent="flex-start"
                  >
                    {time}
                  </Button>
                ))}
              </VStack>
            </Box>

            <Button
              colorScheme="purple"
              size="lg"
              isDisabled={!selectedType || !selectedTime}
              onClick={handleBooking}
              bgGradient="linear(to-r, purple.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, purple.600, blue.600)",
              }}
            >
              Confirm Booking
            </Button>
          </VStack>
        </ModalBody>
      </ModalContent>
    </Modal>
  );
}