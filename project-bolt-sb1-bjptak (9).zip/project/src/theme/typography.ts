import { defineStyleConfig } from '@chakra-ui/react';

export const Heading = defineStyleConfig({
  baseStyle: {
    fontWeight: 'bold',
    color: 'gray.900',
    letterSpacing: '-0.02em',
  },
  sizes: {
    '2xl': {
      fontSize: ['3xl', '4xl'],
      lineHeight: 1.2,
    },
    xl: {
      fontSize: ['2xl', '3xl'],
      lineHeight: 1.2,
    },
    lg: {
      fontSize: ['xl', '2xl'],
      lineHeight: 1.2,
    },
    md: {
      fontSize: 'xl',
      lineHeight: 1.3,
    },
    sm: {
      fontSize: 'md',
      lineHeight: 1.4,
    },
  },
  defaultProps: {
    size: 'md',
  },
});

export const Text = defineStyleConfig({
  baseStyle: {
    color: 'gray.700',
    fontSize: 'md',
    lineHeight: 1.6,
  },
  variants: {
    secondary: {
      color: 'gray.600',
      fontSize: 'sm',
    },
    subtle: {
      color: 'gray.500',
      fontSize: 'sm',
    },
  },
});