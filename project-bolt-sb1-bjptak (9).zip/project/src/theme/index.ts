import { extendTheme } from '@chakra-ui/react';
import { colors } from './colors';

const theme = extendTheme({
  colors,
  components: {
    Button: {
      baseStyle: {
        fontWeight: 'medium',
        borderRadius: 'full',
        _hover: {
          transform: 'translateY(-1px)',
        },
        transition: 'all 0.2s',
      },
      variants: {
        solid: {
          bg: 'headspace.orange.primary',
          color: 'white',
          _hover: {
            bg: 'headspace.orange.secondary',
          },
          _active: {
            bg: 'headspace.orange.secondary',
          }
        },
        outline: {
          bg: 'transparent',
          borderColor: 'headspace.orange.primary',
          borderWidth: '2px',
          color: 'headspace.orange.primary',
          _hover: {
            bg: 'headspace.orange.light',
          },
          _active: {
            bg: 'headspace.orange.light',
          }
        },
        ghost: {
          bg: 'transparent',
          color: 'headspace.slate',
          _hover: {
            bg: 'headspace.orange.light',
          },
          _active: {
            bg: 'headspace.orange.light',
          }
        },
        accent: {
          bg: 'headspace.red.primary',
          color: 'white',
          _hover: {
            bg: 'headspace.red.secondary',
          },
          _active: {
            bg: 'headspace.red.secondary',
          }
        },
        calm: {
          bg: 'white',
          color: 'headspace.slate',
          borderWidth: '2px',
          borderColor: 'headspace.orange.light',
          _hover: {
            bg: 'headspace.orange.light',
          },
          _active: {
            bg: 'headspace.orange.light',
          }
        },
        pill: {
          bg: 'headspace.orange.light',
          color: 'headspace.orange.primary',
          fontSize: 'sm',
          height: '32px',
          px: '12px',
          _hover: {
            bg: 'white',
            shadow: 'sm',
          },
          _active: {
            bg: 'white',
          }
        }
      },
      defaultProps: {
        variant: 'solid',
      }
    },
    IconButton: {
      baseStyle: {
        borderRadius: 'full',
      },
      variants: {
        solid: {
          bg: 'headspace.orange.primary',
          color: 'white',
          _hover: {
            bg: 'headspace.orange.secondary',
            transform: 'translateY(-1px)',
          }
        },
        ghost: {
          color: 'headspace.slate',
          _hover: {
            bg: 'headspace.orange.light',
            transform: 'translateY(-1px)',
          }
        },
        outline: {
          borderColor: 'headspace.orange.primary',
          color: 'headspace.orange.primary',
          _hover: {
            bg: 'headspace.orange.light',
            transform: 'translateY(-1px)',
          }
        }
      }
    },
    Progress: {
      baseStyle: {
        track: {
          bg: 'headspace.orange.light'
        },
        filledTrack: {
          bg: 'headspace.orange.primary'
        }
      }
    },
    ButtonGroup: {
      baseStyle: {
        spacing: 2
      },
      variants: {
        pill: {
          bg: 'headspace.orange.light',
          p: '2px',
          borderRadius: 'full',
          spacing: 0
        }
      }
    }
  }
});

export default theme;