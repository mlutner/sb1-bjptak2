import {
  Box,
  Button,
  ButtonGroup,
  Container,
  Grid,
  Heading,
  Progress,
  Text,
  VStack,
  SimpleGrid,
  useDisclosure,
} from '@chakra-ui/react';
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import MetricsCard from '../components/dashboard/MetricsCard';
import MoodTracker from '../components/dashboard/MoodTracker';
import QuickActions from '../components/dashboard/QuickActions';
import SpendingGraph from '../components/dashboard/SpendingGraph';
import LearningPathways from '../components/dashboard/LearningPathways';
import WearablesConnect from '../components/wearables/WearablesConnect';
import WellnessMetrics from '../components/wearables/WellnessMetrics';
import BankImportModal from '../components/bank/BankImportModal';

export default function Dashboard() {
  const navigate = useNavigate();
  const { isOpen, onOpen, onClose } = useDisclosure();

  return (
    <Container maxW="container.xl">
      {/* Header Section */}
      <Box textAlign="center" pt={8} pb={6}>
        <Heading size="lg" mb={2}>Dashboard</Heading>
        <Text color="gray.600" mb={6}>
          Welcome back! Here's your financial wellness overview.
        </Text>

        {/* Action Buttons */}
        <ButtonGroup spacing={4} mb={8}>
          <Button
            size="lg"
            colorScheme="purple"
            bgGradient="linear(to-r, purple.500, blue.500)"
            _hover={{
              bgGradient: "linear(to-r, purple.600, blue.600)",
              transform: "translateY(-2px)",
            }}
            shadow="md"
            transition="all 0.2s"
            onClick={() => navigate('/assessment')}
          >
            Start Your Wellbeing Journey
          </Button>
          <Button
            size="lg"
            colorScheme="blue"
            bgGradient="linear(to-r, blue.500, purple.500)"
            _hover={{
              bgGradient: "linear(to-r, blue.600, purple.600)",
              transform: "translateY(-2px)",
            }}
            shadow="md"
            transition="all 0.2s"
            onClick={() => navigate('/cbt-program')}
          >
            Continue Your CBT Pathway
          </Button>
        </ButtonGroup>
      </Box>

      <VStack spacing={8} align="stretch">
        {/* Mood Tracker */}
        <Box maxW="container.sm" mx="auto">
          <MoodTracker />
        </Box>

        {/* Main Content */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <MetricsCard />
          <SpendingGraph />
        </SimpleGrid>

        {/* Wearables Section */}
        <SimpleGrid columns={{ base: 1, lg: 2 }} spacing={6}>
          <VStack spacing={4}>
            <WearablesConnect />
            <Button
              size="lg"
              colorScheme="blue"
              bgGradient="linear(to-r, cyan.500, blue.500)"
              _hover={{
                bgGradient: "linear(to-r, cyan.600, blue.600)",
                transform: "translateY(-2px)",
              }}
              shadow="md"
              transition="all 0.2s"
              onClick={onOpen}
              w="full"
            >
              Connect Your Bank
            </Button>
          </VStack>
          <WellnessMetrics />
        </SimpleGrid>

        {/* Secondary Content */}
        <Grid templateColumns={{ base: '1fr', lg: 'repeat(2, 1fr)' }} gap={6}>
          <QuickActions />
          <LearningPathways />
        </Grid>
      </VStack>

      {/* Bank Connection Modal */}
      <BankImportModal isOpen={isOpen} onClose={onClose} />
    </Container>
  );
}