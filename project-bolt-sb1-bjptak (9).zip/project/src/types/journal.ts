export interface JournalEntry {
  id?: string;
  userId?: string;
  date: string;
  type: 'text' | 'video';
  mood: string;
  situation?: string;
  thoughts?: string;
  emotions?: string;
  behaviors?: string;
  insights?: string;
  tags: string[];
  mediaUrl?: string;
  transcription?: string;
  learningStyle?: 'visual' | 'auditory' | 'written';
  createdAt?: string;
}